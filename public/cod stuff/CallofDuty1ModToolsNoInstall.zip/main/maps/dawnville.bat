cd ..\..\tools\bin

q3map ../../main/maps/dawnville
q3map -vis ../../main/maps/dawnville
flare -extra -sundiffusesamples 10 -dumpoptions ../../main/maps/dawnville

cd ..\..\

CodSP +set g_connectpaths 2 +set dedicated 1 +devmap dawnville
CodSP +set r_vc_compile 2 +devmap dawnville

pause
