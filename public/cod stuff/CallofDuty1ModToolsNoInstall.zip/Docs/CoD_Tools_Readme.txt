Call Of Duty
Map & Mod Tools
===============

IMPORTANT NOTE:  These tools are not supported by Activision Customer Support.

The Call Of Duty tools are not designed to run on Microsoft Windows� 98 or ME.  They are designed to run on Windows� 2000 or XP.

The Map & Mod tools must be installed to an existing, valid Call of Duty directory.  The installer will detect the location of your CoD installation automatically.  

On running CoDRadiant for the first time, you will need to load the included cod.qe4 project file which is located in "tools/bin". If you ever reinstall CoDRadiant to a different location you will need to reload this project file from the new location.