# game.mp.uo.i386.so Recovered Source

This directory is the canonical compile-checked source tree for the recovered
`game.mp.uo.i386.so` behavior. The maintained source folder is no longer named
as i386-only because the recovered C is intended to build for other host-module
experiments too.

The main server build target is the 32-bit shared object expected by the Linux
server:

```sh
make -C game_mp_uo shared-i386
```

That writes `game_mp_uo/build-i386-shared/game.mp.uo.i386.so`.

For local shared-object experiments using the host toolchain:

```sh
make -C game_mp_uo shared
```

The compile-only progress gate builds reviewed recovered source into a static
archive:

```sh
make -C game_mp_uo check
```

That target is a progress gate, not a claim of full replacement-module equivalence. Until
the recovered tree contains enough of the module to link and run as a replacement, external
engine/module calls remain explicit `extern` boundaries and unrecovered behavior must stay
out of `src/` or be represented by obvious stubs.

For bugfixes and suspected reconstruction errors, compare this source to the original
binary's machine code. Generated decompiler output, local notes, source comments, and
existing recovered code are navigation context, not behavioral authority.

Rules for this tree:

- `src/` contains valid C that participates in the build.
- Incomplete recovered logic must be marked with `TODO_RECOVER`, `STUB`, `INFERRED`, or a
  similarly searchable marker tied to an entry in `unknowns/`.
- Pseudocode that does not compile belongs in `notes/` or ignored generated output, not
  in `src/`.
- Every non-obvious name, type, field, or behavior should cite an RVA and direct
  binary-derived evidence. For suspected bugs, that evidence must be machine code.
- Unresolved assumptions should be recorded as per-entry files in `unknowns/`, then
  referenced from source, notes, or evidence with the stable unknown ID.
- The target remains functional equivalence, not byte-identical rebuilding.
