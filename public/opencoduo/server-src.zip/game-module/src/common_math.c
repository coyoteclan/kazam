/*
 * Source reconstruction for common math/random helpers.
 *
 * Binary SHA-256:
 * 4d2391c10e234559ace294fb69d96741cad522653c361f13f626f4dc1891acb7
 */

#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "coduo_x87emu.h" /* defines EMULATE_X87; x87 shim when it is 1 */

#include "game_types.h"
#include "coduo_libm.h"
#include "coduo_int32_bits.h"
#include "coduo_native_x87.h"

#if EMULATE_X87
/* 80-bit matrix dots rounded to float: three lane products, plus an optional
 * translation term (D4). Used by the matrix-multiply family below. */
#define X87_D3(a, b, c, d, e, f)                                            \
    x87f_store_f32(x87f_add(                                                   \
        x87f_add(x87f_mul(x87f_load_f32(a), x87f_load_f32(b)),                \
                 x87f_mul(x87f_load_f32(c), x87f_load_f32(d))),               \
        x87f_mul(x87f_load_f32(e), x87f_load_f32(f))))
#define X87_D4(a, b, c, d, e, f, g)                                         \
    x87f_store_f32(x87f_add(                                                   \
        x87f_add(x87f_add(x87f_mul(x87f_load_f32(a), x87f_load_f32(b)),       \
                          x87f_mul(x87f_load_f32(c), x87f_load_f32(d))),      \
                 x87f_mul(x87f_load_f32(e), x87f_load_f32(f))),              \
        x87f_load_f32(g)))
/* first product, then translation: (((a*b) + t) + c*d) + e*f, 80-bit -> float. */
#define X87_TD4(t, a, b, c, d, e, f)                                        \
    x87f_store_f32(x87f_add(                                                   \
        x87f_add(x87f_add(x87f_mul(x87f_load_f32(a), x87f_load_f32(b)),       \
                          x87f_load_f32(t)),                                   \
                 x87f_mul(x87f_load_f32(c), x87f_load_f32(d))),              \
        x87f_mul(x87f_load_f32(e), x87f_load_f32(f))))
/* a 2x2 minor (a*b - c*d), kept unrounded in 80-bit for the caller. */
#define X87_MINOR(a, b, c, d)                                               \
    x87f_sub(x87f_mul(x87f_load_f32(a), x87f_load_f32(b)),                    \
             x87f_mul(x87f_load_f32(c), x87f_load_f32(d)))
/* angle helpers: (num * atan2(y,x))/pi in 80-bit -> float; sqrt of a 2D squared
 * sum through double64; and the +360 wrap. atan2/sqrt are libm calls left
 * native. num is a double constant (e.g. +/-DEGREES_PER_RADIAN). */
#define X87_ATAN2DEG(num, y, x)                                             \
    x87f_store_f32(x87f_div(                                                   \
        x87f_mul(x87f_load_f64(num),                                           \
                 x87f_load_f64(atan2((double)(y), (double)(x)))),            \
        x87f_load_f64(DOUBLE_PI)))
#define X87_HYPOT2(x, y)                                                    \
    (float)CoduoLibm_Sqrt(x87f_store_f64(                                                \
        x87f_add(x87f_mul(x87f_load_f32(x), x87f_load_f32(x)),               \
                 x87f_mul(x87f_load_f32(y), x87f_load_f32(y)))))
#define X87_WRAP360(v)                                                      \
    x87f_store_f32(                                                            \
        x87f_add(x87f_load_f32(v), x87f_load_f32(DEGREES_PER_CIRCLE)))
#endif

#define Q_RAND_MULTIPLIER 69069
#define Q_RANDOM_MASK 0xffff
#define Q_RANDOM_DENOMINATOR 65536.0f /* 2^16; original float32 0x47800000 */
#define LIBC_RAND_FLOAT_DENOMINATOR 2147483648.0f /* 2^31; original float32 0x4f000000 */
#define DEGREES_PER_CIRCLE 360.0f
#define DEGREES_PER_HALF_CIRCLE 180.0f
#define PI 3.1415927f /* pi rounded to float32; original float32 0x40490fdb */
#define DOUBLE_PI 3.141592653589793 /* pi rounded to double64; original double64 0x400921fb54442d18 */
#define DEGREES_PER_RADIAN 180.0f
#define DOUBLE_RADIANS_PER_DEGREE 0.017453292519943295 /* pi/180 rounded to double64; original double64 0x3f91df46a2529d39 */
#define RADIANS_PER_DEGREE 0.017453292f /* pi/180 rounded to float32; original float32 0x3c8efa35 */
#define DOUBLE_HALF_RADIANS_PER_DEGREE 0.008726646259971648 /* pi/360 rounded to double64; original double64 0x3f81df46a2529d39 */
#define HALF_RADIANS_PER_DEGREE 0.008726646f /* pi/360 rounded to float32; original float32 0x3c0efa35 */
#define ANGLE_SHORT_SCALE 182.04445f /* 65536/360 rounded to float32; original float32 0x43360b61 */
#define ANGLE_SHORT_TO_DEGREES 0.005493164f /* 360/65536 rounded to float32; original float32 0x3bb40000 */
#define NORMAL_LATLONG_SCALE 0.70833331f /* 255/360 rounded to float32 0x3f355555; the binary stores it widened to double64 0x3fe6aaaaa0000000 (.rodata 0x9dc20, fmul QWORD @0x3ebd3/0x3ec18) - value-identical, as GCC emits for a float literal in a double context */
#define Q_RSQRT_HALF 0.5f
#define Q_RSQRT_THREE_HALVES 1.5f
#define COLOR_BYTE_SCALE 255.0f
#define VECTOR_COMPARE_EPSILON 1.0000001e-06f /* original float32 0x358637be */
#define SHARED_RAND_SHIFT 17
#define SHARED_RAND_FLOAT_DENOMINATOR 32768.0f /* 2^15; original float32 0x47000000 */
#define MILLISECONDS_PER_SECOND 1000.0f
#define X87_FISTP_WORD_MIN (-32769.0L)
#define X87_FISTP_WORD_MAX 32768.0L
#define BYTE_SWAP_MIDDLE_BYTE_MASK 0x0000ff00u
#define FLOAT_SIGN_BIT_MASK 0x80000000u
#define FLOAT_ONE_BITS UINT32_C(0x3f800000) /* 1.0f */
#define COLOR_OPAQUE_ALPHA_MASK 0xff000000u

/* RECOVERED 0x5f3759df: Quake rsqrt magic value. */
static const uint32_t Q_RSQRT_MAGIC = 1597463007u;
/* RECOVERED 0x343fd: shared rand LCG multiplier. */
static const uint32_t SHARED_RAND_MULTIPLIER = 214013u;
/* RECOVERED 0x269ec3: shared rand LCG increment. */
static const uint32_t SHARED_RAND_INCREMENT = 2531011u;
#if EMULATE_X87
static const uint16_t X87_WORD_INTEGER_INDEFINITE = 32768u;
#endif
static const uint8_t NORMAL_LATLONG_NEGATIVE_Z_BYTE = 128u;

const vec3_t vec3_origin = {0.0f, 0.0f, 0.0f};

#if !EMULATE_X87
/* NOT_FROM_ORIGINAL_SOURCE: volatile carrier for the stock 0xbf800000
 * multiplication operand used by AngleVectors.  Modern GCC otherwise folds
 * `-1.0f * value` into FCHS even at -O0, which changes signaling-NaN behavior
 * from the original FMUL graph. */
static const volatile float game_compat_angle_vectors_negative_one = -1.0f;
#endif

static uint32_t shared_rand_seed;

static void SinCosFloat(float radians, float *sine, float *cosine);
static void SinCosDouble(double radians, double *sine, double *cosine);
static uint32_t game_compat_byte_swap32(uint32_t value);
static long double Common_FabsLongDouble(float value);
void MatrixMultiply(const float *lhs, const float *rhs, float *out);
void PerpendicularVector(float *dst, const float *src);
void ProjectPointOnPlane(float *dst, const float *point, const float *normal);

static int (*bigShortConverter)(short value);
static int (*littleShortConverter)(short value);
static int (*bigLongConverter)(int value);
static int (*littleLongConverter)(int value);
static qint64 (*bigLong64Converter)(qint64 value);
static qint64 (*littleLong64Converter)(qint64 value);
static float (*bigFloatConverter)(float value);
static float (*littleFloatConverter)(float value);

#if EMULATE_X87
/* NOT_FROM_ORIGINAL_SOURCE: shim variant that truncates the 80-bit value
 * directly (no extF80->long double
 * bridge). The range guard uses the double projection (the bounds are far from
 * any real lat/long, so the projection cannot change the guard); the truncation
 * itself is on the full 80-bit value via the shim's truncating store. */
static uint8_t game_compat_x87_fistp_word_low_byte_x87(x87f value)
{
    double projected = x87f_store_f64(value);

    if (!isfinite(projected) ||
        projected <= X87_FISTP_WORD_MIN ||
        projected >= X87_FISTP_WORD_MAX) {
        return (uint8_t)X87_WORD_INTEGER_INDEFINITE;
    }

    return (uint8_t)(uint16_t)(int16_t)x87f_store_i32_trunc(value);
}
#endif

/* NOT_FROM_ORIGINAL_SOURCE: local byteswap helper shared by recovered swap functions. */
static uint32_t game_compat_byte_swap32(uint32_t value)
{
    return (value << 24) |
           ((value & BYTE_SWAP_MIDDLE_BYTE_MASK) << 8) |
           ((value >> 8) & BYTE_SWAP_MIDDLE_BYTE_MASK) |
           (value >> 24);
}

/* VERIFIED_DECOMPILER(0x92c9c, a2c9c_ColorIndex.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x92c9c ColorIndex */
char ColorIndex(char value)
{
    uint8_t index = (uint8_t)value - (uint8_t)'0';

    if (index > 9) {
        index = 7;
    }
    return (char)index;
}

/* VERIFIED_DECOMPILER(0x92ccc, a2ccc_Com_Clamp.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x92ccc Com_Clamp */
float Com_Clamp(float min, float max, float value)
{
    if (value < min) {
        return min;
    }
    if (value > max) {
        return max;
    }
    return value;
}

/* VERIFIED_DECOMPILER(0x92ef4, a2ef4_BigShort.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x92ef4 BigShort */
int BigShort(short value)
{
    return (int)(int16_t)bigShortConverter(value);
}

/* VERIFIED_DECOMPILER(0x92f23, a2f23_BigLong.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x92f23 BigLong */
int BigLong(int value)
{
    return bigLongConverter(value);
}

/* VERIFIED_DECOMPILER(0x92f49, a2f49_BigLong64.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x92f49 BigLong64 */
qint64 BigLong64(qint64 value)
{
    return bigLong64Converter(value);
}

/* VERIFIED_DECOMPILER(0x92f92, a2f92_LittleLong64.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x92f92 LittleLong64 */
qint64 LittleLong64(qint64 value)
{
    return littleLong64Converter(value);
}

/* VERIFIED_DECOMPILER(0x92fdb, a2fdb_BigFloat.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x92fdb BigFloat */
float BigFloat(float value)
{
    return bigFloatConverter(value);
}

/* VERIFIED_DECOMPILER(0x93001, a3001_ShortSwap.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x93001 ShortSwap */
int ShortSwap(short value)
{
    uint16_t bits = (uint16_t)value;
    uint16_t swapped = (uint16_t)((bits << 8) | (bits >> 8));

    return (int)(int16_t)swapped;
}

/* VERIFIED_DECOMPILER(0x93038, a3038_ShortNoSwap.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x93038 ShortNoSwap */
int ShortNoSwap(short value)
{
    return (int)value;
}

/* VERIFIED_DECOMPILER(0x9304b, a304b_LongSwap.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x9304b LongSwap */
int LongSwap(int value)
{
    return coduo_int32_from_bits(
        game_compat_byte_swap32(coduo_int32_bits(value)));
}

/* VERIFIED_DECOMPILER(0x930a7, a30a7_LongNoSwap.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x930a7 LongNoSwap */
int LongNoSwap(int value)
{
    return value;
}

/* VERIFIED_DECOMPILER(0x930af, a30af_Long64Swap.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x930af Long64Swap */
qint64 Long64Swap(qint64 value)
{
    qint64 swapped;

    swapped.b0 = value.b7;
    swapped.b1 = value.b6;
    swapped.b2 = value.b5;
    swapped.b3 = value.b4;
    swapped.b4 = value.b3;
    swapped.b5 = value.b2;
    swapped.b6 = value.b1;
    swapped.b7 = value.b0;
    return swapped;
}

/* VERIFIED_DECOMPILER(0x9310d, a310d_Long64NoSwap.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x9310d Long64NoSwap */
qint64 Long64NoSwap(qint64 value)
{
    return value;
}

/* VERIFIED_DECOMPILER(0x93131, a3131_FloatSwap.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x93131 FloatSwap */
float FloatSwap(float value)
{
    uint32_t bits;
    float swapped;

    memcpy(&bits, &value, sizeof(bits));
    bits = game_compat_byte_swap32(bits);
    memcpy(&swapped, &bits, sizeof(swapped));
    return swapped;
}

/* VERIFIED_DECOMPILER(0x93164, a3164_FloatNoSwap.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x93164 FloatNoSwap */
float FloatNoSwap(float value)
{
    return value;
}

/* VERIFIED_DECOMPILER(0x93175, a3175_Swap_Init.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x93175 Swap_Init */
void Swap_Init(void)
{
    uint16_t endianProbe = UINT16_C(1);

    if (*(const uint8_t *)(const void *)&endianProbe == UINT8_C(1)) {
        bigShortConverter = ShortSwap;
        littleShortConverter = ShortNoSwap;
        bigLongConverter = LongSwap;
        littleLongConverter = LongNoSwap;
        bigLong64Converter = Long64Swap;
        littleLong64Converter = Long64NoSwap;
        bigFloatConverter = FloatSwap;
        littleFloatConverter = FloatNoSwap;
    } else {
        bigShortConverter = ShortNoSwap;
        littleShortConverter = ShortSwap;
        bigLongConverter = LongNoSwap;
        littleLongConverter = LongSwap;
        bigLong64Converter = Long64NoSwap;
        littleLong64Converter = Long64Swap;
        bigFloatConverter = FloatNoSwap;
        littleFloatConverter = FloatSwap;
    }
}

/* VERIFIED_DECOMPILER(0x39960, 49960_Q_rand.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x39960 Q_rand */
int Q_rand(int *seed)
{
    *seed = coduo_int32_from_bits(
        (uint32_t)*seed * (uint32_t)Q_RAND_MULTIPLIER + UINT32_C(1));
    return *seed;
}

/* VERIFIED_DECOMPILER(0x3997b, 4997b_Q_random.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x3997b Q_random */
float Q_random(int *seed)
{
    /* 0x3999e: fild keeps the masked value exact in x87; no float32 cast
     * rounding before the divide. */
    return (long double)(Q_rand(seed) & Q_RANDOM_MASK) /
           Q_RANDOM_DENOMINATOR;
}

/* VERIFIED_DECOMPILER(0x399b3, 499b3_Q_crandom.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x399b3 Q_crandom */
float Q_crandom(int *seed)
{
    /* 0x399d0..0x399d8: the centered value is never spilled to float32;
     * the doubling adds the x87 register to itself. */
    long double centered = Q_random(seed) - 0.5f;

    return centered + centered;
}

/* VERIFIED_DECOMPILER(0x399e0, 499e0_gunrandom.c, VERIFY-WAVE4-COMMON-MATH-01-2026-06-17): DATAFLOW_VERIFIED. */
/* 0x399e0 gunrandom */
void gunrandom(float *x, float *y)
{
    /* 0x399f8/0x39a18: fild keeps rand() exact in x87; no float32 cast
     * rounding before the divides. */
    float degrees = ((long double)rand() / LIBC_RAND_FLOAT_DENOMINATOR) *
                    DEGREES_PER_CIRCLE;
    float radius = (long double)rand() / LIBC_RAND_FLOAT_DENOMINATOR;
    /* 0x39a3b/0x39a43: machine multiplies by DOUBLE pi (.rodata 0x9d9c0)
     * and divides by double 180.0, then uses one fsincos (helper 0x3f464)
     * for both outputs. */
    float radians =
        (float)(((double)degrees * DOUBLE_PI) / 180.0);
    float sine;
    float cosine;

    SinCosFloat(radians, &sine, &cosine);
    *x = radius * cosine;
    *y = radius * sine;
}

/* VERIFIED_DECOMPILER(0x39a6f, 49a6f_Q_rsqrt.c, VERIFY-WAVE4-COMMON-MATH-02-2026-06-17): DATAFLOW_VERIFIED - raw float-bit load/store, 0x5f3759df seed, arithmetic shift, Newton step, and float return checked; objdump 0x39a96..0x39ab6 confirms bit reinterpretation where decompiler text prints a misleading cast. */
/* 0x39a6f Q_rsqrt */
float Q_rsqrt(float value)
{
    uint32_t bits;
    float estimate;

#if EMULATE_X87
    /* half = value*0.5 rounded to float; the Newton step
     * estimate*(1.5 - (half*estimate)*estimate) is 80-bit rounded to float. */
    float half = x87f_store_f32(
        x87f_mul(x87f_load_f32(value), x87f_load_f32(Q_RSQRT_HALF)));

    memcpy(&bits, &value, sizeof(bits));
    bits = Q_RSQRT_MAGIC - coduo_int32_sar_bits(bits, 1U);
    memcpy(&estimate, &bits, sizeof(estimate));

    return x87f_store_f32(x87f_mul(
        x87f_load_f32(estimate),
        x87f_sub(x87f_load_f32(Q_RSQRT_THREE_HALVES),
                 x87f_mul(x87f_mul(x87f_load_f32(half),
                                   x87f_load_f32(estimate)),
                          x87f_load_f32(estimate)))));
#else
    float half = value * Q_RSQRT_HALF;

    memcpy(&bits, &value, sizeof(bits));
    bits = Q_RSQRT_MAGIC - coduo_int32_sar_bits(bits, 1U);
    memcpy(&estimate, &bits, sizeof(estimate));

    return estimate *
           (Q_RSQRT_THREE_HALVES - half * estimate * estimate);
#endif
}

/* VERIFIED_DECOMPILER(0x39b03, 49b03_Q_acos.c, VERIFY-WAVE4-COMMON-MATH-02-2026-06-17): DATAFLOW_VERIFIED - acos call, float32 local, upper pi clamp, lower negative-pi branch returning positive pi, and x87 float return checked. */
/* 0x39b03 Q_acos */
float Q_acos(float value)
{
    float angle = (float)CoduoLibm_Acos((double)value);

    /* 0x39b26/0x39b45: the clamp compares load QWORD double64 pi (.rodata
     * 0x9d9d8/0x9d9e8), not the float32 pi that is returned (0x9d9e0). */
    if (angle > DOUBLE_PI) {
        return PI;
    }
    if (angle < -DOUBLE_PI) {
        return PI;
    }
    return angle;
}

/* VERIFIED_DECOMPILER(0x39d64, 49d64__DotProduct.c, VERIFY-WAVE4-COMMON-MATH-02-2026-06-17): DATAFLOW_VERIFIED - three-lane dot product and float/x87 return checked. */
/* 0x39d64 _DotProduct */
float _DotProduct(const float *a, const float *b)
{
#if EMULATE_X87
    /* 80-bit three-term dot rounded to float at the return. */
    return x87f_store_f32(x87f_add(
        x87f_add(x87f_mul(x87f_load_f32(a[0]), x87f_load_f32(b[0])),
                 x87f_mul(x87f_load_f32(a[1]), x87f_load_f32(b[1]))),
        x87f_mul(x87f_load_f32(a[2]), x87f_load_f32(b[2]))));
#else
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
#endif
}

/* VERIFIED_DECOMPILER(0x39ed9, 49ed9_VectorCompareEpsilon.c, VERIFY-WAVE4-COMMON-MATH-02-2026-06-17): DATAFLOW_VERIFIED - three-axis loop, squared delta threshold 1.0000001e-06, early false, and true after axis 2 checked. */
/* 0x39ed9 VectorCompareEpsilon */
int VectorCompareEpsilon(const float *a, const float *b)
{
    for (int axis = 0; axis < 3; axis++) {
        /* 0x39f15..0x39f3b: the delta is computed twice in x87 registers
         * and squared without a float32 spill. */
#if EMULATE_X87
        x87f d = x87f_sub(x87f_load_f32(a[axis]), x87f_load_f32(b[axis]));
        if (x87f_lt(x87f_load_f32(VECTOR_COMPARE_EPSILON),
                    x87f_mul(d, d))) {
            return 0;
        }
#else
        if ((a[axis] - b[axis]) * (a[axis] - b[axis]) >
            VECTOR_COMPARE_EPSILON) {
            return 0;
        }
#endif
    }

    return 1;
}

/* VERIFIED_DECOMPILER(0x39f6f, 49f6f__VectorLength.c, VERIFY-WAVE4-COMMON-MATH-02-2026-06-17): DATAFLOW_VERIFIED - 3D squared sum, CoduoLibm_Sqrt(double), float cast, and x87 return checked. */
/* 0x39f6f _VectorLength */
float _VectorLength(const float *v)
{
    /* 0x39faf: the squared sum is rounded straight to double64 for the sqrt
     * argument; no float32 spill of the sum. */
#if EMULATE_X87
    return (float)CoduoLibm_Sqrt(x87f_store_f64(x87f_add(
        x87f_add(x87f_mul(x87f_load_f32(v[0]), x87f_load_f32(v[0])),
                 x87f_mul(x87f_load_f32(v[1]), x87f_load_f32(v[1]))),
        x87f_mul(x87f_load_f32(v[2]), x87f_load_f32(v[2])))));
#else
    return (float)CoduoLibm_Sqrt((double)(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]));
#endif
}

/* VERIFIED_DECOMPILER(0x39fc9, 49fc9_VectorDistance.c, VERIFY-WAVE4-COMMON-MATH-02-2026-06-17): DATAFLOW_VERIFIED - b-a delta order, 3D squared sum, CoduoLibm_Sqrt(double), float cast, and x87 return checked. */
/* 0x39fc9 VectorDistance */
float VectorDistance(const float *a, const float *b)
{
    float delta0 = b[0] - a[0];
    float delta1 = b[1] - a[1];
    float delta2 = b[2] - a[2];

    /* 0x3a024: the squared sum is rounded straight to double64 for the sqrt
     * argument; no float32 spill of the sum. */
#if EMULATE_X87
    return (float)CoduoLibm_Sqrt(x87f_store_f64(x87f_add(
        x87f_add(x87f_mul(x87f_load_f32(delta0), x87f_load_f32(delta0)),
                 x87f_mul(x87f_load_f32(delta1), x87f_load_f32(delta1))),
        x87f_mul(x87f_load_f32(delta2), x87f_load_f32(delta2)))));
#else
    return (float)CoduoLibm_Sqrt((double)(delta0 * delta0 + delta1 * delta1 +
                                delta2 * delta2));
#endif
}

/* VERIFIED_DECOMPILER(0x3a03e, 4a03e_VectorDistanceSquared.c, VERIFY-WAVE4-COMMON-MATH-02-2026-06-17): DATAFLOW_VERIFIED - b-a delta order and 3D squared sum checked. */
/* 0x3a03e VectorDistanceSquared */
float VectorDistanceSquared(const float *a, const float *b)
{
    float delta0 = b[0] - a[0];
    float delta1 = b[1] - a[1];
    float delta2 = b[2] - a[2];

#if EMULATE_X87
    /* deltas are single-op; the squared sum is 80-bit rounded to float at the
     * float return. */
    return x87f_store_f32(x87f_add(
        x87f_add(x87f_mul(x87f_load_f32(delta0), x87f_load_f32(delta0)),
                 x87f_mul(x87f_load_f32(delta1), x87f_load_f32(delta1))),
        x87f_mul(x87f_load_f32(delta2), x87f_load_f32(delta2))));
#else
    return delta0 * delta0 + delta1 * delta1 + delta2 * delta2;
#endif
}

/* VERIFIED_DECOMPILER(0x3a08f, 4a08f_VectorDistance2D.c, VERIFY-WAVE4-COMMON-MATH-02-2026-06-17): DATAFLOW_VERIFIED - b-a XY delta order, squared sum, CoduoLibm_Sqrt(double), float cast, and x87 return checked. */
/* 0x3a08f VectorDistance2D */
float VectorDistance2D(const float *a, const float *b)
{
    float delta0 = b[0] - a[0];
    float delta1 = b[1] - a[1];

    /* 0x3a0cf: the squared sum is rounded straight to double64 for the sqrt
     * argument; no float32 spill of the sum. */
#if EMULATE_X87
    return (float)CoduoLibm_Sqrt(x87f_store_f64(
        x87f_add(x87f_mul(x87f_load_f32(delta0), x87f_load_f32(delta0)),
                 x87f_mul(x87f_load_f32(delta1), x87f_load_f32(delta1)))));
#else
    return (float)CoduoLibm_Sqrt((double)(delta0 * delta0 + delta1 * delta1));
#endif
}

/* VERIFIED_DECOMPILER(0x3a0e9, 4a0e9_VectorDistanceSquared2D.c, VERIFY-WAVE4-COMMON-MATH-02-2026-06-17): DATAFLOW_VERIFIED - b-a XY delta order and squared sum checked. */
/* 0x3a0e9 VectorDistanceSquared2D */
float VectorDistanceSquared2D(const float *a, const float *b)
{
    float delta0 = b[0] - a[0];
    float delta1 = b[1] - a[1];

#if EMULATE_X87
    return x87f_store_f32(
        x87f_add(x87f_mul(x87f_load_f32(delta0), x87f_load_f32(delta0)),
                 x87f_mul(x87f_load_f32(delta1), x87f_load_f32(delta1))));
#else
    return delta0 * delta0 + delta1 * delta1;
#endif
}

/* VERIFIED_DECOMPILER(0x3a11f, 4a11f_CrossProduct.c, VERIFY-WAVE4-COMMON-MATH-02-2026-06-17): DATAFLOW_VERIFIED - all three cross-product lane stores checked. */
/* 0x3a11f CrossProduct */
void CrossProduct(const float *a, const float *b, float *out)
{
#if EMULATE_X87
    /* each lane is an 80-bit (mul - mul) rounded to float. */
    out[0] = x87f_store_f32(
        x87f_sub(x87f_mul(x87f_load_f32(a[1]), x87f_load_f32(b[2])),
                 x87f_mul(x87f_load_f32(a[2]), x87f_load_f32(b[1]))));
    out[1] = x87f_store_f32(
        x87f_sub(x87f_mul(x87f_load_f32(a[2]), x87f_load_f32(b[0])),
                 x87f_mul(x87f_load_f32(a[0]), x87f_load_f32(b[2]))));
    out[2] = x87f_store_f32(
        x87f_sub(x87f_mul(x87f_load_f32(a[0]), x87f_load_f32(b[1])),
                 x87f_mul(x87f_load_f32(a[1]), x87f_load_f32(b[0]))));
#else
    out[0] = a[1] * b[2] - a[2] * b[1];
    out[1] = a[2] * b[0] - a[0] * b[2];
    out[2] = a[0] * b[1] - a[1] * b[0];
#endif
}

/* VERIFIED_DECOMPILER(0x3a193, 4a193_CrossProductUp.c, VERIFY-WAVE4-COMMON-MATH-02-2026-06-17): DATAFLOW_VERIFIED - y, sign-flipped x via xor 0x80000000, and zero z stores checked. */
/* 0x3a193 CrossProductUp */
void CrossProductUp(const float *v, float *out)
{
    uint32_t bits;

    /* Stock performs dword copies/sign toggles, not floating-point loads. */
    memcpy(&bits, &v[1], sizeof(bits));
    memcpy(&out[0], &bits, sizeof(bits));
    memcpy(&bits, &v[0], sizeof(bits));
    bits ^= FLOAT_SIGN_BIT_MASK;
    memcpy(&out[1], &bits, sizeof(bits));
    bits = 0;
    memcpy(&out[2], &bits, sizeof(bits));
}

/* VERIFIED_DECOMPILER(0x3a1c3, 4a1c3_VectorNormalize.c, VERIFY-WAVE4-COMMON-MATH-02-2026-06-17): DATAFLOW_VERIFIED - 3D length, NAN-aware nonzero branch via != 0.0f, inverse scale stores, and float/x87 return checked. */
/* 0x3a1c3 VectorNormalize */
float VectorNormalize(float *v)
{
    /* 0x3a203/0x3a211: machine rounds the squared sum to float32 before the
     * sqrt call, then rounds the sqrt result into the same slot. */
#if EMULATE_X87
    float lengthSquared = x87f_store_f32(x87f_add(
        x87f_add(x87f_mul(x87f_load_f32(v[0]), x87f_load_f32(v[0])),
                 x87f_mul(x87f_load_f32(v[1]), x87f_load_f32(v[1]))),
        x87f_mul(x87f_load_f32(v[2]), x87f_load_f32(v[2]))));
    float length = (float)CoduoLibm_Sqrt((double)lengthSquared);

    if (length != 0.0f) {
        float inverse = x87f_store_f32(
            x87f_div(x87f_load_f32(1.0f), x87f_load_f32(length)));

        v[0] = x87f_store_f32(x87f_mul(x87f_load_f32(v[0]),
                                       x87f_load_f32(inverse)));
        v[1] = x87f_store_f32(x87f_mul(x87f_load_f32(v[1]),
                                       x87f_load_f32(inverse)));
        v[2] = x87f_store_f32(x87f_mul(x87f_load_f32(v[2]),
                                       x87f_load_f32(inverse)));
    }

    return length;
#else
    float lengthSquared = v[0] * v[0] + v[1] * v[1] + v[2] * v[2];
    float length = (float)CoduoLibm_Sqrt((double)lengthSquared);

    if (length != 0.0f) {
        float inverse = 1.0f / length;

        v[0] *= inverse;
        v[1] *= inverse;
        v[2] *= inverse;
    }

    return length;
#endif
}

/* VERIFIED_DECOMPILER(0x3a278, 4a278_VectorNormalize2D.c, VERIFY-WAVE4-COMMON-MATH-02-2026-06-17): DATAFLOW_VERIFIED - XY length, NAN-aware nonzero branch via != 0.0f, inverse scale stores, and float/x87 return checked. */
/* 0x3a278 VectorNormalize2D */
float VectorNormalize2D(float *v)
{
    /* 0x3a2a6/0x3a2b4: machine rounds the squared sum to float32 before the
     * sqrt call, then rounds the sqrt result into the same slot. */
#if EMULATE_X87
    float lengthSquared = x87f_store_f32(
        x87f_add(x87f_mul(x87f_load_f32(v[0]), x87f_load_f32(v[0])),
                 x87f_mul(x87f_load_f32(v[1]), x87f_load_f32(v[1]))));
    float length = (float)CoduoLibm_Sqrt((double)lengthSquared);

    if (length != 0.0f) {
        float inverse = x87f_store_f32(
            x87f_div(x87f_load_f32(1.0f), x87f_load_f32(length)));

        v[0] = x87f_store_f32(x87f_mul(x87f_load_f32(v[0]),
                                       x87f_load_f32(inverse)));
        v[1] = x87f_store_f32(x87f_mul(x87f_load_f32(v[1]),
                                       x87f_load_f32(inverse)));
    }

    return length;
#else
    float lengthSquared = v[0] * v[0] + v[1] * v[1];
    float length = (float)CoduoLibm_Sqrt((double)lengthSquared);

    if (length != 0.0f) {
        float inverse = 1.0f / length;

        v[0] *= inverse;
        v[1] *= inverse;
    }

    return length;
#endif
}

/* VERIFIED_DECOMPILER(0x3a308, 4a308_VectorNormalize4D.c, VERIFY-WAVE4-COMMON-MATH-02-2026-06-17): DATAFLOW_VERIFIED - 4D length, NAN-aware nonzero branch via != 0.0f, inverse scale stores, and float/x87 return checked. */
/* 0x3a308 VectorNormalize4D */
float VectorNormalize4D(float *v)
{
    /* 0x3a35a/0x3a368: machine rounds the squared sum to float32 before the
     * sqrt call, then rounds the sqrt result into the same slot. */
#if EMULATE_X87
    x87f ls = x87f_add(x87f_mul(x87f_load_f32(v[0]), x87f_load_f32(v[0])),
                       x87f_mul(x87f_load_f32(v[1]), x87f_load_f32(v[1])));
    ls = x87f_add(ls, x87f_mul(x87f_load_f32(v[2]), x87f_load_f32(v[2])));
    ls = x87f_add(ls, x87f_mul(x87f_load_f32(v[3]), x87f_load_f32(v[3])));
    float lengthSquared = x87f_store_f32(ls);
    float length = (float)CoduoLibm_Sqrt((double)lengthSquared);

    if (length != 0.0f) {
        float inverse = x87f_store_f32(
            x87f_div(x87f_load_f32(1.0f), x87f_load_f32(length)));

        v[0] = x87f_store_f32(x87f_mul(x87f_load_f32(v[0]),
                                       x87f_load_f32(inverse)));
        v[1] = x87f_store_f32(x87f_mul(x87f_load_f32(v[1]),
                                       x87f_load_f32(inverse)));
        v[2] = x87f_store_f32(x87f_mul(x87f_load_f32(v[2]),
                                       x87f_load_f32(inverse)));
        v[3] = x87f_store_f32(x87f_mul(x87f_load_f32(v[3]),
                                       x87f_load_f32(inverse)));
    }

    return length;
#else
    float lengthSquared = v[0] * v[0] + v[1] * v[1] +
                          v[2] * v[2] + v[3] * v[3];
    float length = (float)CoduoLibm_Sqrt((double)lengthSquared);

    if (length != 0.0f) {
        float inverse = 1.0f / length;

        v[0] *= inverse;
        v[1] *= inverse;
        v[2] *= inverse;
        v[3] *= inverse;
    }

    return length;
#endif
}

/* VERIFIED_DECOMPILER(0x3a3e2, 4a3e2_VectorNormalizeFast.c, VERIFY-WAVE4-COMMON-MATH-02-2026-06-17): DATAFLOW_VERIFIED - squared 3D sum, Q_rsqrt call, float inverse, and three scale stores checked. */
/* 0x3a3e2 VectorNormalizeFast */
void VectorNormalizeFast(float *v)
{
#if EMULATE_X87
    float inverse = Q_rsqrt(x87f_store_f32(x87f_add(
        x87f_add(x87f_mul(x87f_load_f32(v[0]), x87f_load_f32(v[0])),
                 x87f_mul(x87f_load_f32(v[1]), x87f_load_f32(v[1]))),
        x87f_mul(x87f_load_f32(v[2]), x87f_load_f32(v[2])))));

    v[0] = x87f_store_f32(x87f_mul(x87f_load_f32(v[0]), x87f_load_f32(inverse)));
    v[1] = x87f_store_f32(x87f_mul(x87f_load_f32(v[1]), x87f_load_f32(inverse)));
    v[2] = x87f_store_f32(x87f_mul(x87f_load_f32(v[2]), x87f_load_f32(inverse)));
#else
    float inverse = Q_rsqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);

    v[0] *= inverse;
    v[1] *= inverse;
    v[2] *= inverse;
#endif
}

/* VERIFIED_DECOMPILER(0x3a466, 4a466_VectorNormalize2.c, VERIFY-WAVE4-COMMON-MATH-02-2026-06-17): DATAFLOW_VERIFIED - 3D length, NAN-aware nonzero branch via != 0.0f, output scale stores, zero fallback stores, and float/x87 return checked. */
/* 0x3a466 VectorNormalize2 */
float VectorNormalize2(const float *in, float *out)
{
    /* 0x3a4a7/0x3a4b5: machine rounds the squared sum to float32 before the
     * sqrt call, then rounds the sqrt result into the same slot. */
#if EMULATE_X87
    float lengthSquared = x87f_store_f32(x87f_add(
        x87f_add(x87f_mul(x87f_load_f32(in[0]), x87f_load_f32(in[0])),
                 x87f_mul(x87f_load_f32(in[1]), x87f_load_f32(in[1]))),
        x87f_mul(x87f_load_f32(in[2]), x87f_load_f32(in[2]))));
    float length = (float)CoduoLibm_Sqrt((double)lengthSquared);

    if (length != 0.0f) {
        float inverse = x87f_store_f32(
            x87f_div(x87f_load_f32(1.0f), x87f_load_f32(length)));

        out[0] = x87f_store_f32(x87f_mul(x87f_load_f32(in[0]),
                                         x87f_load_f32(inverse)));
        out[1] = x87f_store_f32(x87f_mul(x87f_load_f32(in[1]),
                                         x87f_load_f32(inverse)));
        out[2] = x87f_store_f32(x87f_mul(x87f_load_f32(in[2]),
                                         x87f_load_f32(inverse)));
    } else {
        out[0] = 0.0f;
        out[1] = 0.0f;
        out[2] = 0.0f;
    }

    return length;
#else
    float lengthSquared = in[0] * in[0] + in[1] * in[1] + in[2] * in[2];
    float length = (float)CoduoLibm_Sqrt((double)lengthSquared);

    if (length != 0.0f) {
        float inverse = 1.0f / length;

        out[0] = in[0] * inverse;
        out[1] = in[1] * inverse;
        out[2] = in[2] * inverse;
    } else {
        out[0] = 0.0f;
        out[1] = 0.0f;
        out[2] = 0.0f;
    }

    return length;
#endif
}

/* VERIFIED_DECOMPILER(0x3a5c3, 4a5c3_VectorMax.c, VERIFY-WAVE4-COMMON-MATH-02-2026-06-17): DATAFLOW_VERIFIED - first-three-lane max comparisons and float/x87 return checked. */
/* 0x3a5c3 VectorMax */
float VectorMax(const float *v)
{
    float max = v[0];

    if (!(v[1] <= max)) {
        max = v[1];
    }
    if (!(v[2] <= max)) {
        max = v[2];
    }

    return max;
}

/* VERIFIED_DECOMPILER(0x3a62a, 4a62a_VectorRotate.c, VERIFY-WAVE4-COMMON-MATH-02-2026-06-17): DATAFLOW_VERIFIED - row-vector multiply by three matrix columns and output lane stores checked. */
/* 0x3a62a VectorRotate */
void VectorRotate(const float *in, const float *matrix, float *out)
{
#if EMULATE_X87
    out[0] = x87f_store_f32(x87f_add(
        x87f_add(x87f_mul(x87f_load_f32(in[0]), x87f_load_f32(matrix[0])),
                 x87f_mul(x87f_load_f32(in[1]), x87f_load_f32(matrix[1]))),
        x87f_mul(x87f_load_f32(in[2]), x87f_load_f32(matrix[2]))));
    out[1] = x87f_store_f32(x87f_add(
        x87f_add(x87f_mul(x87f_load_f32(in[0]), x87f_load_f32(matrix[3])),
                 x87f_mul(x87f_load_f32(in[1]), x87f_load_f32(matrix[4]))),
        x87f_mul(x87f_load_f32(in[2]), x87f_load_f32(matrix[5]))));
    out[2] = x87f_store_f32(x87f_add(
        x87f_add(x87f_mul(x87f_load_f32(in[0]), x87f_load_f32(matrix[6])),
                 x87f_mul(x87f_load_f32(in[1]), x87f_load_f32(matrix[7]))),
        x87f_mul(x87f_load_f32(in[2]), x87f_load_f32(matrix[8]))));
#else
    out[0] = in[0] * matrix[0] + in[1] * matrix[1] + in[2] * matrix[2];
    out[1] = in[0] * matrix[3] + in[1] * matrix[4] + in[2] * matrix[5];
    out[2] = in[0] * matrix[6] + in[1] * matrix[7] + in[2] * matrix[8];
#endif
}

/* VERIFIED_DECOMPILER(0x3a6d4, 4a6d4_RotatePointAroundVector.c, VERIFY-WAVE4-COMMON-MATH-03-2026-06-17): DATAFLOW_VERIFIED - axis-basis matrix construction, z-rotation sin/cos slots, matrix multiply order, and extracted VectorRotate loop checked. */
/* 0x3a6d4 RotatePointAroundVector */
void RotatePointAroundVector(float *dst, const float *dir, const float *point,
                             float degrees)
{
    uint32_t bits;
    vec3_t savedDir;
    vec3_t right;
    vec3_t up;
    float m[9];
    float im[9];
    float zrot[9];
    float tmp[9];
    float rot[9];
    float radians;

    /* 0x3a6ea..0x3a70b snapshots all three direction lanes before the first
     * call.  Later basis construction reads this snapshot, not dir. */
    memcpy(&savedDir[0], &dir[0], sizeof(bits));
    memcpy(&savedDir[1], &dir[1], sizeof(bits));
    memcpy(&savedDir[2], &dir[2], sizeof(bits));
    PerpendicularVector(right, dir);
    CrossProduct(right, savedDir, up);

    memcpy(&m[0], &right[0], sizeof(bits));
    memcpy(&m[1], &up[0], sizeof(bits));
    memcpy(&m[2], &savedDir[0], sizeof(bits));
    memcpy(&m[3], &right[1], sizeof(bits));
    memcpy(&m[4], &up[1], sizeof(bits));
    memcpy(&m[5], &savedDir[1], sizeof(bits));
    memcpy(&m[6], &right[2], sizeof(bits));
    memcpy(&m[7], &up[2], sizeof(bits));
    memcpy(&m[8], &savedDir[2], sizeof(bits));

    /* 0x3a799..0x3a7d4 copies m wholesale, then overwrites the six
     * off-diagonal lanes needed for the transposed inverse basis. */
    memcpy(im, m, sizeof(im));
    memcpy(&im[1], &right[1], sizeof(bits));
    memcpy(&im[2], &right[2], sizeof(bits));
    memcpy(&im[3], &up[0], sizeof(bits));
    memcpy(&im[5], &up[2], sizeof(bits));
    memcpy(&im[6], &savedDir[0], sizeof(bits));
    memcpy(&im[7], &savedDir[1], sizeof(bits));

    memset(zrot, 0, sizeof(zrot));
    zrot[0] = 1.0f;
    zrot[4] = 1.0f;
    zrot[8] = 1.0f;
    /* 0x3a80d/0x3a815: machine uses DOUBLE pi (.rodata 0x9da18) and
     * double 180.0 for the degrees->radians conversion. */
#if EMULATE_X87
    radians = x87f_store_f32(x87f_div(
        x87f_mul(x87f_load_f32(degrees), x87f_load_f64(DOUBLE_PI)),
        x87f_load_f64(180.0)));
#else
    radians = (float)(((double)degrees * DOUBLE_PI) / 180.0);
#endif
    SinCosFloat(radians, &zrot[1], &zrot[0]);
    memcpy(&bits, &zrot[1], sizeof(bits));
    bits ^= FLOAT_SIGN_BIT_MASK;
    memcpy(&zrot[3], &bits, sizeof(bits));
    memcpy(&bits, &zrot[0], sizeof(bits));
    memcpy(&zrot[4], &bits, sizeof(bits));

    MatrixMultiply(m, zrot, tmp);
    MatrixMultiply(tmp, im, rot);
    VectorRotate(point, rot, dst);
}

/* VERIFIED_DECOMPILER(0x3a94f, 4a94f_RotateAroundDirection.c, VERIFY-WAVE4-COMMON-MATH-03-2026-06-17): DATAFLOW_VERIFIED - perpendicular axis write, nonzero/NaN yaw branch, local right copy, rotate call, and final CrossProduct checked. */
/* 0x3a94f RotateAroundDirection */
void RotateAroundDirection(float *axis, float yaw)
{
    PerpendicularVector(&axis[3], axis);
    if (yaw != 0.0f) {
        vec3_t right;

        memcpy(&right[0], &axis[3], sizeof(right[0]));
        memcpy(&right[1], &axis[4], sizeof(right[1]));
        memcpy(&right[2], &axis[5], sizeof(right[2]));
        RotatePointAroundVector(&axis[3], axis, right, yaw);
    }
    CrossProduct(axis, &axis[3], &axis[6]);
}

/* VERIFIED_DECOMPILER(0x3a9f5, 4a9f5_MakeNormalVectors.c, VERIFY-WAVE4-COMMON-MATH-03-2026-06-17): DATAFLOW_VERIFIED - right-vector seed order, projection subtraction, normalization call, and CrossProduct argument order checked. */
/* 0x3a9f5 MakeNormalVectors */
void MakeNormalVectors(const float *forward, float *right, float *up)
{
    uint32_t bits;
    float dot;

    memcpy(&bits, &forward[0], sizeof(bits));
    bits ^= FLOAT_SIGN_BIT_MASK;
    memcpy(&right[1], &bits, sizeof(bits));
    memcpy(&bits, &forward[1], sizeof(bits));
    memcpy(&right[2], &bits, sizeof(bits));
    memcpy(&bits, &forward[2], sizeof(bits));
    memcpy(&right[0], &bits, sizeof(bits));

#if EMULATE_X87
    dot = x87f_store_f32(x87f_add(
        x87f_add(x87f_mul(x87f_load_f32(right[0]), x87f_load_f32(forward[0])),
                 x87f_mul(x87f_load_f32(right[1]), x87f_load_f32(forward[1]))),
        x87f_mul(x87f_load_f32(right[2]), x87f_load_f32(forward[2]))));

    right[0] = x87f_store_f32(x87f_add(
        x87f_mul(x87f_neg(x87f_load_f32(dot)), x87f_load_f32(forward[0])),
        x87f_load_f32(right[0])));
    right[1] = x87f_store_f32(x87f_add(
        x87f_mul(x87f_neg(x87f_load_f32(dot)), x87f_load_f32(forward[1])),
        x87f_load_f32(right[1])));
    right[2] = x87f_store_f32(x87f_add(
        x87f_mul(x87f_neg(x87f_load_f32(dot)), x87f_load_f32(forward[2])),
        x87f_load_f32(right[2])));
#else
    dot = right[0] * forward[0] +
          right[1] * forward[1] +
          right[2] * forward[2];

    /* 0x3aa77..0x3aacc uses (-dot)*forward + right in this order. */
    right[0] = (-dot) * forward[0] + right[0];
    right[1] = (-dot) * forward[1] + right[1];
    right[2] = (-dot) * forward[2] + right[2];
#endif

    VectorNormalize(right);
    CrossProduct(right, forward, up);
}

/* VERIFIED_DECOMPILER(0x3aafb, 4aafb_vectoyaw.c, VERIFY-WAVE4-COMMON-MATH-03-2026-06-17): DATAFLOW_VERIFIED - zero-vector branch, atan2 argument order, float local conversion, negative wrap, and return checked. */
/* 0x3aafb vectoyaw */
float vectoyaw(const float *vec)
{
    float yaw;

    if (vec[1] == 0.0f && vec[0] == 0.0f) {
        yaw = 0.0f;
    } else {
#if EMULATE_X87
        /* (deg-per-rad * atan2)/pi in 80-bit rounded to float; +360 wrap in
         * 80-bit. atan2 is a libm call left native. */
        yaw = x87f_store_f32(x87f_div(
            x87f_mul(x87f_load_f64(DEGREES_PER_RADIAN),
                     x87f_load_f64(atan2((double)vec[1], (double)vec[0]))),
            x87f_load_f64(DOUBLE_PI)));
        if (yaw < 0.0f) {
            yaw = x87f_store_f32(x87f_add(x87f_load_f32(yaw),
                                          x87f_load_f32(DEGREES_PER_CIRCLE)));
        }
#else
        yaw = (float)((DEGREES_PER_RADIAN * atan2((double)vec[1],
                                                     (double)vec[0])) /
                      DOUBLE_PI);
        if (yaw < 0.0f) {
            yaw += DEGREES_PER_CIRCLE;
        }
#endif
    }

    return yaw;
}

/* VERIFIED_DECOMPILER(0x3aba4, 4aba4_vectosignedyaw.c, VERIFY-WAVE4-COMMON-MATH-03-2026-06-17): DATAFLOW_VERIFIED - zero-vector branch, atan2 argument order, signed no-wrap behavior, and return checked. */
/* 0x3aba4 vectosignedyaw */
float vectosignedyaw(const float *vec)
{
    if (vec[1] == 0.0f && vec[0] == 0.0f) {
        return 0.0f;
    }

#if EMULATE_X87
    return X87_ATAN2DEG(DEGREES_PER_RADIAN, vec[1], vec[0]);
#else
    return (float)((DEGREES_PER_RADIAN * atan2((double)vec[1],
                                                  (double)vec[0])) /
                   DOUBLE_PI);
#endif
}

/* VERIFIED_DECOMPILER(0x3ac2d, 4ac2d_vectopitch.c, VERIFY-WAVE4-COMMON-MATH-03-2026-06-17): DATAFLOW_VERIFIED - vertical-vector pitch constants, sqrt forward length, atan2 argument order, negative scale, wrap, and return checked. */
/* 0x3ac2d vectopitch */
float vectopitch(const float *vec)
{
    float pitch;

    if (vec[1] == 0.0f && vec[0] == 0.0f) {
        if (vec[2] > 0.0f) {
            pitch = 270.0f;
        } else {
            pitch = 90.0f;
        }
    } else {
#if EMULATE_X87
        float forward = X87_HYPOT2(vec[0], vec[1]);
        pitch = X87_ATAN2DEG(-DEGREES_PER_RADIAN, vec[2], forward);
        if (pitch < 0.0f) {
            pitch = X87_WRAP360(pitch);
        }
#else
        float forward = (float)CoduoLibm_Sqrt((double)(vec[0] * vec[0] +
                                             vec[1] * vec[1]));
        pitch = (float)((-DEGREES_PER_RADIAN * atan2((double)vec[2],
                                                        (double)forward)) /
                        DOUBLE_PI);
        if (pitch < 0.0f) {
            pitch += DEGREES_PER_CIRCLE;
        }
#endif
    }

    return pitch;
}

/* VERIFIED_DECOMPILER(0x3ad1d, 4ad1d_vectosignedpitch.c, VERIFY-WAVE4-COMMON-MATH-03-2026-06-17): DATAFLOW_VERIFIED - vertical-vector signed pitch constants, sqrt forward length, atan2 argument order, no-wrap behavior, and return checked. */
/* 0x3ad1d vectosignedpitch */
float vectosignedpitch(const float *vec)
{
    if (vec[1] == 0.0f && vec[0] == 0.0f) {
        if (vec[2] > 0.0f) {
            return -90.0f;
        }
        return 90.0f;
    }

    {
#if EMULATE_X87
        float forward = X87_HYPOT2(vec[0], vec[1]);
        return X87_ATAN2DEG(-DEGREES_PER_RADIAN, vec[2], forward);
#else
        float forward = (float)CoduoLibm_Sqrt((double)(vec[0] * vec[0] +
                                             vec[1] * vec[1]));
        return (float)((-DEGREES_PER_RADIAN * atan2((double)vec[2],
                                                       (double)forward)) /
                       DOUBLE_PI);
#endif
    }
}

/* VERIFIED_DECOMPILER(0x3aded, 4aded_vectoangles.c, VERIFY-WAVE4-COMMON-MATH-03-2026-06-17): DATAFLOW_VERIFIED - zero-vector branch, yaw/pitch atan2 math, wrap behavior, and angles[0..2] stores checked. */
/* 0x3aded vectoangles */
void vectoangles(const float *vec, float *angles)
{
    float yaw;
    float pitch;

    if (vec[1] == 0.0f && vec[0] == 0.0f) {
        yaw = 0.0f;
        if (vec[2] > 0.0f) {
            pitch = 270.0f;
        } else {
            pitch = 90.0f;
        }
    } else {
        float forward;
#if EMULATE_X87
        yaw = X87_ATAN2DEG(DEGREES_PER_RADIAN, vec[1], vec[0]);
        if (yaw < 0.0f) {
            yaw = X87_WRAP360(yaw);
        }
        forward = X87_HYPOT2(vec[0], vec[1]);
        pitch = X87_ATAN2DEG(-DEGREES_PER_RADIAN, vec[2], forward);
        if (pitch < 0.0f) {
            pitch = X87_WRAP360(pitch);
        }
#else
        yaw = (float)((DEGREES_PER_RADIAN * atan2((double)vec[1],
                                                     (double)vec[0])) /
                      DOUBLE_PI);
        if (yaw < 0.0f) {
            yaw += DEGREES_PER_CIRCLE;
        }

        forward = (float)CoduoLibm_Sqrt((double)(vec[0] * vec[0] + vec[1] * vec[1]));
        pitch = (float)((-DEGREES_PER_RADIAN * atan2((double)vec[2],
                                                        (double)forward)) /
                        DOUBLE_PI);
        if (pitch < 0.0f) {
            pitch += DEGREES_PER_CIRCLE;
        }
#endif
    }

    angles[0] = pitch;
    angles[1] = yaw;
    angles[2] = 0.0f;
}

/* VERIFIED_DECOMPILER(0x3af4c, 4af4c_vectosignedangles.c, VERIFY-WAVE4-COMMON-MATH-03-2026-06-17): DATAFLOW_VERIFIED - zero-vector branch, signed yaw/pitch atan2 math, no-wrap behavior, and angles[0..2] stores checked. */
/* 0x3af4c vectosignedangles */
void vectosignedangles(const float *vec, float *angles)
{
    float yaw;
    float pitch;

    if (vec[1] == 0.0f && vec[0] == 0.0f) {
        yaw = 0.0f;
        if (vec[2] > 0.0f) {
            pitch = -90.0f;
        } else {
            pitch = 90.0f;
        }
    } else {
        float forward;
#if EMULATE_X87
        yaw = X87_ATAN2DEG(DEGREES_PER_RADIAN, vec[1], vec[0]);
        forward = X87_HYPOT2(vec[0], vec[1]);
        pitch = X87_ATAN2DEG(-DEGREES_PER_RADIAN, vec[2], forward);
#else
        yaw = (float)((DEGREES_PER_RADIAN * atan2((double)vec[1],
                                                     (double)vec[0])) /
                      DOUBLE_PI);
        forward = (float)CoduoLibm_Sqrt((double)(vec[0] * vec[0] + vec[1] * vec[1]));
        pitch = (float)((-DEGREES_PER_RADIAN * atan2((double)vec[2],
                                                        (double)forward)) /
                        DOUBLE_PI);
#endif
    }

    angles[0] = pitch;
    angles[1] = yaw;
    angles[2] = 0.0f;
}

/* VERIFIED_DECOMPILER(0x3b068, 4b068_AngleVectors.c, VERIFY-WAVE4-COMMON-MATH-03-2026-06-17): DATAFLOW_VERIFIED - yaw/pitch/roll sincos calls, null guards, forward/right/up formulas, and sign-bit-equivalent negations checked. */
/* 0x3b068 AngleVectors */
void AngleVectors(const float *angles, float *forward, float *right, float *up)
{
    float sy;
    float cy;
    float sp;
    float cp;
    float radians;

#if EMULATE_X87
#define RAD(k)                                                                \
    x87f_store_f32(x87f_mul(x87f_load_f32(angles[k]),                         \
                            x87f_load_f64(DOUBLE_RADIANS_PER_DEGREE)))
#define MUL(a, b) x87f_mul(x87f_load_f32(a), x87f_load_f32(b))
    radians = RAD(1);
    SinCosFloat(radians, &sy, &cy);
    radians = RAD(0);
    SinCosFloat(radians, &sp, &cp);

    if (forward != 0) {
        uint32_t bits;

        forward[0] = x87f_store_f32(MUL(cp, cy));
        forward[1] = x87f_store_f32(MUL(cp, sy));
        memcpy(&bits, &sp, sizeof(bits));
        bits ^= FLOAT_SIGN_BIT_MASK;
        memcpy(&forward[2], &bits, sizeof(bits));
    }

    if (right != 0 || up != 0) {
        float sr;
        float cr;

        radians = RAD(2);
        SinCosFloat(radians, &sr, &cr);

        if (right != 0) {
            right[0] = x87f_store_f32(x87f_add(
                x87f_mul(x87f_mul(x87f_mul(x87f_load_f32(-1.0f),
                                           x87f_load_f32(sr)),
                                  x87f_load_f32(sp)),
                         x87f_load_f32(cy)),
                x87f_mul(x87f_mul(x87f_load_f32(-1.0f), x87f_load_f32(cr)),
                         x87f_neg(x87f_load_f32(sy)))));
            right[1] = x87f_store_f32(x87f_add(
                x87f_mul(x87f_mul(x87f_mul(x87f_load_f32(-1.0f),
                                           x87f_load_f32(sr)),
                                  x87f_load_f32(sp)),
                         x87f_load_f32(sy)),
                x87f_mul(x87f_mul(x87f_load_f32(-1.0f), x87f_load_f32(cr)),
                         x87f_load_f32(cy))));
            right[2] = x87f_store_f32(x87f_mul(
                x87f_mul(x87f_load_f32(-1.0f), x87f_load_f32(sr)),
                x87f_load_f32(cp)));
        }
        if (up != 0) {
            up[0] = x87f_store_f32(x87f_add(
                x87f_mul(x87f_mul(x87f_load_f32(cr), x87f_load_f32(sp)),
                         x87f_load_f32(cy)),
                MUL(sr, sy)));
            up[1] = x87f_store_f32(x87f_add(
                x87f_mul(x87f_mul(x87f_load_f32(cr), x87f_load_f32(sp)),
                         x87f_load_f32(sy)),
                x87f_mul(x87f_neg(x87f_load_f32(sr)), x87f_load_f32(cy))));
            up[2] = x87f_store_f32(MUL(cr, cp));
        }
    }
#undef RAD
#undef MUL
#else
    radians = (float)((double)angles[1] * DOUBLE_RADIANS_PER_DEGREE);
    SinCosFloat(radians, &sy, &cy);
    radians = (float)((double)angles[0] * DOUBLE_RADIANS_PER_DEGREE);
    SinCosFloat(radians, &sp, &cp);

    if (forward != 0) {
        uint32_t bits;

        forward[0] = cp * cy;
        forward[1] = cp * sy;
        memcpy(&bits, &sp, sizeof(bits));
        bits ^= FLOAT_SIGN_BIT_MASK;
        memcpy(&forward[2], &bits, sizeof(bits));
    }

    if (right != 0 || up != 0) {
        float sr;
        float cr;

        radians = (float)((double)angles[2] * DOUBLE_RADIANS_PER_DEGREE);
        SinCosFloat(radians, &sr, &cr);

        if (right != 0) {
            /* Preserve the stock multiply/sign/add graph at
             * 0x3b141..0x3b1ae, including its signed-zero behavior. */
            right[0] = game_compat_angle_vectors_negative_one * sr * sp * cy +
                       game_compat_angle_vectors_negative_one * cr * -sy;
            right[1] = game_compat_angle_vectors_negative_one * sr * sp * sy +
                       game_compat_angle_vectors_negative_one * cr * cy;
            right[2] = game_compat_angle_vectors_negative_one * sr * cp;
        }
        if (up != 0) {
            up[0] = cr * sp * cy + sr * sy;
            up[1] = cr * sp * sy + -sr * cy;
            up[2] = cr * cp;
        }
    }
#endif
}

/* VERIFIED_DECOMPILER(0x3b201, 4b201_YawVectors.c, VERIFY-WAVE4-COMMON-MATH-03-2026-06-17): DATAFLOW_VERIFIED - yaw sincos call, forward/right null guards, zero Z stores, and negative cosine sign-bit behavior checked. */
/* 0x3b201 YawVectors */
void YawVectors(float yaw, float *forward, float *right)
{
    uint32_t bits;
    float radians = (float)((double)yaw * DOUBLE_RADIANS_PER_DEGREE);
    float sine;
    float cosine;

    SinCosFloat(radians, &sine, &cosine);

    if (forward != 0) {
        memcpy(&bits, &cosine, sizeof(bits));
        memcpy(&forward[0], &bits, sizeof(bits));
        memcpy(&bits, &sine, sizeof(bits));
        memcpy(&forward[1], &bits, sizeof(bits));
        bits = 0;
        memcpy(&forward[2], &bits, sizeof(bits));
    }
    if (right != 0) {
        memcpy(&bits, &sine, sizeof(bits));
        memcpy(&right[0], &bits, sizeof(bits));
        memcpy(&bits, &cosine, sizeof(bits));
        bits ^= FLOAT_SIGN_BIT_MASK;
        memcpy(&right[1], &bits, sizeof(bits));
        bits = 0;
        memcpy(&right[2], &bits, sizeof(bits));
    }
}

/* VERIFIED_DECOMPILER(0x3b28f, 4b28f_PerpendicularVector.c, VERIFY-WAVE4-COMMON-MATH-04-2026-06-17): DATAFLOW_VERIFIED - least-axis scan, temp unit vector stores, projection call, and normalization checked. */
/* 0x3b28f PerpendicularVector */
void PerpendicularVector(float *dst, const float *src)
{
    float minelem = 1.0f;
    int pos = 0;
    vec3_t temp;

    for (int axis = 0; axis < 3; axis++) {
        float value = fabsf(src[axis]);

        if (value < minelem) {
            minelem = value;
            pos = axis;
        }
    }

    temp[0] = 0.0f;
    temp[1] = 0.0f;
    temp[2] = 0.0f;
    temp[pos] = 1.0f;

    ProjectPointOnPlane(dst, temp, src);
    VectorNormalize(dst);
}

/* VERIFIED_DECOMPILER(0x3b344, 4b344_GetPerpendicularViewVector.c, VERIFY-WAVE4-COMMON-MATH-04-2026-06-17): DATAFLOW_VERIFIED - two point-delta vectors, normalization calls, CrossProduct argument order, and output normalization checked. */
/* 0x3b344 GetPerpendicularViewVector */
void GetPerpendicularViewVector(const float *point, const float *p1,
                                const float *p2, float *out)
{
    vec3_t dir1;
    vec3_t dir2;

    dir1[0] = point[0] - p1[0];
    dir1[1] = point[1] - p1[1];
    dir1[2] = point[2] - p1[2];
    VectorNormalize(dir1);

    dir2[0] = point[0] - p2[0];
    dir2[1] = point[1] - p2[1];
    dir2[2] = point[2] - p2[2];
    VectorNormalize(dir2);

    CrossProduct(dir1, dir2, out);
    VectorNormalize(out);
}

/* VERIFIED_DECOMPILER(0x3b402, 4b402_ProjectPointOntoVector.c, VERIFY-WAVE4-COMMON-MATH-04-2026-06-17): DATAFLOW_VERIFIED - point/start delta, normalized segment direction, dot product reuse, and projected output stores checked. */
/* 0x3b402 ProjectPointOntoVector */
void ProjectPointOntoVector(const float *point, const float *start,
                            const float *end, float *out)
{
    vec3_t pointDelta;
    vec3_t direction;

    pointDelta[0] = point[0] - start[0];
    pointDelta[1] = point[1] - start[1];
    pointDelta[2] = point[2] - start[2];

    direction[0] = end[0] - start[0];
    direction[1] = end[1] - start[1];
    direction[2] = end[2] - start[2];
    VectorNormalize(direction);

    /* 0x3b48d..0x3b500: the dot product is recomputed in x87 registers for
     * each output lane and never rounded to float32 (original likely used
     * nested DotProduct/VectorMA macros). */
#if EMULATE_X87
    for (int c = 0; c < 3; ++c) {
        x87f dot = x87f_add(
            x87f_add(x87f_mul(x87f_load_f32(pointDelta[0]),
                              x87f_load_f32(direction[0])),
                     x87f_mul(x87f_load_f32(pointDelta[1]),
                              x87f_load_f32(direction[1]))),
            x87f_mul(x87f_load_f32(pointDelta[2]), x87f_load_f32(direction[2])));
        out[c] = x87f_store_f32(x87f_add(
            x87f_load_f32(start[c]),
            x87f_mul(dot, x87f_load_f32(direction[c]))));
    }
#else
    out[0] = start[0] + (pointDelta[0] * direction[0] +
                         pointDelta[1] * direction[1] +
                         pointDelta[2] * direction[2]) * direction[0];
    out[1] = start[1] + (pointDelta[0] * direction[0] +
                         pointDelta[1] * direction[1] +
                         pointDelta[2] * direction[2]) * direction[1];
    out[2] = start[2] + (pointDelta[0] * direction[0] +
                         pointDelta[1] * direction[1] +
                         pointDelta[2] * direction[2]) * direction[2];
#endif
}

/* VERIFIED_DECOMPILER(0x3b508, 4b508_MatrixMultiply.c, VERIFY-WAVE4-COMMON-MATH-04-2026-06-17): DATAFLOW_VERIFIED - 3x3 multiply cell formulas and store order checked. */
/* 0x3b508 MatrixMultiply */
void MatrixMultiply(const float *lhs, const float *rhs, float *out)
{
#if EMULATE_X87
    /* each out[r][c] is the 80-bit dot (lhs[r][0]*rhs[0][c] + lhs[r][1]*rhs[1][c])
     * + lhs[r][2]*rhs[2][c], rounded to float at the store. */
    for (int r = 0; r < 3; ++r) {
        for (int c = 0; c < 3; ++c) {
            out[r * 3 + c] = x87f_store_f32(x87f_add(
                x87f_add(x87f_mul(x87f_load_f32(lhs[r * 3 + 0]),
                                  x87f_load_f32(rhs[c])),
                         x87f_mul(x87f_load_f32(lhs[r * 3 + 1]),
                                  x87f_load_f32(rhs[3 + c]))),
                x87f_mul(x87f_load_f32(lhs[r * 3 + 2]),
                         x87f_load_f32(rhs[6 + c]))));
        }
    }
#else
    out[0] = lhs[0] * rhs[0] + lhs[1] * rhs[3] + lhs[2] * rhs[6];
    out[1] = lhs[0] * rhs[1] + lhs[1] * rhs[4] + lhs[2] * rhs[7];
    out[2] = lhs[0] * rhs[2] + lhs[1] * rhs[5] + lhs[2] * rhs[8];
    out[3] = lhs[3] * rhs[0] + lhs[4] * rhs[3] + lhs[5] * rhs[6];
    out[4] = lhs[3] * rhs[1] + lhs[4] * rhs[4] + lhs[5] * rhs[7];
    out[5] = lhs[3] * rhs[2] + lhs[4] * rhs[5] + lhs[5] * rhs[8];
    out[6] = lhs[6] * rhs[0] + lhs[7] * rhs[3] + lhs[8] * rhs[6];
    out[7] = lhs[6] * rhs[1] + lhs[7] * rhs[4] + lhs[8] * rhs[7];
    out[8] = lhs[6] * rhs[2] + lhs[7] * rhs[5] + lhs[8] * rhs[8];
#endif
}

/* VERIFIED_DECOMPILER(0x3b714, 4b714_MatrixMultiplyEquals.c, VERIFY-WAVE4-COMMON-MATH-04-2026-06-17): DATAFLOW_VERIFIED - alias-sensitive first-six temp outputs, rhs[6..8] early stores, and final rhs[0..5] stores checked. */
/* 0x3b714 MatrixMultiplyEquals */
void MatrixMultiplyEquals(const float *lhs, float *rhs)
{
    float lhs0 = lhs[0];
    float lhs1 = lhs[1];
    float lhs2 = lhs[2];
    float rhs6 = rhs[6];
    float rhs7 = rhs[7];
    float rhs8 = rhs[8];
    float lhs3 = lhs[3];
    float rhs0 = rhs[0];
    float lhs4 = lhs[4];
    float lhs5 = lhs[5];
    float rhs1 = rhs[1];
    float rhs2 = rhs[2];

#if EMULATE_X87
#define D3(a, b, c, d, e, f)                                                   \
    x87f_store_f32(x87f_add(                                                   \
        x87f_add(x87f_mul(x87f_load_f32(a), x87f_load_f32(b)),                \
                 x87f_mul(x87f_load_f32(c), x87f_load_f32(d))),               \
        x87f_mul(x87f_load_f32(e), x87f_load_f32(f))))
    rhs[6] = D3(lhs[6], rhs[0], lhs[7], rhs[3], lhs[8], rhs[6]);
    rhs[7] = D3(lhs[6], rhs[1], lhs[7], rhs[4], lhs[8], rhs[7]);
    rhs[8] = D3(lhs[6], rhs[2], lhs[7], rhs[5], lhs[8], rhs[8]);
    rhs[0] = D3(lhs0, rhs[0], lhs1, rhs[3], lhs2, rhs6);
    rhs[1] = D3(lhs0, rhs[1], lhs1, rhs[4], lhs2, rhs7);
    rhs[2] = D3(lhs0, rhs[2], lhs1, rhs[5], lhs2, rhs8);
    rhs[3] = D3(lhs3, rhs0, lhs4, rhs[3], lhs5, rhs6);
    rhs[4] = D3(lhs3, rhs1, lhs4, rhs[4], lhs5, rhs7);
    rhs[5] = D3(lhs3, rhs2, lhs4, rhs[5], lhs5, rhs8);
#undef D3
#else
    rhs[6] = lhs[6] * rhs[0] + lhs[7] * rhs[3] + lhs[8] * rhs[6];
    rhs[7] = lhs[6] * rhs[1] + lhs[7] * rhs[4] + lhs[8] * rhs[7];
    rhs[8] = lhs[6] * rhs[2] + lhs[7] * rhs[5] + lhs[8] * rhs[8];
    rhs[0] = lhs0 * rhs[0] + lhs1 * rhs[3] + lhs2 * rhs6;
    rhs[1] = lhs0 * rhs[1] + lhs1 * rhs[4] + lhs2 * rhs7;
    rhs[2] = lhs0 * rhs[2] + lhs1 * rhs[5] + lhs2 * rhs8;
    rhs[3] = lhs3 * rhs0 + lhs4 * rhs[3] + lhs5 * rhs6;
    rhs[4] = lhs3 * rhs1 + lhs4 * rhs[4] + lhs5 * rhs7;
    rhs[5] = lhs3 * rhs2 + lhs4 * rhs[5] + lhs5 * rhs8;
#endif
}

/* VERIFIED_DECOMPILER(0x3b947, 4b947_MatrixMultiply34.c, VERIFY-WAVE4-COMMON-MATH-04-2026-06-17): DATAFLOW_VERIFIED - 3x4 multiply formulas, translation additions, and twelve output stores checked. */
/* 0x3b947 MatrixMultiply34 */
void MatrixMultiply34(const float *lhs, const float *rhs, float *out)
{
#if EMULATE_X87
    out[0] = X87_D3(lhs[0], rhs[0], lhs[1], rhs[4], lhs[2], rhs[8]);
    out[1] = X87_D3(lhs[0], rhs[1], lhs[1], rhs[5], lhs[2], rhs[9]);
    out[2] = X87_D3(lhs[0], rhs[2], lhs[1], rhs[6], lhs[2], rhs[10]);
    out[3] = X87_D4(lhs[0], rhs[3], lhs[1], rhs[7], lhs[2], rhs[11], lhs[3]);
    out[4] = X87_D3(lhs[4], rhs[0], lhs[5], rhs[4], lhs[6], rhs[8]);
    out[5] = X87_D3(lhs[4], rhs[1], lhs[5], rhs[5], lhs[6], rhs[9]);
    out[6] = X87_D3(lhs[4], rhs[2], lhs[5], rhs[6], lhs[6], rhs[10]);
    out[7] = X87_D4(lhs[4], rhs[3], lhs[5], rhs[7], lhs[6], rhs[11], lhs[7]);
    out[8] = X87_D3(lhs[8], rhs[0], lhs[9], rhs[4], lhs[10], rhs[8]);
    out[9] = X87_D3(lhs[8], rhs[1], lhs[9], rhs[5], lhs[10], rhs[9]);
    out[10] = X87_D3(lhs[8], rhs[2], lhs[9], rhs[6], lhs[10], rhs[10]);
    out[11] =
        X87_D4(lhs[8], rhs[3], lhs[9], rhs[7], lhs[10], rhs[11], lhs[11]);
#else
    out[0] = lhs[0] * rhs[0] + lhs[1] * rhs[4] + lhs[2] * rhs[8];
    out[1] = lhs[0] * rhs[1] + lhs[1] * rhs[5] + lhs[2] * rhs[9];
    out[2] = lhs[0] * rhs[2] + lhs[1] * rhs[6] + lhs[2] * rhs[10];
    out[3] = lhs[0] * rhs[3] + lhs[1] * rhs[7] + lhs[2] * rhs[11] +
             lhs[3];
    out[4] = lhs[4] * rhs[0] + lhs[5] * rhs[4] + lhs[6] * rhs[8];
    out[5] = lhs[4] * rhs[1] + lhs[5] * rhs[5] + lhs[6] * rhs[9];
    out[6] = lhs[4] * rhs[2] + lhs[5] * rhs[6] + lhs[6] * rhs[10];
    out[7] = lhs[4] * rhs[3] + lhs[5] * rhs[7] + lhs[6] * rhs[11] +
             lhs[7];
    out[8] = lhs[8] * rhs[0] + lhs[9] * rhs[4] + lhs[10] * rhs[8];
    out[9] = lhs[8] * rhs[1] + lhs[9] * rhs[5] + lhs[10] * rhs[9];
    out[10] = lhs[8] * rhs[2] + lhs[9] * rhs[6] + lhs[10] * rhs[10];
    out[11] = lhs[8] * rhs[3] + lhs[9] * rhs[7] + lhs[10] * rhs[11] +
              lhs[11];
#endif
}

/* VERIFIED_DECOMPILER(0x3bc1c, 4bc1c_MatrixMultiply43.c, VERIFY-WAVE4-COMMON-MATH-04-2026-06-17): DATAFLOW_VERIFIED - 4x3 affine multiply formulas, decompiler store order, and rhs translation additions checked. */
/* 0x3bc1c MatrixMultiply43 */
void MatrixMultiply43(const float *lhs, const float *rhs, float *out)
{
#if EMULATE_X87
    out[0] = X87_D3(lhs[0], rhs[0], lhs[1], rhs[3], lhs[2], rhs[6]);
    out[3] = X87_D3(lhs[3], rhs[0], lhs[4], rhs[3], lhs[5], rhs[6]);
    out[6] = X87_D3(lhs[6], rhs[0], lhs[7], rhs[3], lhs[8], rhs[6]);
    out[1] = X87_D3(lhs[0], rhs[1], lhs[1], rhs[4], lhs[2], rhs[7]);
    out[4] = X87_D3(lhs[3], rhs[1], lhs[4], rhs[4], lhs[5], rhs[7]);
    out[7] = X87_D3(lhs[6], rhs[1], lhs[7], rhs[4], lhs[8], rhs[7]);
    out[2] = X87_D3(lhs[0], rhs[2], lhs[1], rhs[5], lhs[2], rhs[8]);
    out[5] = X87_D3(lhs[3], rhs[2], lhs[4], rhs[5], lhs[5], rhs[8]);
    out[8] = X87_D3(lhs[6], rhs[2], lhs[7], rhs[5], lhs[8], rhs[8]);
    out[9] = X87_D4(lhs[9], rhs[0], lhs[10], rhs[3], lhs[11], rhs[6], rhs[9]);
    out[10] =
        X87_D4(lhs[9], rhs[1], lhs[10], rhs[4], lhs[11], rhs[7], rhs[10]);
    out[11] =
        X87_D4(lhs[9], rhs[2], lhs[10], rhs[5], lhs[11], rhs[8], rhs[11]);
#else
    out[0] = lhs[0] * rhs[0] + lhs[1] * rhs[3] + lhs[2] * rhs[6];
    out[3] = lhs[3] * rhs[0] + lhs[4] * rhs[3] + lhs[5] * rhs[6];
    out[6] = lhs[6] * rhs[0] + lhs[7] * rhs[3] + lhs[8] * rhs[6];
    out[1] = lhs[0] * rhs[1] + lhs[1] * rhs[4] + lhs[2] * rhs[7];
    out[4] = lhs[3] * rhs[1] + lhs[4] * rhs[4] + lhs[5] * rhs[7];
    out[7] = lhs[6] * rhs[1] + lhs[7] * rhs[4] + lhs[8] * rhs[7];
    out[2] = lhs[0] * rhs[2] + lhs[1] * rhs[5] + lhs[2] * rhs[8];
    out[5] = lhs[3] * rhs[2] + lhs[4] * rhs[5] + lhs[5] * rhs[8];
    out[8] = lhs[6] * rhs[2] + lhs[7] * rhs[5] + lhs[8] * rhs[8];
    out[9] = lhs[9] * rhs[0] + lhs[10] * rhs[3] + lhs[11] * rhs[6] +
             rhs[9];
    out[10] = lhs[9] * rhs[1] + lhs[10] * rhs[4] + lhs[11] * rhs[7] +
              rhs[10];
    out[11] = lhs[9] * rhs[2] + lhs[10] * rhs[5] + lhs[11] * rhs[8] +
              rhs[11];
#endif
}

/* VERIFIED_DECOMPILER(0x3bef1, 4bef1_DObjSkelMatrixMultiply43.c, VERIFY-WAVE4-COMMON-MATH-04-2026-06-17): DATAFLOW_VERIFIED - skeleton lhs row starts 0/4/8/12, 4x3 affine formulas, and rhs translation additions checked. */
/* 0x3bef1 DObjSkelMatrixMultiply43 */
void DObjSkelMatrixMultiply43(const float *lhs, const float *rhs, float *out)
{
#if EMULATE_X87
    out[0] = X87_D3(lhs[0], rhs[0], lhs[1], rhs[3], lhs[2], rhs[6]);
    out[3] = X87_D3(lhs[4], rhs[0], lhs[5], rhs[3], lhs[6], rhs[6]);
    out[6] = X87_D3(lhs[8], rhs[0], lhs[9], rhs[3], lhs[10], rhs[6]);
    out[1] = X87_D3(lhs[0], rhs[1], lhs[1], rhs[4], lhs[2], rhs[7]);
    out[4] = X87_D3(lhs[4], rhs[1], lhs[5], rhs[4], lhs[6], rhs[7]);
    out[7] = X87_D3(lhs[8], rhs[1], lhs[9], rhs[4], lhs[10], rhs[7]);
    out[2] = X87_D3(lhs[0], rhs[2], lhs[1], rhs[5], lhs[2], rhs[8]);
    out[5] = X87_D3(lhs[4], rhs[2], lhs[5], rhs[5], lhs[6], rhs[8]);
    out[8] = X87_D3(lhs[8], rhs[2], lhs[9], rhs[5], lhs[10], rhs[8]);
    out[9] =
        X87_D4(lhs[12], rhs[0], lhs[13], rhs[3], lhs[14], rhs[6], rhs[9]);
    out[10] =
        X87_D4(lhs[12], rhs[1], lhs[13], rhs[4], lhs[14], rhs[7], rhs[10]);
    out[11] =
        X87_D4(lhs[12], rhs[2], lhs[13], rhs[5], lhs[14], rhs[8], rhs[11]);
#else
    out[0] = lhs[0] * rhs[0] + lhs[1] * rhs[3] + lhs[2] * rhs[6];
    out[3] = lhs[4] * rhs[0] + lhs[5] * rhs[3] + lhs[6] * rhs[6];
    out[6] = lhs[8] * rhs[0] + lhs[9] * rhs[3] + lhs[10] * rhs[6];
    out[1] = lhs[0] * rhs[1] + lhs[1] * rhs[4] + lhs[2] * rhs[7];
    out[4] = lhs[4] * rhs[1] + lhs[5] * rhs[4] + lhs[6] * rhs[7];
    out[7] = lhs[8] * rhs[1] + lhs[9] * rhs[4] + lhs[10] * rhs[7];
    out[2] = lhs[0] * rhs[2] + lhs[1] * rhs[5] + lhs[2] * rhs[8];
    out[5] = lhs[4] * rhs[2] + lhs[5] * rhs[5] + lhs[6] * rhs[8];
    out[8] = lhs[8] * rhs[2] + lhs[9] * rhs[5] + lhs[10] * rhs[8];
    out[9] = lhs[12] * rhs[0] + lhs[13] * rhs[3] + lhs[14] * rhs[6] +
             rhs[9];
    out[10] = lhs[12] * rhs[1] + lhs[13] * rhs[4] + lhs[14] * rhs[7] +
              rhs[10];
    out[11] = lhs[12] * rhs[2] + lhs[13] * rhs[5] + lhs[14] * rhs[8] +
              rhs[11];
#endif
}

/* VERIFIED_DECOMPILER(0x3c184, 4c184_DObjSkel2MatrixMultiply43.c, VERIFY-WAVE4-COMMON-MATH-04-2026-06-17): DATAFLOW_VERIFIED - skeleton lhs row starts 0/4/8/12, 4x4 output layout, zero/one homogeneous stores, and affine translation checked. */
/* 0x3c184 DObjSkel2MatrixMultiply43 */
void DObjSkel2MatrixMultiply43(const float *lhs, const float *rhs, float *out)
{
#if EMULATE_X87
    out[0] = X87_D3(lhs[0], rhs[0], lhs[1], rhs[3], lhs[2], rhs[6]);
    out[4] = X87_D3(lhs[4], rhs[0], lhs[5], rhs[3], lhs[6], rhs[6]);
    out[8] = X87_D3(lhs[8], rhs[0], lhs[9], rhs[3], lhs[10], rhs[6]);
    out[1] = X87_D3(lhs[0], rhs[1], lhs[1], rhs[4], lhs[2], rhs[7]);
    out[5] = X87_D3(lhs[4], rhs[1], lhs[5], rhs[4], lhs[6], rhs[7]);
    out[9] = X87_D3(lhs[8], rhs[1], lhs[9], rhs[4], lhs[10], rhs[7]);
    out[2] = X87_D3(lhs[0], rhs[2], lhs[1], rhs[5], lhs[2], rhs[8]);
    out[6] = X87_D3(lhs[4], rhs[2], lhs[5], rhs[5], lhs[6], rhs[8]);
    out[10] = X87_D3(lhs[8], rhs[2], lhs[9], rhs[5], lhs[10], rhs[8]);
    out[3] = 0.0f;
    out[7] = 0.0f;
    out[11] = 0.0f;
    out[12] =
        X87_D4(lhs[12], rhs[0], lhs[13], rhs[3], lhs[14], rhs[6], rhs[9]);
    out[13] =
        X87_D4(lhs[12], rhs[1], lhs[13], rhs[4], lhs[14], rhs[7], rhs[10]);
    out[14] =
        X87_D4(lhs[12], rhs[2], lhs[13], rhs[5], lhs[14], rhs[8], rhs[11]);
    out[15] = 1.0f;
#else
    out[0] = lhs[0] * rhs[0] + lhs[1] * rhs[3] + lhs[2] * rhs[6];
    out[4] = lhs[4] * rhs[0] + lhs[5] * rhs[3] + lhs[6] * rhs[6];
    out[8] = lhs[8] * rhs[0] + lhs[9] * rhs[3] + lhs[10] * rhs[6];
    out[1] = lhs[0] * rhs[1] + lhs[1] * rhs[4] + lhs[2] * rhs[7];
    out[5] = lhs[4] * rhs[1] + lhs[5] * rhs[4] + lhs[6] * rhs[7];
    out[9] = lhs[8] * rhs[1] + lhs[9] * rhs[4] + lhs[10] * rhs[7];
    out[2] = lhs[0] * rhs[2] + lhs[1] * rhs[5] + lhs[2] * rhs[8];
    out[6] = lhs[4] * rhs[2] + lhs[5] * rhs[5] + lhs[6] * rhs[8];
    out[10] = lhs[8] * rhs[2] + lhs[9] * rhs[5] + lhs[10] * rhs[8];
    out[3] = 0.0f;
    out[7] = 0.0f;
    out[11] = 0.0f;
    out[12] = lhs[12] * rhs[0] + lhs[13] * rhs[3] + lhs[14] * rhs[6] +
              rhs[9];
    out[13] = lhs[12] * rhs[1] + lhs[13] * rhs[4] + lhs[14] * rhs[7] +
              rhs[10];
    out[14] = lhs[12] * rhs[2] + lhs[13] * rhs[5] + lhs[14] * rhs[8] +
              rhs[11];
    out[15] = 1.0f;
#endif
}

/* VERIFIED_DECOMPILER(0x3c4b8, 4c4b8_MatrixInverse.c, VERIFY-WAVE4-COMMON-MATH-04-2026-06-17): DATAFLOW_VERIFIED - determinant expression, reciprocal scale, cofactor signs, and nine output stores checked. */
/* 0x3c4b8 MatrixInverse */
void MatrixInverse(const float *in, float *out)
{
    /* The determinant is rounded to a float slot before the reciprocal
     * (fstp at 0x3c549), so it must be a separate float statement. */
#if EMULATE_X87
    float det = x87f_store_f32(x87f_add(
        x87f_sub(x87f_mul(X87_MINOR(in[8], in[4], in[7], in[5]),
                          x87f_load_f32(in[0])),
                 x87f_mul(X87_MINOR(in[8], in[1], in[7], in[2]),
                          x87f_load_f32(in[3]))),
        x87f_mul(X87_MINOR(in[5], in[1], in[4], in[2]),
                 x87f_load_f32(in[6]))));
    float invDet =
        x87f_store_f32(x87f_div(x87f_load_f32(1.0f), x87f_load_f32(det)));

    out[0] = x87f_store_f32(
        x87f_mul(X87_MINOR(in[8], in[4], in[7], in[5]), x87f_load_f32(invDet)));
    out[1] = x87f_store_f32(x87f_mul(
        x87f_neg(X87_MINOR(in[8], in[1], in[7], in[2])), x87f_load_f32(invDet)));
    out[2] = x87f_store_f32(
        x87f_mul(X87_MINOR(in[5], in[1], in[4], in[2]), x87f_load_f32(invDet)));
    out[3] = x87f_store_f32(x87f_mul(
        x87f_neg(X87_MINOR(in[8], in[3], in[6], in[5])), x87f_load_f32(invDet)));
    out[4] = x87f_store_f32(
        x87f_mul(X87_MINOR(in[8], in[0], in[6], in[2]), x87f_load_f32(invDet)));
    out[5] = x87f_store_f32(x87f_mul(
        x87f_neg(X87_MINOR(in[5], in[0], in[3], in[2])), x87f_load_f32(invDet)));
    out[6] = x87f_store_f32(
        x87f_mul(X87_MINOR(in[7], in[3], in[6], in[4]), x87f_load_f32(invDet)));
    out[7] = x87f_store_f32(x87f_mul(
        x87f_neg(X87_MINOR(in[7], in[0], in[6], in[1])), x87f_load_f32(invDet)));
    out[8] = x87f_store_f32(
        x87f_mul(X87_MINOR(in[4], in[0], in[3], in[1]), x87f_load_f32(invDet)));
#else
    float det = (in[8] * in[4] - in[7] * in[5]) * in[0] -
                (in[8] * in[1] - in[7] * in[2]) * in[3] +
                (in[5] * in[1] - in[4] * in[2]) * in[6];
    float invDet = 1.0f / det;

    out[0] = (in[8] * in[4] - in[7] * in[5]) * invDet;
    out[1] = -(in[8] * in[1] - in[7] * in[2]) * invDet;
    out[2] = (in[5] * in[1] - in[4] * in[2]) * invDet;
    out[3] = -(in[8] * in[3] - in[6] * in[5]) * invDet;
    out[4] = (in[8] * in[0] - in[6] * in[2]) * invDet;
    out[5] = -(in[5] * in[0] - in[3] * in[2]) * invDet;
    out[6] = (in[7] * in[3] - in[6] * in[4]) * invDet;
    out[7] = -(in[7] * in[0] - in[6] * in[1]) * invDet;
    out[8] = (in[4] * in[0] - in[3] * in[1]) * invDet;
#endif
}

/* VERIFIED_DECOMPILER(0x3c76d, 4c76d_MatrixInverse44.c, VERIFY-WAVE4-COMMON-MATH-12-2026-06-17): DATAFLOW_VERIFIED - column extraction loop, cofactor temporaries, sixteen adjugate stores, determinant reciprocal, and final scale loop checked. */
/* 0x3c76d MatrixInverse44 */
/* 4x4 adjugate cell: a three-term dot assigned (SET) then a `-=` of another
 * (SUB), in 80-bit under EMULATE_X87, plain float otherwise. */
#if EMULATE_X87
#define I4D(a, b, c, d, e, f)                                              \
    x87f_add(x87f_add(x87f_mul(x87f_load_f32(a), x87f_load_f32(b)),          \
                      x87f_mul(x87f_load_f32(c), x87f_load_f32(d))),         \
             x87f_mul(x87f_load_f32(e), x87f_load_f32(f)))
#define I4SET(dst, a, b, c, d, e, f) (dst) = x87f_store_f32(I4D(a, b, c, d, e, f))
#define I4SUB(dst, a, b, c, d, e, f)                                       \
    (dst) = x87f_store_f32(x87f_sub(x87f_load_f32(dst), I4D(a, b, c, d, e, f)))
#else
#define I4SET(dst, a, b, c, d, e, f) (dst) = (a) * (b) + (c) * (d) + (e) * (f)
#define I4SUB(dst, a, b, c, d, e, f) (dst) -= (a) * (b) + (c) * (d) + (e) * (f)
#endif

void MatrixInverse44(const float *in, float *out)
{
    float a[4];
    float b[4];
    float c[4];
    float d[4];
    float p0;
    float p1;
    float p2;
    float p3;
    float p4;
    float p5;
    float p6;
    float p7;
    float p8;
    float p9;
    float p10;
    float p11;

    for (int row = 0; row < 4; row++) {
        memcpy(&a[row], &in[row * 4 + 0], sizeof(a[row]));
        memcpy(&b[row], &in[row * 4 + 1], sizeof(b[row]));
        memcpy(&c[row], &in[row * 4 + 2], sizeof(c[row]));
        memcpy(&d[row], &in[row * 4 + 3], sizeof(d[row]));
    }

    p0 = c[2] * d[3];
    p1 = c[3] * d[2];
    p2 = c[1] * d[3];
    p3 = c[3] * d[1];
    p4 = c[1] * d[2];
    p5 = c[2] * d[1];
    p6 = c[0] * d[3];
    p7 = c[3] * d[0];
    p8 = c[0] * d[2];
    p9 = c[2] * d[0];
    p10 = c[0] * d[1];
    p11 = c[1] * d[0];

    /* Each adjugate cell is two statements in the original: the positive
     * triple is stored to the float slot, then reloaded and the negative
     * triple subtracted (e.g. out[0]: fstp 0x3c86f, fld/fsubrp 0x3c88d). */
    I4SET(out[0], p0, b[1], p3, b[2], p4, b[3]);
    I4SUB(out[0], p1, b[1], p2, b[2], p5, b[3]);
    I4SET(out[1], p1, b[0], p6, b[2], p9, b[3]);
    I4SUB(out[1], p0, b[0], p7, b[2], p8, b[3]);
    I4SET(out[2], p2, b[0], p7, b[1], p10, b[3]);
    I4SUB(out[2], p3, b[0], p6, b[1], p11, b[3]);
    I4SET(out[3], p5, b[0], p8, b[1], p11, b[2]);
    I4SUB(out[3], p4, b[0], p9, b[1], p10, b[2]);
    I4SET(out[4], p1, a[1], p2, a[2], p5, a[3]);
    I4SUB(out[4], p0, a[1], p3, a[2], p4, a[3]);
    I4SET(out[5], p0, a[0], p7, a[2], p8, a[3]);
    I4SUB(out[5], p1, a[0], p6, a[2], p9, a[3]);
    I4SET(out[6], p3, a[0], p6, a[1], p11, a[3]);
    I4SUB(out[6], p2, a[0], p7, a[1], p10, a[3]);
    I4SET(out[7], p4, a[0], p9, a[1], p10, a[2]);
    I4SUB(out[7], p5, a[0], p8, a[1], p11, a[2]);

    p0 = a[2] * b[3];
    p1 = a[3] * b[2];
    p2 = a[1] * b[3];
    p3 = a[3] * b[1];
    p4 = a[1] * b[2];
    p5 = a[2] * b[1];
    p6 = a[0] * b[3];
    p7 = a[3] * b[0];
    p8 = a[0] * b[2];
    p9 = a[2] * b[0];
    p10 = a[0] * b[1];
    p11 = a[1] * b[0];

    I4SET(out[8], p0, d[1], p3, d[2], p4, d[3]);
    I4SUB(out[8], p1, d[1], p2, d[2], p5, d[3]);
    I4SET(out[9], p1, d[0], p6, d[2], p9, d[3]);
    I4SUB(out[9], p0, d[0], p7, d[2], p8, d[3]);
    I4SET(out[10], p2, d[0], p7, d[1], p10, d[3]);
    I4SUB(out[10], p3, d[0], p6, d[1], p11, d[3]);
    I4SET(out[11], p5, d[0], p8, d[1], p11, d[2]);
    I4SUB(out[11], p4, d[0], p9, d[1], p10, d[2]);
    I4SET(out[12], p2, c[2], p5, c[3], p1, c[1]);
    I4SUB(out[12], p4, c[3], p0, c[1], p3, c[2]);
    I4SET(out[13], p8, c[3], p0, c[0], p7, c[2]);
    I4SUB(out[13], p6, c[2], p9, c[3], p1, c[0]);
    I4SET(out[14], p6, c[1], p11, c[3], p3, c[0]);
    I4SUB(out[14], p10, c[3], p2, c[0], p7, c[1]);
    I4SET(out[15], p10, c[2], p4, c[0], p9, c[1]);
    I4SUB(out[15], p8, c[1], p11, c[2], p5, c[0]);

    {
        /* det and its reciprocal are each rounded to a float slot once,
         * before the scale loop (fstp 0x3cd48 and 0x3cd54). */
#if EMULATE_X87
        float det = x87f_store_f32(x87f_add(
            x87f_add(x87f_add(x87f_mul(x87f_load_f32(a[0]), x87f_load_f32(out[0])),
                              x87f_mul(x87f_load_f32(a[1]),
                                       x87f_load_f32(out[1]))),
                     x87f_mul(x87f_load_f32(a[2]), x87f_load_f32(out[2]))),
            x87f_mul(x87f_load_f32(a[3]), x87f_load_f32(out[3]))));
        float invDet =
            x87f_store_f32(x87f_div(x87f_load_f32(1.0f), x87f_load_f32(det)));
#else
        float det = a[0] * out[0] + a[1] * out[1] +
                    a[2] * out[2] + a[3] * out[3];
        float invDet = 1.0f / det;
#endif

        for (int index = 0; index < 16; index++) {
            out[index] *= invDet;
        }
    }
}
#undef I4SET
#undef I4SUB
#undef I4D

/* VERIFIED_DECOMPILER(0x3cd97, 4cd97_MatrixTransformVector.c, VERIFY-WAVE4-COMMON-MATH-05-2026-06-17): DATAFLOW_VERIFIED - 3x3 vector transform formulas and output stores checked. */
/* 0x3cd97 MatrixTransformVector */
void MatrixTransformVector(const float *in, const float *matrix, float *out)
{
#if EMULATE_X87
    for (int c = 0; c < 3; ++c) {
        out[c] = x87f_store_f32(x87f_add(
            x87f_add(x87f_mul(x87f_load_f32(in[0]), x87f_load_f32(matrix[c])),
                     x87f_mul(x87f_load_f32(in[1]), x87f_load_f32(matrix[3 + c]))),
            x87f_mul(x87f_load_f32(in[2]), x87f_load_f32(matrix[6 + c]))));
    }
#else
    out[0] = in[0] * matrix[0] + in[1] * matrix[3] + in[2] * matrix[6];
    out[1] = in[0] * matrix[1] + in[1] * matrix[4] + in[2] * matrix[7];
    out[2] = in[0] * matrix[2] + in[1] * matrix[5] + in[2] * matrix[8];
#endif
}

/* VERIFIED_DECOMPILER(0x3c6ec, 4c6ec_MatrixInverseOrthogonal43.c, VERIFY-WAVE4-COMMON-MATH-05-2026-06-17): DATAFLOW_VERIFIED - transpose call, negated translation locals, and transformed output translation slot checked. */
/* 0x3c6ec MatrixInverseOrthogonal43 */
void MatrixInverseOrthogonal43(const float *in, float *out)
{
    const volatile float *originZero = vec3_origin;
    vec3_t negTranslation;

    MatrixTranspose((const vec3_t *)in, (vec3_t *)out);

    /* 0x3c710..0x3c748 loads vec3_origin through its GOT entry for each
     * subtraction; the volatile-qualified view prevents modern compilers from
     * replacing that proved global dependency with a synthesized zero. */
    negTranslation[0] = originZero[0] - in[9];
    negTranslation[1] = originZero[1] - in[10];
    negTranslation[2] = originZero[2] - in[11];
    MatrixTransformVector(negTranslation, out, &out[9]);
}

/* VERIFIED_DECOMPILER(0x3ce41, 4ce41_MatrixTransposeTransformVector.c, VERIFY-WAVE4-COMMON-MATH-05-2026-06-17): DATAFLOW_VERIFIED - transposed 3x3 vector transform formulas and output stores checked. */
/* 0x3ce41 MatrixTransposeTransformVector */
void MatrixTransposeTransformVector(const float *in, const float *matrix,
                                    float *out)
{
#if EMULATE_X87
    out[0] = x87f_store_f32(x87f_add(
        x87f_add(x87f_mul(x87f_load_f32(in[0]), x87f_load_f32(matrix[0])),
                 x87f_mul(x87f_load_f32(in[1]), x87f_load_f32(matrix[1]))),
        x87f_mul(x87f_load_f32(in[2]), x87f_load_f32(matrix[2]))));
    out[1] = x87f_store_f32(x87f_add(
        x87f_add(x87f_mul(x87f_load_f32(in[0]), x87f_load_f32(matrix[3])),
                 x87f_mul(x87f_load_f32(in[1]), x87f_load_f32(matrix[4]))),
        x87f_mul(x87f_load_f32(in[2]), x87f_load_f32(matrix[5]))));
    out[2] = x87f_store_f32(x87f_add(
        x87f_add(x87f_mul(x87f_load_f32(in[0]), x87f_load_f32(matrix[6])),
                 x87f_mul(x87f_load_f32(in[1]), x87f_load_f32(matrix[7]))),
        x87f_mul(x87f_load_f32(in[2]), x87f_load_f32(matrix[8]))));
#else
    out[0] = in[0] * matrix[0] + in[1] * matrix[1] + in[2] * matrix[2];
    out[1] = in[0] * matrix[3] + in[1] * matrix[4] + in[2] * matrix[5];
    out[2] = in[0] * matrix[6] + in[1] * matrix[7] + in[2] * matrix[8];
#endif
}

/* VERIFIED_DECOMPILER(0x3ceeb, 4ceeb_MatrixTransformVector43.c, VERIFY-WAVE4-COMMON-MATH-05-2026-06-17): DATAFLOW_VERIFIED - 4x3 affine vector transform formulas, translation additions, and output stores checked. */
/* 0x3ceeb MatrixTransformVector43 */
void MatrixTransformVector43(const float *in, const float *matrix, float *out)
{
#if EMULATE_X87
    for (int c = 0; c < 3; ++c) {
        out[c] = x87f_store_f32(x87f_add(
            x87f_add(
                x87f_add(x87f_mul(x87f_load_f32(in[0]), x87f_load_f32(matrix[c])),
                         x87f_mul(x87f_load_f32(in[1]),
                                  x87f_load_f32(matrix[3 + c]))),
                x87f_mul(x87f_load_f32(in[2]), x87f_load_f32(matrix[6 + c]))),
            x87f_load_f32(matrix[9 + c])));
    }
#else
    out[0] = in[0] * matrix[0] + in[1] * matrix[3] + in[2] * matrix[6] +
             matrix[9];
    out[1] = in[0] * matrix[1] + in[1] * matrix[4] + in[2] * matrix[7] +
             matrix[10];
    out[2] = in[0] * matrix[2] + in[1] * matrix[5] + in[2] * matrix[8] +
             matrix[11];
#endif
}

/* VERIFIED_DECOMPILER(0x3cfad, 4cfad_DObjSkelMatrixTransformVector43.c, VERIFY-WAVE4-COMMON-MATH-05-2026-06-17): DATAFLOW_VERIFIED - DObj skeleton matrix stride, affine vector transform formulas, and translation slots checked. */
/* 0x3cfad DObjSkelMatrixTransformVector43 */
void DObjSkelMatrixTransformVector43(const float *in, const float *matrix,
                                     float *out)
{
    out[0] = in[0] * matrix[0] + in[1] * matrix[4] + in[2] * matrix[8] +
             matrix[12];
    out[1] = in[0] * matrix[1] + in[1] * matrix[5] + in[2] * matrix[9] +
             matrix[13];
    out[2] = in[0] * matrix[2] + in[1] * matrix[6] + in[2] * matrix[10] +
             matrix[14];
}

/* VERIFIED_DECOMPILER(0x3d059, 4d059_MatrixTransposeTransformVector43.c, VERIFY-WAVE4-COMMON-MATH-05-2026-06-17): DATAFLOW_VERIFIED - translation subtraction locals, transpose-axis multiply formulas, and output stores checked. */
/* 0x3d059 MatrixTransposeTransformVector43 */
void MatrixTransposeTransformVector43(const float *in, const float *matrix,
                                      float *out)
{
    float delta0 = in[0] - matrix[9];
    float delta1 = in[1] - matrix[10];
    float delta2 = in[2] - matrix[11];

    out[0] = matrix[0] * delta0 + matrix[1] * delta1 + matrix[2] * delta2;
    out[1] = matrix[3] * delta0 + matrix[4] * delta1 + matrix[5] * delta2;
    out[2] = matrix[6] * delta0 + matrix[7] * delta1 + matrix[8] * delta2;
}

/* VERIFIED_DECOMPILER(0x3d118, 4d118_MatrixTransformVector43Equals.c, VERIFY-WAVE4-COMMON-MATH-05-2026-06-17): DATAFLOW_VERIFIED - in-place affine transform temp caching, z-before-x/y write order, and translation additions checked. */
/* 0x3d118 MatrixTransformVector43Equals */
void MatrixTransformVector43Equals(float *vec, const float *matrix)
{
#if EMULATE_X87
    float out0 = x87f_store_f32(x87f_add(
        x87f_add(
            x87f_add(x87f_mul(x87f_load_f32(vec[0]), x87f_load_f32(matrix[0])),
                     x87f_mul(x87f_load_f32(vec[1]), x87f_load_f32(matrix[3]))),
            x87f_mul(x87f_load_f32(vec[2]), x87f_load_f32(matrix[6]))),
        x87f_load_f32(matrix[9])));
    float out1 = x87f_store_f32(x87f_add(
        x87f_add(
            x87f_add(x87f_mul(x87f_load_f32(vec[0]), x87f_load_f32(matrix[1])),
                     x87f_mul(x87f_load_f32(vec[1]), x87f_load_f32(matrix[4]))),
            x87f_mul(x87f_load_f32(vec[2]), x87f_load_f32(matrix[7]))),
        x87f_load_f32(matrix[10])));

    vec[2] = x87f_store_f32(x87f_add(
        x87f_add(
            x87f_add(x87f_mul(x87f_load_f32(vec[0]), x87f_load_f32(matrix[2])),
                     x87f_mul(x87f_load_f32(vec[1]), x87f_load_f32(matrix[5]))),
            x87f_mul(x87f_load_f32(vec[2]), x87f_load_f32(matrix[8]))),
        x87f_load_f32(matrix[11])));
#else
    float out0 = vec[0] * matrix[0] + vec[1] * matrix[3] +
                 vec[2] * matrix[6] + matrix[9];
    float out1 = vec[0] * matrix[1] + vec[1] * matrix[4] +
                 vec[2] * matrix[7] + matrix[10];

    vec[2] = vec[0] * matrix[2] + vec[1] * matrix[5] +
             vec[2] * matrix[8] + matrix[11];
#endif
    vec[0] = out0;
    vec[1] = out1;
}

/* VERIFIED_DECOMPILER(0x94623, a4623_GetLeanFraction.c, VERIFY-WAVE4-COMMON-MATH-06-2026-06-17): DATAFLOW_VERIFIED - fabs helper call, long-double promotion, lean curve expression, and return checked. */
/* 0x94623 GetLeanFraction */
long double GetLeanFraction(float fraction)
{
    return (2.0f - (float)Common_FabsLongDouble(fraction)) * fraction;
}

#if EMULATE_X87
/* NOT_FROM_ORIGINAL_SOURCE: shim variant for stock 0x94640, which is
 * `fld 2.0; fsubrp; fmul fraction` on the 80-bit
 * |fraction| (|float| is exact).  Callers that keep the result in an 80-bit chain
 * (e.g. items.c view-kick GetLeanFraction(..) * scale) use this so the chain does
 * not collapse to double on arm64. */
x87f game_compat_get_lean_fraction_x87(float fraction)
{
    return x87f_mul(
        x87f_sub(x87f_load_f32(2.0f), x87f_abs(x87f_load_f32(fraction))),
        x87f_load_f32(fraction));
}
#endif

/* VERIFIED_DECOMPILER(0x94651, a4651_UnGetLeanFraction.c, VERIFY-WAVE4-COMMON-MATH-06-2026-06-17): DATAFLOW_VERIFIED - sqrt input, float root truncation, long-double subtraction, and return checked. */
/* 0x94651 UnGetLeanFraction */
long double UnGetLeanFraction(float fraction)
{
    double radicand =
        (double)((long double)1.0 - (long double)fraction);
    float root = (float)CoduoLibm_Sqrt(radicand);

    return (long double)1.0 - (long double)root;
}

/* VERIFIED_DECOMPILER(0x94688, a4688_AddLeanToPosition.c, VERIFY-WAVE4-COMMON-MATH-06-2026-06-17): DATAFLOW_VERIFIED - zero-only early return, GetLeanFraction call, angle vector setup, right-vector offset scale, and origin stores checked. */
/* 0x94688 AddLeanToPosition */
void AddLeanToPosition(float *origin, float yaw, float leanFraction,
                       float maxLean, float side)
{
    float lean;
    vec3_t angles;
    vec3_t right;

    if (leanFraction == 0.0f) {
        return;
    }

    lean = GetLeanFraction(leanFraction);
    angles[0] = 0.0f;
    angles[1] = yaw;
    angles[2] = lean * maxLean;
    AngleVectors(angles, NULL, right, NULL);

    lean *= side;
    origin[0] += right[0] * lean;
    origin[1] += right[1] * lean;
    origin[2] += right[2] * lean;
}

/* VERIFIED_DECOMPILER(0x9474a, a474a_OrientationPosToWorldPos.c, VERIFY-WAVE4-COMMON-MATH-06-2026-06-17): DATAFLOW_VERIFIED - orientation origin add, axis columns, and world-position output stores checked. */
/* 0x9474a OrientationPosToWorldPos */
void OrientationPosToWorldPos(const orientation_t *orientation, const vec3_t pos,
                              vec3_t out)
{
#if EMULATE_X87
    for (int i = 0; i < 3; ++i) {
        out[i] = X87_TD4(orientation->origin[i], pos[0],
                            orientation->axis[0][i], pos[1],
                            orientation->axis[1][i], pos[2],
                            orientation->axis[2][i]);
    }
#else
    out[0] = pos[0] * orientation->axis[0][0] +
             orientation->origin[0] +
             pos[1] * orientation->axis[1][0] +
             pos[2] * orientation->axis[2][0];
    out[1] = pos[0] * orientation->axis[0][1] +
             orientation->origin[1] +
             pos[1] * orientation->axis[1][1] +
             pos[2] * orientation->axis[2][1];
    out[2] = pos[0] * orientation->axis[0][2] +
             orientation->origin[2] +
             pos[1] * orientation->axis[1][2] +
             pos[2] * orientation->axis[2][2];
#endif
}

/* VERIFIED_DECOMPILER(0x947f8, a47f8_OrientationDirToWorldDir.c, VERIFY-WAVE4-COMMON-MATH-06-2026-06-17): DATAFLOW_VERIFIED - axis-column direction transform without origin addition checked. */
/* 0x947f8 OrientationDirToWorldDir */
void OrientationDirToWorldDir(const orientation_t *orientation, const vec3_t dir,
                              vec3_t out)
{
#if EMULATE_X87
    for (int i = 0; i < 3; ++i) {
        out[i] = X87_D3(dir[0], orientation->axis[0][i], dir[1],
                           orientation->axis[1][i], dir[2],
                           orientation->axis[2][i]);
    }
#else
    out[0] = dir[0] * orientation->axis[0][0] +
             dir[1] * orientation->axis[1][0] +
             dir[2] * orientation->axis[2][0];
    out[1] = dir[0] * orientation->axis[0][1] +
             dir[1] * orientation->axis[1][1] +
             dir[2] * orientation->axis[2][1];
    out[2] = dir[0] * orientation->axis[0][2] +
             dir[1] * orientation->axis[1][2] +
             dir[2] * orientation->axis[2][2];
#endif
}

/* VERIFIED_DECOMPILER(0x94893, a4893_OrientationPosFromWorldPos.c, VERIFY-WAVE4-COMMON-MATH-06-2026-06-17): DATAFLOW_VERIFIED - world-origin delta locals, axis-row dot products, and local-position stores checked. */
/* 0x94893 OrientationPosFromWorldPos */
void OrientationPosFromWorldPos(const orientation_t *orientation,
                                const vec3_t pos, vec3_t out)
{
    vec3_t delta;

    delta[0] = pos[0] - orientation->origin[0];
    delta[1] = pos[1] - orientation->origin[1];
    delta[2] = pos[2] - orientation->origin[2];

#if EMULATE_X87
    for (int i = 0; i < 3; ++i) {
        out[i] = X87_D3(delta[0], orientation->axis[i][0], delta[1],
                           orientation->axis[i][1], delta[2],
                           orientation->axis[i][2]);
    }
#else
    out[0] = delta[0] * orientation->axis[0][0] +
             delta[1] * orientation->axis[0][1] +
             delta[2] * orientation->axis[0][2];
    out[1] = delta[0] * orientation->axis[1][0] +
             delta[1] * orientation->axis[1][1] +
             delta[2] * orientation->axis[1][2];
    out[2] = delta[0] * orientation->axis[2][0] +
             delta[1] * orientation->axis[2][1] +
             delta[2] * orientation->axis[2][2];
#endif
}

/* VERIFIED_DECOMPILER(0x9493c, a493c_OrientationDirFromWorldDir.c, VERIFY-WAVE4-COMMON-MATH-06-2026-06-17): DATAFLOW_VERIFIED - axis-row direction transform without origin subtraction checked. */
/* 0x9493c OrientationDirFromWorldDir */
void OrientationDirFromWorldDir(const orientation_t *orientation,
                                const vec3_t dir, vec3_t out)
{
#if EMULATE_X87
    for (int i = 0; i < 3; ++i) {
        out[i] = X87_D3(dir[0], orientation->axis[i][0], dir[1],
                           orientation->axis[i][1], dir[2],
                           orientation->axis[i][2]);
    }
#else
    out[0] = dir[0] * orientation->axis[0][0] +
             dir[1] * orientation->axis[0][1] +
             dir[2] * orientation->axis[0][2];
    out[1] = dir[0] * orientation->axis[1][0] +
             dir[1] * orientation->axis[1][1] +
             dir[2] * orientation->axis[1][2];
    out[2] = dir[0] * orientation->axis[2][0] +
             dir[1] * orientation->axis[2][1] +
             dir[2] * orientation->axis[2][2];
#endif
}

/* VERIFIED_DECOMPILER(0x949d7, a49d7_Q_GetDecimalDelimiter.c, VERIFY-WAVE4-COMMON-MATH-06-2026-06-17): DATAFLOW_VERIFIED - standalone body returns '.', while caller-passed source argument is ignored by ABI-compatible source signature. */
/* 0x949d7 Q_GetDecimalDelimiter */
int Q_GetDecimalDelimiter(int decimalDelimiterSource)
{
    (void)decimalDelimiterSource;

    return '.';
}

/* VERIFIED_DECOMPILER(0x949e1, a49e1_Q_LocalizedFloatToString.c, VERIFY-WAVE4-COMMON-MATH-06-2026-06-17): DATAFLOW_VERIFIED - snprintf size-1 call, terminator store, delimiter-source argument, replacement loop bound, and early return checked. */
/* 0x949e1 Q_LocalizedFloatToString */
void Q_LocalizedFloatToString(float value, char *buffer, unsigned int size,
                              int precision, int decimalDelimiterSource)
{
    int delimiter;

    (void)decimalDelimiterSource;

    snprintf(buffer, size - 1u, "%.*f", precision, (double)value);
    buffer[size - 1u] = '\0';

    delimiter = Q_GetDecimalDelimiter(decimalDelimiterSource);
    if (delimiter != '.') {
        for (unsigned int index = 0; index < size; index++) {
            if (buffer[index] == '.') {
                buffer[index] = (char)delimiter;
                return;
            }
        }
    }
}

/* VERIFIED_DECOMPILER(0x94a75, a4a75_FUN_000a4a75.c, VERIFY-WAVE4-COMMON-MATH-06-2026-06-17): DATAFLOW_VERIFIED - float absolute value and long-double return checked. */
/* 0x94a75 local fabs helper */
static long double Common_FabsLongDouble(float value)
{
    float absolute = fabsf(value);
    float rounded;
    uint32_t bits;

    memcpy(&bits, &absolute, sizeof(bits));
    memcpy(&rounded, &bits, sizeof(bits));
    return (long double)rounded;
}

/* VERIFIED_DECOMPILER(0x3d1e9, 4d1e9_VectorAngleMultiply.c, VERIFY-WAVE4-COMMON-MATH-07-2026-06-17): DATAFLOW_VERIFIED - sin/cos angle conversion, original-Y temp, y-before-x store order, and xy rotation formulas checked. */
/* 0x3d1e9 VectorAngleMultiply */
void VectorAngleMultiply(float *vec, float degrees)
{
    float radians = (float)((double)degrees * DOUBLE_RADIANS_PER_DEGREE);
    float sine;
    float cosine;
    float newX;
    uint32_t bits;

    SinCosFloat(radians, &sine, &cosine);
    newX = vec[0] * cosine - vec[1] * sine;
    vec[1] = vec[1] * cosine + vec[0] * sine;
    memcpy(&bits, &newX, sizeof(bits));
    memcpy(&vec[0], &bits, sizeof(bits));
}

/* VERIFIED_DECOMPILER(0x3d25f, 4d25f_QuatMultiply.c, VERIFY-WAVE4-COMMON-MATH-07-2026-06-17): DATAFLOW_VERIFIED - quaternion product lane formulas, signs, and output stores checked. */
/* 0x3d25f QuatMultiply */
void QuatMultiply(const float *lhs, const float *rhs, float *out)
{
#if EMULATE_X87
#define M(a, b) x87f_mul(x87f_load_f32(a), x87f_load_f32(b))
    /* ((l0r3 + l3r0) + l2r1) - l1r2 */
    out[0] = x87f_store_f32(x87f_sub(
        x87f_add(x87f_add(M(lhs[0], rhs[3]), M(lhs[3], rhs[0])),
                 M(lhs[2], rhs[1])),
        M(lhs[1], rhs[2])));
    /* ((l1r3 - l2r0) + l3r1) + l0r2 */
    out[1] = x87f_store_f32(x87f_add(
        x87f_add(x87f_sub(M(lhs[1], rhs[3]), M(lhs[2], rhs[0])),
                 M(lhs[3], rhs[1])),
        M(lhs[0], rhs[2])));
    /* ((l2r3 + l1r0) - l0r1) + l3r2 */
    out[2] = x87f_store_f32(x87f_add(
        x87f_sub(x87f_add(M(lhs[2], rhs[3]), M(lhs[1], rhs[0])),
                 M(lhs[0], rhs[1])),
        M(lhs[3], rhs[2])));
    /* ((l3r3 - l0r0) - l1r1) - l2r2 */
    out[3] = x87f_store_f32(x87f_sub(
        x87f_sub(x87f_sub(M(lhs[3], rhs[3]), M(lhs[0], rhs[0])),
                 M(lhs[1], rhs[1])),
        M(lhs[2], rhs[2])));
#undef M
#else
    out[0] = lhs[0] * rhs[3] + lhs[3] * rhs[0] + lhs[2] * rhs[1] -
             lhs[1] * rhs[2];
    out[1] = lhs[1] * rhs[3] - lhs[2] * rhs[0] + lhs[3] * rhs[1] +
             lhs[0] * rhs[2];
    out[2] = ((lhs[2] * rhs[3] + lhs[1] * rhs[0]) -
              lhs[0] * rhs[1]) +
             lhs[3] * rhs[2];
    out[3] = ((lhs[3] * rhs[3] - lhs[0] * rhs[0]) -
              lhs[1] * rhs[1]) -
             lhs[2] * rhs[2];
#endif
}

/* VERIFIED_DECOMPILER(0x3d3cf, 4d3cf_ConvertQuatToMat.c, VERIFY-WAVE4-COMMON-MATH-07-2026-06-17): DATAFLOW_VERIFIED - nonzero/NaN length branch, scale intermediates, in-place matrix stores, and identity fallback checked. */
/* 0x3d3cf ConvertQuatToMat */
void ConvertQuatToMat(float *quat)
{
    /* 0x3d3eb/0x3d3fe/0x3d411: each square is stored to a float slot before the
       length sum and reused for the scaled squares. */
    float xSquared = quat[0] * quat[0];
    float ySquared = quat[1] * quat[1];
    float zSquared = quat[2] * quat[2];
    float lengthSquared =
        xSquared + ySquared + zSquared + quat[3] * quat[3];

    if (lengthSquared != 0.0f) {
        float scale = 2.0f / lengthSquared;
        float xy;
        float xz;
        float xw;
        float yz;
        float yw;
        float zw;

        xSquared = xSquared * scale;
        ySquared = ySquared * scale;
        zSquared = zSquared * scale;

        /* 0x3d472..0x3d4e5 uses the input quaternion itself as two rounded
           scale temporaries before the nine matrix lanes overwrite it. */
        quat[0] = quat[0] * scale;
        xy = quat[0] * quat[1];
        xz = quat[0] * quat[2];
        xw = quat[0] * quat[3];
        quat[1] = quat[1] * scale;
        yz = quat[1] * quat[2];
        yw = quat[1] * quat[3];
        zw = quat[2] * quat[3] * scale;

        quat[0] = 1.0f - (ySquared + zSquared);
        quat[1] = xy + zw;
        quat[2] = xz - yw;
        quat[3] = xy - zw;
        quat[4] = 1.0f - (xSquared + zSquared);
        quat[5] = yz + xw;
        quat[6] = xz + yw;
        quat[7] = yz - xw;
        quat[8] = 1.0f - (xSquared + ySquared);
    } else {
        uint32_t bits = FLOAT_ONE_BITS;

        memcpy(&quat[0], &bits, sizeof(bits));
        bits = 0;
        memcpy(&quat[1], &bits, sizeof(bits));
        memcpy(&quat[2], &bits, sizeof(bits));
        memcpy(&quat[3], &bits, sizeof(bits));
        bits = FLOAT_ONE_BITS;
        memcpy(&quat[4], &bits, sizeof(bits));
        bits = 0;
        memcpy(&quat[5], &bits, sizeof(bits));
        memcpy(&quat[6], &bits, sizeof(bits));
        memcpy(&quat[7], &bits, sizeof(bits));
        bits = FLOAT_ONE_BITS;
        memcpy(&quat[8], &bits, sizeof(bits));
    }
}

/* VERIFIED_DECOMPILER(0x3d602, 4d602_QuatEigenTrace.c, VERIFY-WAVE4-COMMON-MATH-07-2026-06-17): DATAFLOW_VERIFIED - vector/scalar length, nonzero/NaN normalization branch, trace sum, zero fallback, and float/x87 return checked. */
/* 0x3d602 QuatEigenTrace */
float QuatEigenTrace(const float *quat)
{
    /* 0x3d61e/0x3d631/0x3d644: each square is stored to a float slot before the
       length sum and reused for the scaled squares. */
#if EMULATE_X87
    float xSquared =
        x87f_store_f32(x87f_mul(x87f_load_f32(quat[0]), x87f_load_f32(quat[0])));
    float ySquared =
        x87f_store_f32(x87f_mul(x87f_load_f32(quat[1]), x87f_load_f32(quat[1])));
    float zSquared =
        x87f_store_f32(x87f_mul(x87f_load_f32(quat[2]), x87f_load_f32(quat[2])));
    float lengthSquared = x87f_store_f32(x87f_add(
        x87f_add(x87f_add(x87f_load_f32(xSquared), x87f_load_f32(ySquared)),
                 x87f_load_f32(zSquared)),
        x87f_mul(x87f_load_f32(quat[3]), x87f_load_f32(quat[3]))));

    if (lengthSquared != 0.0f) {
        float invLengthSquared = x87f_store_f32(
            x87f_div(x87f_load_f32(1.0f), x87f_load_f32(lengthSquared)));
        float xScaled = x87f_store_f32(
            x87f_mul(x87f_load_f32(xSquared), x87f_load_f32(invLengthSquared)));
        float yScaled = x87f_store_f32(
            x87f_mul(x87f_load_f32(ySquared), x87f_load_f32(invLengthSquared)));
        float zScaled = x87f_store_f32(
            x87f_mul(x87f_load_f32(zSquared), x87f_load_f32(invLengthSquared)));

        return x87f_store_f32(
            x87f_add(x87f_add(x87f_load_f32(xScaled), x87f_load_f32(yScaled)),
                     x87f_load_f32(zScaled)));
    }

    return 0.0f;
#else
    float xSquared = quat[0] * quat[0];
    float ySquared = quat[1] * quat[1];
    float zSquared = quat[2] * quat[2];
    float lengthSquared = xSquared + ySquared + zSquared + quat[3] * quat[3];

    if (lengthSquared != 0.0f) {
        float invLengthSquared = 1.0f / lengthSquared;
        /* 0x3d68d/0x3d696/0x3d69f: each scaled square is stored back to its
           float slot before the final sum. */
        float xScaled = xSquared * invLengthSquared;
        float yScaled = ySquared * invLengthSquared;
        float zScaled = zSquared * invLengthSquared;

        return xScaled + yScaled + zScaled;
    }

    return 0.0f;
#endif
}

/* VERIFIED_DECOMPILER(0x3d6c2, 4d6c2_AngleEigenTrace.c, VERIFY-WAVE4-COMMON-MATH-07-2026-06-17): DATAFLOW_VERIFIED - radians conversion, double sin call, squared result, float narrowing, and x87 return checked. */
/* 0x3d6c2 AngleEigenTrace */
float AngleEigenTrace(float degrees)
{
    double sine = CoduoLibm_Sin((double)degrees * DOUBLE_RADIANS_PER_DEGREE);

    return (float)(sine * sine);
}

/* VERIFIED_DECOMPILER(0x3d702, 4d702_QuatRatioEigenTrace.c, VERIFY-WAVE4-COMMON-MATH-07-2026-06-17): DATAFLOW_VERIFIED - inverse/multiply/eigen trace call sequence and local stack buffers checked; original i386 disassembly at 0x3d745 calls QuatEigenTrace immediately before epilogue, preserving the x87 return despite Ghidra's void inference. */
/* 0x3d702 QuatRatioEigenTrace */
float QuatRatioEigenTrace(const float *lhs, const float *rhs)
{
    float inverse[4];
    float product[4];

    QuatInverse(rhs, inverse);
    QuatMultiply(lhs, inverse, product);
    return QuatEigenTrace(product);
}

/* VERIFIED_DECOMPILER(0x3d750, 4d750_RotationToYaw.c, VERIFY-WAVE4-COMMON-MATH-07-2026-06-17): DATAFLOW_VERIFIED - xy scale, atan2 argument order, degrees conversion double constant, float narrowing, and x87 return checked. */
/* 0x3d750 RotationToYaw */
float RotationToYaw(const float *quat)
{
    /* 0x3d784: the xy squared length is stored to a float slot before the divide. */
#if EMULATE_X87
    float x2 =
        x87f_store_f32(x87f_mul(x87f_load_f32(quat[0]), x87f_load_f32(quat[0])));
    float lengthSquared = x87f_store_f32(x87f_add(
        x87f_load_f32(x2),
        x87f_mul(x87f_load_f32(quat[1]), x87f_load_f32(quat[1]))));
    float scale =
        x87f_store_f32(x87f_div(x87f_load_f32(2.0f), x87f_load_f32(lengthSquared)));

    double num = x87f_store_f64(x87f_mul(
        x87f_mul(x87f_load_f32(quat[0]), x87f_load_f32(quat[1])),
        x87f_load_f32(scale)));
    double den = x87f_store_f64(x87f_sub(
        x87f_load_f64(1.0),
        x87f_mul(x87f_load_f32(x2), x87f_load_f32(scale))));
    return x87f_store_f32(x87f_mul(x87f_load_f64(57.29577951308232),
                                   x87f_load_f64(atan2(num, den))));
#else
    float x2 = quat[0] * quat[0];
    float lengthSquared = x2 + quat[1] * quat[1];
    float scale = 2.0f / lengthSquared;

    return (float)(57.29577951308232 /* original double64 0x404ca5dc1a63c1f8 */ *
                   atan2((double)quat[0] * (double)quat[1] * (double)scale,
                         (double)1.0f - (double)x2 * (double)scale));
#endif
}

/* VERIFIED_DECOMPILER(0x3d7d7, 4d7d7_PitchToQuaternion.c, VERIFY-WAVE4-COMMON-MATH-07-2026-06-17): DATAFLOW_VERIFIED - pitch half-angle sin/cos destination lanes and zero stores checked. */
/* 0x3d7d7 PitchToQuaternion */
void PitchToQuaternion(float degrees, float *quat)
{
    float halfRadians =
        (float)((double)degrees * DOUBLE_HALF_RADIANS_PER_DEGREE);
    uint32_t zeroBits = 0;

    memcpy(&quat[0], &zeroBits, sizeof(zeroBits));
    memcpy(&quat[2], &zeroBits, sizeof(zeroBits));
    SinCosFloat(halfRadians, &quat[1], &quat[3]);
}

/* VERIFIED_DECOMPILER(0x3d831, 4d831_YawToQuaternion.c, VERIFY-WAVE4-COMMON-MATH-07-2026-06-17): DATAFLOW_VERIFIED - yaw half-angle sin/cos destination lanes and zero stores checked. */
/* 0x3d831 YawToQuaternion */
void YawToQuaternion(float degrees, float *quat)
{
    float halfRadians =
        (float)((double)degrees * DOUBLE_HALF_RADIANS_PER_DEGREE);
    uint32_t zeroBits = 0;

    memcpy(&quat[0], &zeroBits, sizeof(zeroBits));
    memcpy(&quat[1], &zeroBits, sizeof(zeroBits));
    SinCosFloat(halfRadians, &quat[2], &quat[3]);
}

/* VERIFIED_DECOMPILER(0x3d88b, 4d88b_RollToQuaternion.c, VERIFY-WAVE4-COMMON-MATH-07-2026-06-17): DATAFLOW_VERIFIED - roll half-angle sin/cos destination lanes and zero stores checked. */
/* 0x3d88b RollToQuaternion */
void RollToQuaternion(float degrees, float *quat)
{
    float halfRadians =
        (float)((double)degrees * DOUBLE_HALF_RADIANS_PER_DEGREE);
    uint32_t zeroBits = 0;

    memcpy(&quat[1], &zeroBits, sizeof(zeroBits));
    memcpy(&quat[2], &zeroBits, sizeof(zeroBits));
    SinCosFloat(halfRadians, &quat[0], &quat[3]);
}

/* VERIFIED_DECOMPILER(0x3d8e5, 4d8e5_ColorBytes3.c, VERIFY-WAVE4-COMMON-MATH-07-2026-06-17): DATAFLOW_VERIFIED - x87 rounded RGB byte extraction, byte packing order, and opaque alpha mask checked. */
/* 0x3d8e5 ColorBytes3 */
uint32_t ColorBytes3(float r, float g, float b)
{
#if !EMULATE_X87 && defined(__x86_64__)
    static const float scale = COLOR_BYTE_SCALE;
    coduo_x87_truncation_control_t control;
    int16_t converted[3];

    converted[0] = CODUO_X87_TRUNCATE_I16_FIRST(
        &control, (long double)r * (long double)scale);
    converted[1] = CODUO_X87_TRUNCATE_I16_NEXT(
        &control, (long double)g * (long double)scale);
    converted[2] = CODUO_X87_TRUNCATE_I16_NEXT(
        &control, (long double)b * (long double)scale);

    uint32_t rByte = (uint8_t)converted[0];
    uint32_t gByte = (uint8_t)converted[1];
    uint32_t bByte = (uint8_t)converted[2];
#else
    uint32_t rByte = (uint8_t)(int16_t)(r * COLOR_BYTE_SCALE);
    uint32_t gByte = (uint8_t)(int16_t)(g * COLOR_BYTE_SCALE);
    uint32_t bByte = (uint8_t)(int16_t)(b * COLOR_BYTE_SCALE);
#endif

    return rByte | (gByte << 8) | (bByte << 16) | COLOR_OPAQUE_ALPHA_MASK;
}

/* VERIFIED_DECOMPILER(0x3d964, 4d964_ColorBytes4.c, VERIFY-WAVE4-COMMON-MATH-07-2026-06-17): DATAFLOW_VERIFIED - x87 rounded RGBA byte extraction and byte packing order checked. */
/* 0x3d964 ColorBytes4 */
uint32_t ColorBytes4(float r, float g, float b, float a)
{
#if !EMULATE_X87 && defined(__x86_64__)
    static const float scale = COLOR_BYTE_SCALE;
    coduo_x87_truncation_control_t control;
    int16_t converted[4];

    converted[0] = CODUO_X87_TRUNCATE_I16_FIRST(
        &control, (long double)r * (long double)scale);
    converted[1] = CODUO_X87_TRUNCATE_I16_NEXT(
        &control, (long double)g * (long double)scale);
    converted[2] = CODUO_X87_TRUNCATE_I16_NEXT(
        &control, (long double)b * (long double)scale);
    converted[3] = CODUO_X87_TRUNCATE_I16_NEXT(
        &control, (long double)a * (long double)scale);

    uint32_t rByte = (uint8_t)converted[0];
    uint32_t gByte = (uint8_t)converted[1];
    uint32_t bByte = (uint8_t)converted[2];
    uint32_t aByte = (uint8_t)converted[3];
#else
    uint32_t rByte = (uint8_t)(int16_t)(r * COLOR_BYTE_SCALE);
    uint32_t gByte = (uint8_t)(int16_t)(g * COLOR_BYTE_SCALE);
    uint32_t bByte = (uint8_t)(int16_t)(b * COLOR_BYTE_SCALE);
    uint32_t aByte = (uint8_t)(int16_t)(a * COLOR_BYTE_SCALE);
#endif

    return rByte | (gByte << 8) | (bByte << 16) | (aByte << 24);
}

/* VERIFIED_DECOMPILER(0x3d9fa, 4d9fa_NormalizeColor.c, VERIFY-WAVE4-COMMON-MATH-07-2026-06-17): DATAFLOW_VERIFIED - max-channel comparisons, zero fallback store order, normalized stores, and float/x87 return checked. */
/* 0x3d9fa NormalizeColor */
float NormalizeColor(const float *in, float *out)
{
    float max;

    memcpy(&max, &in[0], sizeof(max));

    if (max < in[1]) {
        memcpy(&max, &in[1], sizeof(max));
    }
    if (max < in[2]) {
        memcpy(&max, &in[2], sizeof(max));
    }

    if (max == 0.0f) {
        uint32_t zeroBits = 0;

        memcpy(&out[2], &zeroBits, sizeof(zeroBits));
        memcpy(&out[1], &zeroBits, sizeof(zeroBits));
        memcpy(&out[0], &zeroBits, sizeof(zeroBits));
    } else {
        out[0] = in[0] / max;
        out[1] = in[1] / max;
        out[2] = in[2] / max;
    }

    return max;
}

/* VERIFIED_DECOMPILER(0x3dacd, 4dacd_AngleMod.c, VERIFY-WAVE4-COMMON-MATH-ANGLE-2026-06-17): DATAFLOW_VERIFIED - x87 ROUND(angle*182.04445), low-u16 mask, 0.005493164 scale, and float/x87 return checked. */
/* 0x3dacd AngleMod */
float AngleMod(float angle)
{
#if !EMULATE_X87 && defined(__x86_64__)
    static const float scale = ANGLE_SHORT_SCALE;
    int32_t packed = CODUO_X87_TRUNCATE_I32(
        (long double)angle * (long double)scale);
#else
    int32_t packed = (int32_t)(angle * ANGLE_SHORT_SCALE);
#endif

    return ANGLE_SHORT_TO_DEGREES *
           (float)(packed & (int32_t)UINT16_MAX);
}

/* VERIFIED_DECOMPILER(0x3db20, 4db20_LerpAngle.c, VERIFY-WAVE4-COMMON-MATH-ANGLE-2026-06-17): DATAFLOW_VERIFIED - target initialization, >180 wrap, <-180 wrap, interpolation expression, and float/x87 return checked. */
/* 0x3db20 LerpAngle */
float LerpAngle(float from, float to, float fraction)
{
    float target;

    memcpy(&target, &to, sizeof(target));

    if (DEGREES_PER_HALF_CIRCLE < to - from) {
        target = to - DEGREES_PER_CIRCLE;
    }
    if (target - from < -DEGREES_PER_HALF_CIRCLE) {
        target += DEGREES_PER_CIRCLE;
    }

    return from + (target - from) * fraction;
}

/* VERIFIED_DECOMPILER(0x3dba0, 4dba0_AngleSubtract.c, VERIFY-WAVE4-COMMON-MATH-ANGLE-2026-06-17): DATAFLOW_VERIFIED - a-b delta, >180 subtract loop, <-180 add loop, and float/x87 return checked. */
/* 0x3dba0 AngleSubtract */
float AngleSubtract(float a, float b)
{
    float delta = a - b;

    while (delta > DEGREES_PER_HALF_CIRCLE) {
        delta -= DEGREES_PER_CIRCLE;
    }
    while (delta < -DEGREES_PER_HALF_CIRCLE) {
        delta += DEGREES_PER_CIRCLE;
    }

    return delta;
}

/* VERIFIED_DECOMPILER(0x3dc11, 4dc11_AnglesSubtract.c, VERIFY-WAVE4-COMMON-MATH-ANGLE-2026-06-17): DATAFLOW_VERIFIED - three AngleSubtract calls, argument order, float casts, and output stores checked. */
/* 0x3dc11 AnglesSubtract */
void AnglesSubtract(const float *a, const float *b, float *out)
{
    out[0] = AngleSubtract(a[0], b[0]);
    out[1] = AngleSubtract(a[1], b[1]);
    out[2] = AngleSubtract(a[2], b[2]);
}

/* VERIFIED_DECOMPILER(0x3dc8c, 4dc8c_AngleNormalize360.c, VERIFY-WAVE4-COMMON-MATH-ANGLE-2026-06-17): DATAFLOW_VERIFIED - x87 ROUND(angle*182.04445), low-u16 mask, 0.005493164 scale, and float/x87 return checked. */
/* 0x3dc8c AngleNormalize360 */
float AngleNormalize360(float angle)
{
#if !EMULATE_X87 && defined(__x86_64__)
    static const float scale = ANGLE_SHORT_SCALE;
    int32_t packed = CODUO_X87_TRUNCATE_I32(
        (long double)angle * (long double)scale);
#else
    int32_t packed = (int32_t)(angle * ANGLE_SHORT_SCALE);
#endif

    return ANGLE_SHORT_TO_DEGREES *
           (float)(packed & (int32_t)UINT16_MAX);
}

/* VERIFIED_DECOMPILER(0x3dcdf, 4dcdf_AngleNormalize180.c, VERIFY-WAVE4-COMMON-MATH-ANGLE-2026-06-17): DATAFLOW_VERIFIED - AngleNormalize360 call, >180 subtract branch, and float/x87 return checked. */
/* 0x3dcdf AngleNormalize180 */
float AngleNormalize180(float angle)
{
    float normalized = AngleNormalize360(angle);

    if (normalized > DEGREES_PER_HALF_CIRCLE) {
        normalized -= DEGREES_PER_CIRCLE;
    }

    return normalized;
}

/* VERIFIED_DECOMPILER(0x3dd30, 4dd30_AngleNormalize360Accurate.c, VERIFY-WAVE4-COMMON-MATH-08-2026-06-17): DATAFLOW_VERIFIED - negative/add loop, >=360/subtract loop, unchanged path, and float/x87 return checked. */
/* 0x3dd30 AngleNormalize360Accurate */
float AngleNormalize360Accurate(float angle)
{
    if (angle < 0.0f) {
        do {
            angle += DEGREES_PER_CIRCLE;
        } while (angle < 0.0f);
    } else if (angle >= DEGREES_PER_CIRCLE) {
        do {
            angle -= DEGREES_PER_CIRCLE;
        } while (angle >= DEGREES_PER_CIRCLE);
    }

    return angle;
}

/* VERIFIED_DECOMPILER(0x3ddc5, 4ddc5_AngleNormalize180Accurate.c, VERIFY-WAVE4-COMMON-MATH-08-2026-06-17): DATAFLOW_VERIFIED - <=-180/add loop, >180/subtract loop, unchanged path, and float/x87 return checked. */
/* 0x3ddc5 AngleNormalize180Accurate */
float AngleNormalize180Accurate(float angle)
{
    if (angle <= -DEGREES_PER_HALF_CIRCLE) {
        do {
            angle += DEGREES_PER_CIRCLE;
        } while (angle <= -DEGREES_PER_HALF_CIRCLE);
    } else if (angle > DEGREES_PER_HALF_CIRCLE) {
        do {
            angle -= DEGREES_PER_CIRCLE;
        } while (angle > DEGREES_PER_HALF_CIRCLE);
    }

    return angle;
}

/* VERIFIED_DECOMPILER(0x3de5a, 4de5a_AngleDelta.c, VERIFY-WAVE4-COMMON-MATH-08-2026-06-17): DATAFLOW_VERIFIED - subtract argument expression and AngleNormalize180 tail-call checked; original i386 disassembly at 0x3de75 preserves the x87 return despite Ghidra's void inference. */
/* 0x3de5a AngleDelta */
float AngleDelta(float a, float b)
{
    return AngleNormalize180(a - b);
}

/* VERIFIED_DECOMPILER(0x3de80, 4de80_RadiusFromBounds.c, VERIFY-WAVE4-COMMON-MATH-08-2026-06-17): DATAFLOW_VERIFIED - three-axis absolute max loop, corner vector stores, sqrt length, float narrowing, and x87 return checked. */
/* 0x3de80 RadiusFromBounds */
float RadiusFromBounds(const float *mins, const float *maxs)
{
    vec3_t corner;

    for (int axis = 0; axis < 3; axis++) {
        float minAbs = fabsf(mins[axis]);
        float maxAbs = fabsf(maxs[axis]);

        corner[axis] = minAbs > maxAbs ? minAbs : maxAbs;
    }

#if EMULATE_X87
    return (float)CoduoLibm_Sqrt(x87f_store_f64(x87f_add(
        x87f_add(x87f_mul(x87f_load_f32(corner[0]), x87f_load_f32(corner[0])),
                 x87f_mul(x87f_load_f32(corner[1]), x87f_load_f32(corner[1]))),
        x87f_mul(x87f_load_f32(corner[2]), x87f_load_f32(corner[2])))));
#else
    return (float)CoduoLibm_Sqrt((double)(corner[0] * corner[0] +
                                corner[1] * corner[1] +
                                corner[2] * corner[2]));
#endif
}

/* VERIFIED_DECOMPILER(0x3e24a, 4e24a_AnglesToAxis.c, VERIFY-WAVE4-COMMON-MATH-08-2026-06-17): DATAFLOW_VERIFIED - AngleVectors destination slots and negated right-vector axis stores checked. */
/* 0x3e24a AnglesToAxis */
void AnglesToAxis(const float *angles, float *axis)
{
    vec3_t right;
    const volatile float *originZero = vec3_origin;

    AngleVectors(angles, axis, right, &axis[6]);
    /* 0x3e285..0x3e2b8: the negation is computed as vec3_origin[i] - right[i]
       (fld global; fsub), which differs from -right[i] on the sign of zero. */
    axis[3] = originZero[0] - right[0];
    axis[4] = originZero[1] - right[1];
    axis[5] = originZero[2] - right[2];
}

/* VERIFIED_DECOMPILER(0x3e2c0, 4e2c0_YawToAxis.c, VERIFY-WAVE4-COMMON-MATH-08-2026-06-17): DATAFLOW_VERIFIED - YawVectors destination slots, up-axis constant stores, and negated right-vector axis stores checked. */
/* 0x3e2c0 YawToAxis */
void YawToAxis(float yaw, float *axis)
{
    vec3_t right;
    const volatile float *originZero = vec3_origin;
    uint32_t bits = 0;

    YawVectors(yaw, axis, right);
    memcpy(&axis[6], &bits, sizeof(bits));
    memcpy(&axis[7], &bits, sizeof(bits));
    bits = FLOAT_ONE_BITS;
    memcpy(&axis[8], &bits, sizeof(bits));
    /* 0x3e315..0x3e348: the negation is computed as vec3_origin[i] - right[i]
       (fld global; fsub), which differs from -right[i] on the sign of zero. */
    axis[3] = originZero[0] - right[0];
    axis[4] = originZero[1] - right[1];
    axis[5] = originZero[2] - right[2];
}

/* NOT_FROM_ORIGINAL_SOURCE: shared extraction of roll recovery used by AxisToAngles variants. */
static void game_compat_axis_to_angles_roll(const float *axisRight, float *angles)
{
    float right0;
    float right1;
    float right2;
    float radians;
    float sine;
    float cosine;
    float rotated0;
    vec3_t rotated;
    float roll;
    uint32_t bits;

    memcpy(&right0, &axisRight[0], sizeof(right0));
    memcpy(&right1, &axisRight[1], sizeof(right1));
    memcpy(&right2, &axisRight[2], sizeof(right2));

#if EMULATE_X87
#define RAD(a)                                                             \
    x87f_store_f32(x87f_div(                                                   \
        x87f_mul(x87f_neg(x87f_load_f32(a)), x87f_load_f64(DOUBLE_PI)),    \
        x87f_load_f64((double)DEGREES_PER_RADIAN)))
    radians = RAD(angles[1]);
    SinCosFloat(radians, &sine, &cosine);
    rotated0 = x87f_store_f32(
        x87f_sub(x87f_mul(x87f_load_f32(cosine), x87f_load_f32(right0)),
                 x87f_mul(x87f_load_f32(sine), x87f_load_f32(right1))));
    right1 = x87f_store_f32(
        x87f_add(x87f_mul(x87f_load_f32(sine), x87f_load_f32(right0)),
                 x87f_mul(x87f_load_f32(cosine), x87f_load_f32(right1))));
    radians = RAD(angles[0]);
    SinCosFloat(radians, &sine, &cosine);
    rotated[0] = x87f_store_f32(
        x87f_add(x87f_mul(x87f_load_f32(sine), x87f_load_f32(right2)),
                 x87f_mul(x87f_load_f32(cosine), x87f_load_f32(rotated0))));
    memcpy(&bits, &right1, sizeof(bits));
    memcpy(&rotated[1], &bits, sizeof(bits));
    rotated[2] = x87f_store_f32(
        x87f_sub(x87f_mul(x87f_load_f32(cosine), x87f_load_f32(right2)),
                 x87f_mul(x87f_load_f32(sine), x87f_load_f32(rotated0))));
#undef RAD
#else
    radians = (float)((double)-angles[1] * DOUBLE_PI /
                      (double)DEGREES_PER_RADIAN);
    SinCosFloat(radians, &sine, &cosine);
    rotated0 = cosine * right0 - sine * right1;
    right1 = sine * right0 + cosine * right1;
    radians = (float)((double)-angles[0] * DOUBLE_PI /
                      (double)DEGREES_PER_RADIAN);
    SinCosFloat(radians, &sine, &cosine);

    rotated[0] = sine * right2 + cosine * rotated0;
    memcpy(&bits, &right1, sizeof(bits));
    memcpy(&rotated[1], &bits, sizeof(bits));
    rotated[2] = cosine * right2 - sine * rotated0;
#endif
    roll = vectosignedpitch(rotated);

    if (right1 < 0.0f) {
        if (roll < 0.0f) {
            angles[2] = DEGREES_PER_HALF_CIRCLE + roll;
        } else {
            angles[2] = -DEGREES_PER_HALF_CIRCLE + roll;
        }
    } else {
        memcpy(&bits, &roll, sizeof(bits));
        bits ^= FLOAT_SIGN_BIT_MASK;
        memcpy(&angles[2], &bits, sizeof(bits));
    }
}

/* VERIFIED_DECOMPILER(0x3e350, 4e350_AxisToAngles.c, VERIFY-WAVE4-COMMON-MATH-09-2026-06-17): DATAFLOW_VERIFIED - vectoangles call, axis[3] right-vector offset, and extracted roll recovery sequence checked. */
/* 0x3e350 AxisToAngles */
void AxisToAngles(const float *axis, float *angles)
{
    vectoangles(axis, angles);
    game_compat_axis_to_angles_roll(&axis[3], angles);
}

/* VERIFIED_DECOMPILER(0x3e4c8, 4e4c8_Axis4ToAngles.c, VERIFY-WAVE4-COMMON-MATH-09-2026-06-17): DATAFLOW_VERIFIED - vectoangles call, axis[4] right-vector offset, and extracted roll recovery sequence checked. */
/* 0x3e4c8 Axis4ToAngles */
void Axis4ToAngles(const float *axis, float *angles)
{
    vectoangles(axis, angles);
    game_compat_axis_to_angles_roll(&axis[4], angles);
}

/* VERIFIED_DECOMPILER(0x3e640, 4e640_AxisToSignedAngles.c, VERIFY-WAVE4-COMMON-MATH-09-2026-06-17): DATAFLOW_VERIFIED - vectosignedangles call, axis[3] right-vector offset, and extracted roll recovery sequence checked. */
/* 0x3e640 AxisToSignedAngles */
void AxisToSignedAngles(const float *axis, float *angles)
{
    vectosignedangles(axis, angles);
    game_compat_axis_to_angles_roll(&axis[3], angles);
}

/* VERIFIED_DECOMPILER(0x3e7b8, 4e7b8_PlaneFromPoints.c, VERIFY-WAVE4-COMMON-MATH-09-2026-06-17): DATAFLOW_VERIFIED - dir vectors, CrossProduct argument order, VectorNormalize return test, plane distance store, and boolean return checked. */
/* 0x3e7b8 PlaneFromPoints */
int PlaneFromPoints(float *plane, const float *a, const float *b, const float *c)
{
    vec3_t dir1;
    vec3_t dir2;
    float length;

    dir1[0] = b[0] - a[0];
    dir1[1] = b[1] - a[1];
    dir1[2] = b[2] - a[2];
    dir2[0] = c[0] - a[0];
    dir2[1] = c[1] - a[1];
    dir2[2] = c[2] - a[2];

    CrossProduct(dir2, dir1, plane);
    length = VectorNormalize(plane);
    if (length != 0.0f) {
#if EMULATE_X87
        plane[3] =
            X87_D3(a[0], plane[0], a[1], plane[1], a[2], plane[2]);
#else
        plane[3] = a[0] * plane[0] + a[1] * plane[1] + a[2] * plane[2];
#endif
    }
    return length != 0.0f;
}

/* VERIFIED_DECOMPILER(0x3e8b6, 4e8b6_ProjectPointOnPlane.c, VERIFY-WAVE4-COMMON-MATH-09-2026-06-17): DATAFLOW_VERIFIED - inverse-length-squared calculation, dot scale, decompiler's second inverse scale factor, and dst stores checked. */
/* 0x3e8b6 ProjectPointOnPlane */
void ProjectPointOnPlane(float *dst, const float *point, const float *normal)
{
    /* ORIGINAL_BINARY_BUG: after dot(point, normal) is scaled by 1/|normal|^2,
       stock scales normal by the same reciprocal again. Non-unit normals are
       therefore projected with 1/|normal|^4. Preserved; see
       original-bugs/game-project-point-on-plane-double-inverse.md. */
    /* 0x3e8f6: the squared length is stored to a float slot before the divide. */
#if EMULATE_X87
    float lengthSquared = x87f_store_f32(x87f_add(
        x87f_add(x87f_mul(x87f_load_f32(normal[0]), x87f_load_f32(normal[0])),
                 x87f_mul(x87f_load_f32(normal[1]), x87f_load_f32(normal[1]))),
        x87f_mul(x87f_load_f32(normal[2]), x87f_load_f32(normal[2]))));
    float invLenSq = x87f_store_f32(
        x87f_div(x87f_load_f32(1.0f), x87f_load_f32(lengthSquared)));
    float dotScale = x87f_store_f32(x87f_mul(
        x87f_add(
            x87f_add(x87f_mul(x87f_load_f32(normal[0]), x87f_load_f32(point[0])),
                     x87f_mul(x87f_load_f32(normal[1]),
                              x87f_load_f32(point[1]))),
            x87f_mul(x87f_load_f32(normal[2]), x87f_load_f32(point[2]))),
        x87f_load_f32(invLenSq)));
    /* 0x3e941: the x factor is stored to a float slot like the other two. */
    float scaled0 = x87f_store_f32(
        x87f_mul(x87f_load_f32(normal[0]), x87f_load_f32(invLenSq)));
    float scaled1 = x87f_store_f32(
        x87f_mul(x87f_load_f32(normal[1]), x87f_load_f32(invLenSq)));
    float scaled2 = x87f_store_f32(
        x87f_mul(x87f_load_f32(normal[2]), x87f_load_f32(invLenSq)));

    dst[0] = x87f_store_f32(x87f_sub(
        x87f_load_f32(point[0]),
        x87f_mul(x87f_load_f32(dotScale), x87f_load_f32(scaled0))));
    dst[1] = x87f_store_f32(x87f_sub(
        x87f_load_f32(point[1]),
        x87f_mul(x87f_load_f32(dotScale), x87f_load_f32(scaled1))));
    dst[2] = x87f_store_f32(x87f_sub(
        x87f_load_f32(point[2]),
        x87f_mul(x87f_load_f32(dotScale), x87f_load_f32(scaled2))));
#else
    float lengthSquared = normal[0] * normal[0] +
                          normal[1] * normal[1] +
                          normal[2] * normal[2];
    float invLenSq = 1.0f / lengthSquared;
    float dotScale = (normal[0] * point[0] +
                      normal[1] * point[1] +
                      normal[2] * point[2]) * invLenSq;
    /* 0x3e941: the x factor is stored to a float slot like the other two. */
    float scaled0 = normal[0] * invLenSq;
    float scaled1 = normal[1] * invLenSq;
    float scaled2 = normal[2] * invLenSq;

    dst[0] = point[0] - dotScale * scaled0;
    dst[1] = point[1] - dotScale * scaled1;
    dst[2] = point[2] - dotScale * scaled2;
#endif
}

/* VERIFIED_DECOMPILER(0x3ea0e, 4ea0e_BoxDistSqrdExceeds.c, VERIFY-WAVE4-COMMON-MATH-10-2026-06-17): DATAFLOW_VERIFIED - min/max deltas, same-side axis test, smaller squared-distance accumulation, and threshold comparison checked. */
/* 0x3ea0e BoxDistSqrdExceeds */
int BoxDistSqrdExceeds(const float *mins, const float *maxs, const float *origin,
                       float threshold)
{
    vec3_t minDelta;
    vec3_t maxDelta;
    float distSqrd = 0.0f;

    minDelta[0] = mins[0] - origin[0];
    minDelta[1] = mins[1] - origin[1];
    minDelta[2] = mins[2] - origin[2];
    maxDelta[0] = maxs[0] - origin[0];
    maxDelta[1] = maxs[1] - origin[1];
    maxDelta[2] = maxs[2] - origin[2];

    for (int axis = 0; axis < 3; axis++) {
        if (minDelta[axis] * maxDelta[axis] > 0.0f) {
            float minSqrd = minDelta[axis] * minDelta[axis];
            float maxSqrd = maxDelta[axis] * maxDelta[axis];

            if (maxSqrd < minSqrd) {
                distSqrd += maxSqrd;
            } else {
                distSqrd += minSqrd;
            }
        }
    }

    return distSqrd > threshold;
}

/* VERIFIED_DECOMPILER(0x3eb22, 4eb22_NormalToLatLong.c, VERIFY-WAVE4-COMMON-MATH-10-2026-06-17): DATAFLOW_VERIFIED - vertical normal special cases, atan2/acos argument order, 255/360 scale, and x87 rounded byte stores checked. */
/* 0x3eb22 NormalToLatLong */
void NormalToLatLong(const float *normal, uint8_t *bytes)
{
    if (normal[0] == 0.0f && normal[1] == 0.0f) {
        if (normal[2] > 0.0f) {
            bytes[0] = 0;
            bytes[1] = 0;
        } else {
            bytes[0] = NORMAL_LATLONG_NEGATIVE_Z_BYTE;
            bytes[1] = 0;
        }
    } else {
#if EMULATE_X87
        /* ((atan2/acos * 180) / pi) * scale in 80-bit, then the fistp-word
         * truncation done directly on the 80-bit value. */
        x87f longitude = x87f_mul(
            x87f_div(x87f_mul(x87f_load_f64(atan2((double)normal[1],
                                                  (double)normal[0])),
                              x87f_load_f64(DEGREES_PER_RADIAN)),
                     x87f_load_f64(DOUBLE_PI)),
            x87f_load_f64(NORMAL_LATLONG_SCALE));
        uint8_t longitudeByte =
            game_compat_x87_fistp_word_low_byte_x87(longitude);
        x87f latitude = x87f_mul(
            x87f_div(x87f_mul(x87f_load_f64(CoduoLibm_Acos((double)normal[2])),
                              x87f_load_f64(DEGREES_PER_RADIAN)),
                     x87f_load_f64(DOUBLE_PI)),
            x87f_load_f64(NORMAL_LATLONG_SCALE));

        bytes[0] = game_compat_x87_fistp_word_low_byte_x87(latitude);
        bytes[1] = longitudeByte;
#elif defined(__x86_64__)
        static const double degrees = (double)DEGREES_PER_RADIAN;
        static const double pi = DOUBLE_PI;
        static const double scale = (double)NORMAL_LATLONG_SCALE;
        double longitudeRadians =
            atan2((double)normal[1], (double)normal[0]);
        uint8_t longitudeByte = (uint8_t)CODUO_X87_TRUNCATE_I16(
            ((long double)longitudeRadians * (long double)degrees /
              (long double)pi) *
            (long double)scale);
        double latitudeRadians = CoduoLibm_Acos((double)normal[2]);

        bytes[0] = (uint8_t)CODUO_X87_TRUNCATE_I16(
            ((long double)latitudeRadians * (long double)degrees /
              (long double)pi) *
            (long double)scale);
        bytes[1] = longitudeByte;
#else
        uint8_t longitudeByte = (uint8_t)(int16_t)
            ((atan2((double)normal[1], (double)normal[0]) *
              DEGREES_PER_RADIAN / DOUBLE_PI) *
             NORMAL_LATLONG_SCALE);

        bytes[0] = (uint8_t)(int16_t)
            ((CoduoLibm_Acos((double)normal[2]) *
              DEGREES_PER_RADIAN / DOUBLE_PI) *
             NORMAL_LATLONG_SCALE);
        bytes[1] = longitudeByte;
#endif
    }
}

/* VERIFIED_DECOMPILER(0x3ec50, 4ec50_Vec10Copy.c, VERIFY-WAVE4-COMMON-MATH-10-2026-06-17): DATAFLOW_VERIFIED - ten 32-bit lane copies checked. */
/* 0x3ec50 Vec10Copy: named imported helper, copies ten 32-bit lanes. */
void Vec10Copy(const uint32_t *in, uint32_t *out)
{
    for (int index = 0; index < 10; index++) {
        out[index] = in[index];
    }
}

/* VERIFIED_DECOMPILER(0x3ecef, 4ecef_Q_rint.c, VERIFY-WAVE4-COMMON-MATH-10-2026-06-17): DATAFLOW_VERIFIED - value+0.5 expression, double floor call, float narrowing, and x87 return checked. */
/* 0x3ecef Q_rint */
float Q_rint(float value)
{
    return (float)floor((double)value + 0.5);
}

/* VERIFIED_DECOMPILER(0x3ed26, 4ed26_ColorNormalize.c, VERIFY-WAVE4-COMMON-MATH-10-2026-06-17): DATAFLOW_VERIFIED - max-channel comparisons, white zero fallback, reciprocal scale, normalized stores, and return value checked. */
/* 0x3ed26 ColorNormalize */
float ColorNormalize(const float *in, float *out)
{
    float max;

    memcpy(&max, &in[0], sizeof(max));

    if (max < in[1]) {
        memcpy(&max, &in[1], sizeof(max));
    }
    if (max < in[2]) {
        memcpy(&max, &in[2], sizeof(max));
    }

    if (max == 0.0f) {
        uint32_t oneBits = FLOAT_ONE_BITS;

        memcpy(&out[2], &oneBits, sizeof(oneBits));
        memcpy(&out[1], &oneBits, sizeof(oneBits));
        memcpy(&out[0], &oneBits, sizeof(oneBits));
        return 0.0f;
    }

    {
        /* 0x3edc8: the reciprocal is stored to a float slot once and reused. */
        float scale = 1.0f / max;

        out[0] = in[0] * scale;
        out[1] = in[1] * scale;
        out[2] = in[2] * scale;
    }

    return max;
}

/* VERIFIED_DECOMPILER(0x3ee0e, 4ee0e_VectorRotateAngles.c, VERIFY-WAVE4-COMMON-MATH-11-2026-06-17): DATAFLOW_VERIFIED - lane table, per-axis nonzero/NaN branch, double sin/cos helper, temp copy, rotated lane formulas, and output stores checked. */
/* 0x3ee0e VectorRotateAngles */
void VectorRotateAngles(const float *in, const float *angles, float *out)
{
    vec3_t previous;
    vec3_t rotated;
    uint32_t bits;

    memcpy(&bits, &in[0], sizeof(bits));
    memcpy(&previous[0], &bits, sizeof(bits));
    memcpy(&bits, &in[1], sizeof(bits));
    memcpy(&previous[1], &bits, sizeof(bits));
    memcpy(&bits, &in[2], sizeof(bits));
    memcpy(&previous[2], &bits, sizeof(bits));

    memcpy(&bits, &previous[0], sizeof(bits));
    memcpy(&rotated[0], &bits, sizeof(bits));
    memcpy(&bits, &previous[1], sizeof(bits));
    memcpy(&rotated[1], &bits, sizeof(bits));
    memcpy(&bits, &previous[2], sizeof(bits));
    memcpy(&rotated[2], &bits, sizeof(bits));

    {
        const int lanes[3][2] = {
            {1, 2},
            {2, 0},
            {0, 1},
        };

        for (int axis = 0; axis < 3; axis++) {
            if (angles[axis] != 0.0f) {
                double sine;
                double cosine;
                int lane0 = lanes[axis][0];
                int lane1 = lanes[axis][1];
#if EMULATE_X87
                double radians = x87f_store_f64(x87f_div(
                    x87f_mul(x87f_load_f32(angles[axis]),
                             x87f_load_f64(DOUBLE_PI)),
                    x87f_load_f64((double)DEGREES_PER_RADIAN)));
#else
                double radians = ((double)angles[axis] * DOUBLE_PI) /
                                 (double)DEGREES_PER_RADIAN;
#endif

                SinCosDouble(radians, &sine, &cosine);
#if EMULATE_X87
                rotated[lane0] = x87f_store_f32(x87f_sub(
                    x87f_mul(x87f_load_f32(previous[lane0]),
                             x87f_load_f64(cosine)),
                    x87f_mul(x87f_load_f32(previous[lane1]),
                             x87f_load_f64(sine))));
                rotated[lane1] = x87f_store_f32(x87f_add(
                    x87f_mul(x87f_load_f32(previous[lane0]),
                             x87f_load_f64(sine)),
                    x87f_mul(x87f_load_f32(previous[lane1]),
                             x87f_load_f64(cosine))));
#else
                rotated[lane0] = (float)((double)previous[lane0] * cosine -
                                         (double)previous[lane1] * sine);
                rotated[lane1] = (float)((double)previous[lane0] * sine +
                                         (double)previous[lane1] * cosine);
#endif
            }

            memcpy(&bits, &rotated[0], sizeof(bits));
            memcpy(&previous[0], &bits, sizeof(bits));
            memcpy(&bits, &rotated[1], sizeof(bits));
            memcpy(&previous[1], &bits, sizeof(bits));
            memcpy(&bits, &rotated[2], sizeof(bits));
            memcpy(&previous[2], &bits, sizeof(bits));
        }
    }

    memcpy(&bits, &rotated[0], sizeof(bits));
    memcpy(&out[0], &bits, sizeof(bits));
    memcpy(&bits, &rotated[1], sizeof(bits));
    memcpy(&out[1], &bits, sizeof(bits));
    memcpy(&bits, &rotated[2], sizeof(bits));
    memcpy(&out[2], &bits, sizeof(bits));
}

/* VERIFIED_DECOMPILER(0x3ef8d, 4ef8d_VectorRotateAnglesAroundPoint.c, VERIFY-WAVE4-COMMON-MATH-11-2026-06-17): DATAFLOW_VERIFIED - point-origin delta, VectorRotateAngles call, and origin re-add output stores checked. */
/* 0x3ef8d VectorRotateAnglesAroundPoint */
void VectorRotateAnglesAroundPoint(const float *point, const float *angles,
                                   const float *origin, float *out)
{
    vec3_t relative;
    vec3_t rotated;

    relative[0] = point[0] - origin[0];
    relative[1] = point[1] - origin[1];
    relative[2] = point[2] - origin[2];
    VectorRotateAngles(relative, angles, rotated);
    out[0] = rotated[0] + origin[0];
    out[1] = rotated[1] + origin[1];
    out[2] = rotated[2] + origin[2];
}

/* VERIFIED_DECOMPILER(0x3f024, 4f024_VectorPolar.c, VERIFY-WAVE4-COMMON-MATH-11-2026-06-17): DATAFLOW_VERIFIED - two repeated sin/cos calls on same angle and radius-scaled xyz formulas checked. */
/* 0x3f024 VectorPolar */
void VectorPolar(float *out, float radius, float angle)
{
    float sine0;
    float cosine0;
    float sine1;
    float cosine1;

    SinCosFloat(angle, &sine0, &cosine0);
    SinCosFloat(angle, &sine1, &cosine1);
    out[0] = radius * cosine0 * cosine1;
    out[1] = radius * sine0 * cosine1;
    out[2] = radius * sine1;
}

/* VERIFIED_DECOMPILER(0x3f08b, 4f08b_VectorSnap.c, VERIFY-WAVE4-COMMON-MATH-11-2026-06-17): DATAFLOW_VERIFIED - xyz floor(value+0.5) sequence and float stores checked. */
/* 0x3f08b VectorSnap */
void VectorSnap(float *vec)
{
    vec[0] = (float)floor((double)vec[0] + 0.5);
    vec[1] = (float)floor((double)vec[1] + 0.5);
    vec[2] = (float)floor((double)vec[2] + 0.5);
}

/* VERIFIED_DECOMPILER(0x3f0ff, 4f0ff__Vector5Add.c, VERIFY-WAVE4-COMMON-MATH-11-2026-06-17): DATAFLOW_VERIFIED - five float lane additions and stores checked. */
/* 0x3f0ff _Vector5Add: named imported helper, adds five float lanes. */
void _Vector5Add(const float *a, const float *b, float *out)
{
    for (int index = 0; index < 5; index++) {
        out[index] = a[index] + b[index];
    }
}

/* VERIFIED_DECOMPILER(0x3f173, 4f173__Vector5Scale.c, VERIFY-WAVE4-COMMON-MATH-11-2026-06-17): DATAFLOW_VERIFIED - five float lane scale operations and stores checked. */
/* 0x3f173 _Vector5Scale: named imported helper, scales five float lanes. */
void _Vector5Scale(const float *in, float scale, float *out)
{
    for (int index = 0; index < 5; index++) {
        out[index] = in[index] * scale;
    }
}

/* VERIFIED_DECOMPILER(0x3f1d1, 4f1d1__Vector53Copy.c, VERIFY-WAVE4-COMMON-MATH-11-2026-06-17): DATAFLOW_VERIFIED - three 32-bit lane copies checked. */
/* 0x3f1d1 _Vector53Copy: named imported helper, copies three 32-bit lanes. */
void _Vector53Copy(const uint32_t *in, uint32_t *out)
{
    out[0] = in[0];
    out[1] = in[1];
    out[2] = in[2];
}

/* VERIFIED_DECOMPILER(0x3f200, 4f200_RoundFloat.c, VERIFY-WAVE4-COMMON-MATH-11-2026-06-17): DATAFLOW_VERIFIED - pow(10) scale, modf whole/fraction split, +/-0.5 rounding branches, pow(0.1) unscale, float narrowing, and x87 return checked. */
/* 0x3f200 RoundFloat */
float RoundFloat(float value, int decimals)
{
    double scaled = pow(10.0, (double)decimals) * (double)value;
    double whole;
    double fraction = modf(scaled, &whole);

    if (fraction >= 0.5) {
        whole += 1.0;
    } else if (fraction <= -0.5) {
        whole -= 1.0;
    }

    return (float)(pow(0.1, (double)decimals) * whole);
}

/* VERIFIED_DECOMPILER(0x3f2c9, 4f2c9_PitchForYawOnNormal.c, VERIFY-WAVE4-COMMON-MATH-11-2026-06-17): DATAFLOW_VERIFIED - YawVectors call, ProjectPointOnPlane call, and vectopitch tail-call checked; original i386 disassembly at 0x3f314 preserves the x87 return despite Ghidra's void inference. */
/* 0x3f2c9 PitchForYawOnNormal */
float PitchForYawOnNormal(float yaw, const float *normal)
{
    vec3_t forward;
    vec3_t projected;

    YawVectors(yaw, forward, 0);
    ProjectPointOnPlane(projected, forward, normal);
    return vectopitch(projected);
}

/* VERIFIED_DECOMPILER(0x3f31f, 4f31f_Rand_Init.c, VERIFY-WAVE4-COMMON-MATH-11-2026-06-17): DATAFLOW_VERIFIED - shared rand seed store checked. */
/* 0x3f31f Rand_Init */
void Rand_Init(uint32_t seed)
{
    shared_rand_seed = seed;
}

/* NOT_FROM_ORIGINAL_SOURCE: local shared rand step factored from flrand/irand. */
static uint32_t game_compat_shared_rand_next(void)
{
    shared_rand_seed = shared_rand_seed * SHARED_RAND_MULTIPLIER +
                          SHARED_RAND_INCREMENT;
    return shared_rand_seed >> SHARED_RAND_SHIFT;
}

/* VERIFIED_DECOMPILER(0x3f33a, 4f33a_flrand.c, VERIFY-WAVE4-COMMON-MATH-11-2026-06-17): DATAFLOW_VERIFIED - shared LCG step extraction, shift, 32768.0 denominator, min/max interpolation, and float/x87 return checked. */
/* 0x3f33a flrand */
float flrand(float min, float max)
{
    return (((max - min) * (float)game_compat_shared_rand_next()) /
            SHARED_RAND_FLOAT_DENOMINATOR) + min;
}

/* VERIFIED_DECOMPILER(0x3f3a3, 4f3a3_irand.c, VERIFY-WAVE4-COMMON-MATH-11-2026-06-17): DATAFLOW_VERIFIED - shared LCG step extraction, shift, signed product, final >>15 scale, and min addition checked. */
/* 0x3f3a3 irand */
int irand(int min, int max)
{
    uint32_t rangeBits = (uint32_t)max - (uint32_t)min;
    uint32_t productBits =
        rangeBits * game_compat_shared_rand_next();
    uint32_t resultBits =
        coduo_int32_sar_bits(productBits, 15U) + (uint32_t)min;

    return coduo_int32_from_bits(resultBits);
}

/* VERIFIED_DECOMPILER(0x3f3f6, 4f3f6_Q_SwayRand.c, VERIFY-WAVE4-COMMON-MATH-11-2026-06-17): DATAFLOW_VERIFIED - msec/1000 scale, doubled sine/cosine angles, double libm calls, product, float narrowing, and x87 return checked. */
/* 0x3f3f6 Q_SwayRand */
float Q_SwayRand(float a, float b, float msec)
{
    /* 0x3f408..0x3f422 / 0x3f42d..0x3f447: the angle chains never leave the x87
       registers; only the sin/cos call arguments round to double. */
    long double seconds = (long double)msec /
                          (long double)MILLISECONDS_PER_SECOND;
    long double sineAngle = (long double)a * seconds * DOUBLE_PI;
    double sine = CoduoLibm_Sin((double)(sineAngle + sineAngle));
    long double cosineAngle = (long double)b * seconds * DOUBLE_PI;
    double cosine = CoduoLibm_Cos((double)(cosineAngle + cosineAngle));

    return (float)((long double)cosine * (long double)sine);
}

/* VERIFIED_DECOMPILER(0x3f464, 4f464_FUN_0004f464.c, VERIFY-WAVE4-COMMON-MATH-11-2026-06-17): DATAFLOW_VERIFIED - binary32 load, single fsincos operation, and cosine-then-sine binary32 stores checked. */
/* 0x3f464 SinCosFloat */
/* Stock executes one x87 fsincos on the binary32 argument and stores cosine
 * before sine.  Native x87 targets use that exact instruction; only non-x87
 * targets retain the permitted libm fallback. */
static void SinCosFloat(float radians, float *sine, float *cosine)
{
#if defined(__i386__) || defined(__x86_64__)
    coduo_x87_sincosf(radians, sine, cosine);
#else
    long double angle = (long double)radians;

    *cosine = (float)cosl(angle);
    *sine = (float)sinl(angle);
#endif
}

/* VERIFIED_DECOMPILER(0x3f47c, 4f47c_FUN_0004f47c.c, VERIFY-WAVE4-COMMON-MATH-11-2026-06-17): DATAFLOW_VERIFIED - double sin/cos calls and sine/cosine destination order checked. */
/* 0x3f47c SinCosDouble */
static void SinCosDouble(double radians, double *sine, double *cosine)
{
    *sine = CoduoLibm_Sin(radians);
    *cosine = CoduoLibm_Cos(radians);
}
