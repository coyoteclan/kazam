#ifndef G_PUBLIC_H
#define G_PUBLIC_H

#include <stdint.h>
#include "recovered_game.h"
#include "g_syscalls.h"

/*
 * vmMain command codes.
 * These are the command values passed to vmMain by the engine.
 */
typedef enum {
    GAME_GET_API_VERSION = 1,        /* Returns API version (5) */
    GAME_INIT = 2,                    /* G_InitGame(levelTime, randomSeed, restart, cvarRestartGate) */
    GAME_SHUTDOWN = 3,                /* G_ShutdownGame(restart) */
    GAME_CLIENT_CONNECT = 4,          /* ClientConnect(clientNum, persistentValue) */
    GAME_CLIENT_BEGIN = 5,            /* ClientBegin(clientNum) */
    GAME_CLIENT_USERINFO_CHANGED = 6, /* ClientUserinfoChanged(clientNum) */
    GAME_CLIENT_DISCONNECT = 7,       /* ClientDisconnect(clientNum) */
    GAME_CLIENT_COMMAND = 8,          /* ClientCommand(clientNum) */
    GAME_CLIENT_THINK = 9,            /* ClientThink(clientNum) */
    GAME_GET_FOLLOW_PLAYER_STATE = 10, /* GetFollowPlayerState(clientNum, ps) */
    GAME_UPDATE_CVARS = 11,           /* G_UpdateCvars() */
    GAME_RUN_FRAME = 12,              /* G_RunFrame(levelTime) */
    GAME_CONSOLE_COMMAND = 13,        /* ConsoleCommand() */
    GAME_SCRIPT_FAR_HOOK = 14,        /* Scr_FarHook(engineCallbacks) */
    GAME_DOBJ_CALC_POSE = 15,         /* G_DObjCalcPose(entNum) */
    GAME_IS_VALID_WEAPON = 16,        /* Returns 1 if weapon index is valid */
    GAME_SET_MATCH_STATE = 17,        /* Sets match state variable */
    GAME_GET_MATCH_STATE = 18,        /* Gets match state variable */
    GAME_GET_CLIENT_SESSION = 19,     /* Returns session state pointer */
    GAME_GET_CLIENT_ARCHIVE_TIME = 20, /* Returns archive time for client */
    GAME_SET_CLIENT_ARCHIVE_TIME = 21, /* Sets archive time for client */
    GAME_GET_CLIENT_SCORE = 22,        /* Returns score for client */
    GAME_GET_FOG_OPAQUE_DIST_SQ_BITS = 23 /* Returns raw fogOpaqueDistSq float bits */
} game_command_t;

/*
 * Module export prototypes.
 * These functions are exported to the engine via the VM interface.
 */
extern intptr_t vmMain(int32_t command, intptr_t arg0, intptr_t arg1,
                       intptr_t arg2, intptr_t arg3, intptr_t arg4,
                       intptr_t arg5, intptr_t arg6, intptr_t arg7,
                       intptr_t arg8, intptr_t arg9, intptr_t arg10,
                       intptr_t arg11);
extern void dllEntry(game_syscall_t syscallPtr);

/*
 * Game lifecycle functions called by vmMain.
 */
extern void G_InitGame(int levelTime, int randomSeed, int restart,
                       int cvarRestartGate);
extern void G_ShutdownGame(int restart);
extern char *ClientConnect(int clientNum, uint16_t persistentValue);
extern void ClientBegin(int clientNum);
extern void ClientUserinfoChanged(int clientNum);
extern void ClientDisconnect(int clientNum);
extern void ClientCommand(int clientNum);
extern void ClientThink(int clientNum);
extern qboolean GetFollowPlayerState(int clientNum, void *playerState);
extern void G_RunFrame(int levelTime);
extern void G_UpdateCvars(void);
extern int ConsoleCommand(void);
extern void G_DObjCalcPose(gentity_t *ent);

#endif /* G_PUBLIC_H */
