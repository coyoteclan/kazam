# Project Boundary

This repository is the public source export for CoD:UO dedicated-server
component work.

It includes maintained, compileable source:

- game-module C sources and headers;
- dedicated-server engine C/C++ sources and headers;
- public build and status documentation.

It intentionally excludes private recovery workspace material:

- local agent instructions, private goals, and working notes;
- operational host notes and server-access material;
- private analysis directories, including generated output, Ghidra scripts, evidence notes,
  task ledgers, unknown ledgers, overlays, schemas, and manifests;
- retail binaries, raw proprietary payloads, Ghidra databases, and bulk
  generated decompiler output;
- local build artifacts and caches.

The public source is intended to be understandable and buildable without the
private analysis workspace. Evidence-backed recovery work continues privately,
then reviewed source and public-safe documentation are exported here.
