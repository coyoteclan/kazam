#ifndef CODUO_ENGINE_ABI_H
#define CODUO_ENGINE_ABI_H

/*
 * Engine/game boundary for the CoD:UO Linux dedicated host.
 *
 * The vmMain command IDs and syscall IDs are corroborated by the recovered
 * game module and the existing host shim. Native loader strings in
 * coduo_lnxded also confirm the exported symbol names "dllEntry" and "vmMain".
 */

#include <stdint.h>
#include <stddef.h>
#include "coduo_engine_platform.h"
#include "q_shared_types.h"

#ifdef __cplusplus
extern "C" {
#endif

#define CODUO_GAME_API_VERSION 5

typedef enum coduo_script_variable_type_e {
    CODUO_SCRIPT_VAR_UNDEFINED = 0,
    CODUO_SCRIPT_VAR_STRING = 1,
    CODUO_SCRIPT_VAR_LOCALIZED_STRING = 2,
    CODUO_SCRIPT_VAR_VECTOR = 3,
    CODUO_SCRIPT_VAR_FLOAT = 4,
    CODUO_SCRIPT_VAR_INT = 5,
    CODUO_SCRIPT_VAR_CODEPOS = 6,
    CODUO_SCRIPT_VAR_OBJECT = 7,
    CODUO_SCRIPT_VAR_KEY_VALUE = 8,
    CODUO_SCRIPT_VAR_FUNCTION = 9,
    CODUO_SCRIPT_VAR_STACK = 10,
    CODUO_SCRIPT_VAR_ANIMATION = 11,
    CODUO_SCRIPT_VAR_THREAD = 12,
    CODUO_SCRIPT_VAR_ENTITY = 13,
    CODUO_SCRIPT_VAR_STRUCT = 14,
    CODUO_SCRIPT_VAR_ARRAY = 15,
    CODUO_SCRIPT_VAR_DEAD_THREAD = 16,
    CODUO_SCRIPT_VAR_DEAD_ENTITY = 17,
    CODUO_SCRIPT_VAR_DEAD_OBJECT = 18,
} coduo_script_variable_type_t;

/*
 * Original i386 Sys_LoadDll builds "<module>.mp.uo.i386.so" in a 0x100-byte
 * local buffer. Native recovered builds use a host-architecture suffix so a
 * 64-bit engine does not accidentally request the legacy i386 module name.
 */
#if defined(_WIN32)
#define CODUO_NATIVE_DLL_FILENAME_FORMAT "uo_%s_mp_x86.dll"
#elif UINTPTR_MAX == UINT32_MAX
#define CODUO_NATIVE_DLL_FILENAME_FORMAT "%s.mp.uo.i386.so"
#else
#define CODUO_NATIVE_DLL_FILENAME_FORMAT "%s.mp.uo.x86_64.so"
#endif
#define CODUO_NATIVE_DLL_ENTRY_SYMBOL "dllEntry"
#define CODUO_NATIVE_DLL_MAIN_SYMBOL "vmMain"

enum {
    CODUO_NATIVE_DLL_LOCAL_NAME_BUFFER_SIZE = 256,
    CODUO_NATIVE_DLL_LOCAL_PATH_BUFFER_SIZE = 256,
    CODUO_NATIVE_DLL_VM_SLOT_PATH_COPY_SIZE = 64,
    CODUO_NATIVE_DLL_DLOPEN_MODE_NOW = 2
};

typedef intptr_t (*coduo_game_syscall_fn)(intptr_t command, ...);
typedef void (*coduo_dll_entry_fn)(coduo_game_syscall_fn syscall_fn);
typedef intptr_t (*coduo_vm_system_call_fn)(
    intptr_t *parms);
typedef void *coduo_native_dll_host_handle_t;
typedef char coduo_native_dll_local_name_buffer_t
    [CODUO_NATIVE_DLL_LOCAL_NAME_BUFFER_SIZE];
typedef char coduo_native_dll_local_path_buffer_t
    [CODUO_NATIVE_DLL_LOCAL_PATH_BUFFER_SIZE];

/*
 * VM_Call in coduo_lnxded pushes callNum plus 12 pointer-sized argument slots
 * before calling the module entry point. Native recovered game modules should
 * expose the full pointer-width signature even when a command consumes fewer
 * arguments.
 */
typedef intptr_t (*coduo_vm_main_fn)(
    int32_t command, intptr_t arg0,
    intptr_t arg1, intptr_t arg2,
    intptr_t arg3, intptr_t arg4,
    intptr_t arg5, intptr_t arg6,
    intptr_t arg7, intptr_t arg8,
    intptr_t arg9, intptr_t arg10,
    intptr_t arg11);

typedef coduo_vm_main_fn *coduo_vm_main_host_entry_out_t;

typedef enum coduo_game_command_e {
    CODUO_GAME_GET_API_VERSION = 1,
    CODUO_GAME_INIT = 2,
    CODUO_GAME_SHUTDOWN = 3,
    CODUO_GAME_CLIENT_CONNECT = 4,
    CODUO_GAME_CLIENT_BEGIN = 5,
    CODUO_GAME_CLIENT_USERINFO_CHANGED = 6,
    CODUO_GAME_CLIENT_DISCONNECT = 7,
    CODUO_GAME_CLIENT_COMMAND = 8,
    CODUO_GAME_CLIENT_THINK = 9,
    CODUO_GAME_GET_FOLLOW_PLAYER_STATE = 10,
    CODUO_GAME_UPDATE_CVARS = 11,
    CODUO_GAME_RUN_FRAME = 12,
    CODUO_GAME_CONSOLE_COMMAND = 13,
    CODUO_GAME_SCRIPT_FAR_HOOK = 14,
    CODUO_GAME_DOBJ_CALC_POSE = 15,
    CODUO_GAME_IS_VALID_WEAPON = 16,
    CODUO_GAME_SET_MATCH_STATE = 17,
    CODUO_GAME_GET_MATCH_STATE = 18,
    CODUO_GAME_GET_CLIENT_SESSION = 19,
    CODUO_GAME_GET_CLIENT_ARCHIVE_TIME = 20,
    CODUO_GAME_SET_CLIENT_ARCHIVE_TIME = 21,
    CODUO_GAME_GET_CLIENT_SCORE = 22,
    CODUO_GAME_GET_FOG_OPAQUE_DIST_SQ_BITS = 23
} coduo_game_command_t;

typedef enum coduo_syscall_id_e {
    CODUO_SYSCALL_PRINTF = 0,
    CODUO_SYSCALL_ERROR = 1,
    CODUO_SYSCALL_ERROR_LOCALIZED = 2,
    CODUO_SYSCALL_MILLISECONDS = 3,
    CODUO_SYSCALL_CVAR_REGISTER = 4,
    CODUO_SYSCALL_CVAR_UPDATE = 5,
    CODUO_SYSCALL_CVAR_SET = 6,
    CODUO_SYSCALL_CVAR_VARIABLE_INTEGER_VALUE = 7,
    CODUO_SYSCALL_CVAR_VARIABLE_VALUE = 8,
    CODUO_SYSCALL_CVAR_VARIABLE_STRING_BUFFER = 9,
    CODUO_SYSCALL_ARGC = 10,
    CODUO_SYSCALL_ARGV = 11,
    CODUO_SYSCALL_HUNK_ALLOC = 12,
    CODUO_SYSCALL_HUNK_ALLOC_LOW = 13,
    CODUO_SYSCALL_HUNK_ALLOC_ALIGN = 14,
    CODUO_SYSCALL_HUNK_ALLOC_LOW_ALIGN = 15,
    CODUO_SYSCALL_HUNK_ALLOC_TEMP = 16,
    CODUO_SYSCALL_HUNK_FREE_TEMP = 17,
    CODUO_SYSCALL_FS_FOPEN_FILE = 18,
    CODUO_SYSCALL_FS_READ = 19,
    CODUO_SYSCALL_FS_WRITE = 20,
    CODUO_SYSCALL_FS_RENAME = 21,
    CODUO_SYSCALL_FS_FCLOSE_FILE = 22,
    CODUO_SYSCALL_SEND_CONSOLE_COMMAND = 23,
    CODUO_SYSCALL_LOCATE_GAME_DATA = 24,
    CODUO_SYSCALL_GET_GUID = 25,
    CODUO_SYSCALL_DROP_CLIENT = 26,
    CODUO_SYSCALL_SEND_SERVER_COMMAND = 27,
    CODUO_SYSCALL_SET_CONFIGSTRING = 28,
    CODUO_SYSCALL_GET_CONFIGSTRING = 29,
    CODUO_SYSCALL_GET_CONFIGSTRING_CONST = 30,
    CODUO_SYSCALL_IS_LOCAL_CLIENT = 31,
    CODUO_SYSCALL_GET_CLIENT_PING = 32,
    CODUO_SYSCALL_GET_USERINFO = 33,
    CODUO_SYSCALL_SET_USERINFO = 34,
    CODUO_SYSCALL_GET_SERVERINFO = 35,
    CODUO_SYSCALL_SET_BRUSH_MODEL = 36,
    CODUO_SYSCALL_TRACE = 37,
    CODUO_SYSCALL_TRACE_CAPSULE = 38,
    CODUO_SYSCALL_SIGHT_TRACE = 39,
    CODUO_SYSCALL_SIGHT_TRACE_CAPSULE = 40,
    CODUO_SYSCALL_SIGHT_TRACE_TO_ENTITY = 41,
    CODUO_SYSCALL_CM_BOX_TRACE = 42,
    CODUO_SYSCALL_CM_CAPSULE_TRACE = 43,
    CODUO_SYSCALL_CM_BOX_SIGHT_TRACE = 44,
    CODUO_SYSCALL_CM_CAPSULE_SIGHT_TRACE = 45,
    CODUO_SYSCALL_LOCATIONAL_TRACE = 46,
    CODUO_SYSCALL_POINT_CONTENTS = 47,
    CODUO_SYSCALL_IN_PVS = 48,
    CODUO_SYSCALL_IN_PVS_IGNORE_PORTALS = 49,
    CODUO_SYSCALL_IN_SNAPSHOT = 50,
    CODUO_SYSCALL_ADJUST_AREA_PORTAL_STATE = 51,
    CODUO_SYSCALL_AREAS_CONNECTED = 52,
    CODUO_SYSCALL_LINK_ENTITY = 53,
    CODUO_SYSCALL_UNLINK_ENTITY = 54,
    CODUO_SYSCALL_ENTITIES_IN_BOX = 55,
    CODUO_SYSCALL_ENTITY_CONTACT = 56,
    CODUO_SYSCALL_GET_USERCMD = 57,
    CODUO_SYSCALL_GET_ENTITY_TOKEN = 58,
    CODUO_SYSCALL_FS_GET_FILE_LIST = 59,
    CODUO_SYSCALL_MAP_EXISTS = 60,
    CODUO_SYSCALL_REAL_TIME = 61,
    CODUO_SYSCALL_SNAP_VECTOR = 62,
    CODUO_SYSCALL_ENTITY_CONTACT_CAPSULE = 63,
    CODUO_SYSCALL_COM_SOUND_ALIAS_STRING = 64,
    CODUO_SYSCALL_COM_PICK_SOUND_ALIAS = 65,
    CODUO_SYSCALL_COM_SOUND_ALIAS_INDEX = 66,
    CODUO_SYSCALL_SURFACE_TYPE_FROM_NAME = 67,
    CODUO_SYSCALL_SURFACE_TYPE_TO_NAME = 68,
    CODUO_SYSCALL_ADD_TEST_CLIENT = 69,
    CODUO_SYSCALL_GET_ARCHIVED_CLIENT_INFO = 70,
    CODUO_SYSCALL_ADD_DEBUG_STRING = 71,
    CODUO_SYSCALL_ADD_DEBUG_LINE = 72,
    CODUO_SYSCALL_SET_ARCHIVE = 73,
    CODUO_SYSCALL_Z_MALLOC = 74,
    CODUO_SYSCALL_Z_FREE = 75,
    CODUO_SYSCALL_XANIM_CREATE_TREE = 76,
    CODUO_SYSCALL_XANIM_CREATE_SMALL_TREE = 77,
    CODUO_SYSCALL_XANIM_FREE_SMALL_TREE = 78,
    CODUO_SYSCALL_XMODEL_EXISTS = 79,
    CODUO_SYSCALL_XMODEL_GET = 80,
    CODUO_SYSCALL_DOBJ_CREATE = 81,
    CODUO_SYSCALL_DOBJ_EXISTS = 82,
    CODUO_SYSCALL_SAFE_DOBJ_FREE = 83,
    CODUO_SYSCALL_XANIM_GET_ANIMS = 84,
    CODUO_SYSCALL_XANIM_CLEAR_TREE_GOAL_WEIGHTS = 86,
    CODUO_SYSCALL_XANIM_CLEAR_GOAL_WEIGHT = 87,
    CODUO_SYSCALL_XANIM_CLEAR_TREE_GOAL_WEIGHTS_STRICT = 88,
    CODUO_SYSCALL_XANIM_SET_COMPLETE_GOAL_WEIGHT_KNOB = 89,
    CODUO_SYSCALL_XANIM_SET_COMPLETE_GOAL_WEIGHT_KNOB_ALL = 90,
    CODUO_SYSCALL_XANIM_SET_ANIM_RATE = 91,
    CODUO_SYSCALL_XANIM_SET_TIME = 92,
    CODUO_SYSCALL_XANIM_SET_GOAL_WEIGHT_KNOB = 93,
    CODUO_SYSCALL_XANIM_CLEAR_TREE = 94,
    CODUO_SYSCALL_XANIM_HAS_TIME = 95,
    CODUO_SYSCALL_XANIM_IS_PRIMITIVE = 96,
    CODUO_SYSCALL_XANIM_GET_LENGTH = 97,
    CODUO_SYSCALL_XANIM_GET_LENGTH_SECONDS = 98,
    CODUO_SYSCALL_XANIM_SET_COMPLETE_GOAL_WEIGHT = 99,
    CODUO_SYSCALL_XANIM_SET_GOAL_WEIGHT = 100,
    CODUO_SYSCALL_XANIM_CALC_ABS_DELTA = 101,
    CODUO_SYSCALL_XANIM_CALC_DELTA = 102,
    CODUO_SYSCALL_XANIM_GET_REL_DELTA = 103,
    CODUO_SYSCALL_XANIM_GET_ABS_DELTA = 104,
    CODUO_SYSCALL_XANIM_IS_LOOPED = 105,
    CODUO_SYSCALL_XANIM_NOTETRACK_EXISTS = 106,
    CODUO_SYSCALL_XANIM_GET_TIME = 107,
    CODUO_SYSCALL_XANIM_GET_WEIGHT = 108,
    CODUO_SYSCALL_DOBJ_DUMP_INFO = 109,
    CODUO_SYSCALL_DOBJ_CREATE_SKEL_FOR_BONE = 110,
    CODUO_SYSCALL_DOBJ_CREATE_SKEL_FOR_BONES = 111,
    CODUO_SYSCALL_DOBJ_UPDATE_SERVER_TIME = 112,
    CODUO_SYSCALL_DOBJ_INIT_SERVER_TIME = 113,
    CODUO_SYSCALL_DOBJ_GET_HIERARCHY_BITS = 114,
    CODUO_SYSCALL_DOBJ_CALC_ANIM = 115,
    CODUO_SYSCALL_DOBJ_CALC_SKEL = 116,
    CODUO_SYSCALL_XANIM_LOAD_ANIM_TREE = 117,
    CODUO_SYSCALL_XANIM_SAVE_ANIM_TREE = 118,
    CODUO_SYSCALL_XANIM_CLONE_ANIM_TREE = 119,
    CODUO_SYSCALL_DOBJ_NUM_BONES = 120,
    CODUO_SYSCALL_DOBJ_GET_BONE_INDEX = 121,
    CODUO_SYSCALL_DOBJ_GET_MATRIX_ARRAY = 122,
    CODUO_SYSCALL_DOBJ_DISPLAY_ANIM = 123,
    CODUO_SYSCALL_XANIM_HAS_FINISHED = 124,
    CODUO_SYSCALL_XANIM_GET_NUM_CHILDREN = 125,
    CODUO_SYSCALL_XANIM_GET_CHILD_AT = 126,
    CODUO_SYSCALL_XMODEL_NUM_BONES = 127,
    CODUO_SYSCALL_XMODEL_GET_BONE_NAMES = 128,
    CODUO_SYSCALL_DOBJ_GET_ROT_TRANS_ARRAY = 129,
    CODUO_SYSCALL_DOBJ_SET_ROT_TRANS_INDEX = 130,
    CODUO_SYSCALL_DOBJ_SET_CONTROL_ROT_TRANS_INDEX = 131,
    CODUO_SYSCALL_DOBJ_GET_BOUNDS = 132,
    CODUO_SYSCALL_XANIM_GET_ANIM_NAME = 133,
    CODUO_SYSCALL_DOBJ_GET_TREE = 134,
    CODUO_SYSCALL_XANIM_GET_ANIM_TREE_SIZE = 135,
    CODUO_SYSCALL_XMODEL_DEBUG_BOXES = 136,
    CODUO_SYSCALL_GET_WEAPON_INFO_MEMORY = 137,
    CODUO_SYSCALL_FREE_WEAPON_INFO_MEMORY = 138,
    CODUO_SYSCALL_FREE_CLIENT_SCRIPT_PERS = 139,
    CODUO_SYSCALL_RESET_ENTITY_PARSE_POINT = 140,

    CODUO_SYSCALL_MEMSET = 200,
    CODUO_SYSCALL_MEMCPY = 201,
    CODUO_SYSCALL_STRNCPY = 202,
    CODUO_SYSCALL_SIN = 203,
    CODUO_SYSCALL_COS = 204,
    CODUO_SYSCALL_ATAN2 = 205,
    CODUO_SYSCALL_SQRT = 206,
    CODUO_SYSCALL_MATRIX_MULTIPLY = 207,
    CODUO_SYSCALL_ANGLE_VECTORS = 208,
    CODUO_SYSCALL_PERPENDICULAR_VECTOR = 209,
    CODUO_SYSCALL_FLOOR = 210,
    CODUO_SYSCALL_CEIL = 211
} coduo_syscall_id_t;

enum {
    CODUO_SCRIPT_IMPORT_CALLBACK_COUNT = 102,
    CODUO_SCRIPT_EXPORT_COUNT = 5
};

typedef enum coduo_script_import_e {
    CODUO_SCRIPT_IMPORT_GET_BOOL = 0,
    CODUO_SCRIPT_IMPORT_GET_INT = 1,
    CODUO_SCRIPT_IMPORT_GET_ANIM = 2,
    CODUO_SCRIPT_IMPORT_GET_ANIM_TREE = 3,
    CODUO_SCRIPT_IMPORT_GET_FLOAT = 4,
    CODUO_SCRIPT_IMPORT_GET_STRING = 5,
    CODUO_SCRIPT_IMPORT_GET_CONST_STRING = 6,
    CODUO_SCRIPT_IMPORT_GET_DEBUG_STRING = 7,
    CODUO_SCRIPT_IMPORT_GET_ISTRING = 8,
    CODUO_SCRIPT_IMPORT_GET_CONST_ISTRING = 9,
    CODUO_SCRIPT_IMPORT_GET_VECTOR = 10,
    CODUO_SCRIPT_IMPORT_GET_FUNC = 11,
    CODUO_SCRIPT_IMPORT_GET_TYPE = 12,
    CODUO_SCRIPT_IMPORT_GET_POINTER_TYPE = 13,
    CODUO_SCRIPT_IMPORT_GET_ENTITY_NUM = 14,
    CODUO_SCRIPT_IMPORT_GET_NUM_PARAM = 15,
    CODUO_SCRIPT_IMPORT_ADD_BOOL = 16,
    CODUO_SCRIPT_IMPORT_ADD_INT = 17,
    CODUO_SCRIPT_IMPORT_ADD_FLOAT = 18,
    CODUO_SCRIPT_IMPORT_ADD_ANIM = 19,
    CODUO_SCRIPT_IMPORT_ADD_UNDEFINED = 20,
    CODUO_SCRIPT_IMPORT_ADD_ENTITY_NUM = 21,
    CODUO_SCRIPT_IMPORT_ADD_STRUCT = 22,
    CODUO_SCRIPT_IMPORT_ADD_STRING = 23,
    CODUO_SCRIPT_IMPORT_ADD_ISTRING = 24,
    CODUO_SCRIPT_IMPORT_ADD_CONST_STRING = 25,
    CODUO_SCRIPT_IMPORT_ADD_VECTOR = 26,
    CODUO_SCRIPT_IMPORT_ADD_OBJECT = 27,
    CODUO_SCRIPT_IMPORT_ADD_ARRAY = 28,
    CODUO_SCRIPT_IMPORT_ADD_ARRAY_STRING_INDEXED = 29,
    CODUO_SCRIPT_IMPORT_MAKE_ARRAY = 30,
    CODUO_SCRIPT_IMPORT_BEGIN_LOAD_SCRIPTS = 31,
    CODUO_SCRIPT_IMPORT_BEGIN_LOAD_ANIM_TREES = 32,
    CODUO_SCRIPT_IMPORT_END_LOAD_SCRIPTS = 33,
    CODUO_SCRIPT_IMPORT_END_LOAD_ANIM_TREES = 34,
    CODUO_SCRIPT_IMPORT_PRECACHE_ANIM_TREES = 35,
    CODUO_SCRIPT_IMPORT_FREE_SCRIPTS = 36,
    CODUO_SCRIPT_IMPORT_FREE_GAME_VARIABLE = 37,
    CODUO_SCRIPT_IMPORT_SHUTDOWN_SYSTEM = 38,
    CODUO_SCRIPT_IMPORT_IS_SYSTEM_ACTIVE = 39,
    CODUO_SCRIPT_IMPORT_ADD_EXEC_THREAD = 40,
    CODUO_SCRIPT_IMPORT_ADD_EXEC_ENT_THREAD_NUM = 41,
    CODUO_SCRIPT_IMPORT_EXEC_THREAD = 42,
    CODUO_SCRIPT_IMPORT_EXEC_ENT_THREAD_NUM = 43,
    CODUO_SCRIPT_IMPORT_IS_THREAD_ALIVE = 44,
    CODUO_SCRIPT_IMPORT_ERROR = 45,
    CODUO_SCRIPT_IMPORT_ERROR_WITH_DIALOG_MESSAGE = 46,
    CODUO_SCRIPT_IMPORT_PARAM_ERROR = 47,
    CODUO_SCRIPT_IMPORT_OBJECT_ERROR = 48,
    CODUO_SCRIPT_IMPORT_SET_DYNAMIC_ENTITY_FIELD = 49,
    CODUO_SCRIPT_IMPORT_FREE_ENTITY_NUM = 50,
    CODUO_SCRIPT_IMPORT_GET_ENTITY_ID = 51,
    CODUO_SCRIPT_IMPORT_SET_CLASS_MAP = 52,
    CODUO_SCRIPT_IMPORT_REMOVE_CLASS_MAP = 53,
    CODUO_SCRIPT_IMPORT_UNKNOWN_54 = 54,
    CODUO_SCRIPT_IMPORT_UNKNOWN_55 = 55,
    CODUO_SCRIPT_IMPORT_ADD_CLASS_FIELD = 56,
    CODUO_SCRIPT_IMPORT_ADD_FIELDS = 57,
    CODUO_SCRIPT_IMPORT_FIND_FIELD = 58,
    CODUO_SCRIPT_IMPORT_GET_OFFSET = 59,
    CODUO_SCRIPT_IMPORT_COPY_ENTITY_NUM = 60,
    CODUO_SCRIPT_IMPORT_INIT = 61,
    CODUO_SCRIPT_IMPORT_SHUTDOWN = 62,
    CODUO_SCRIPT_IMPORT_ABORT = 63,
    CODUO_SCRIPT_IMPORT_SET_LOADING = 64,
    CODUO_SCRIPT_IMPORT_INIT_SYSTEM = 65,
    CODUO_SCRIPT_IMPORT_ALLOC_GAME_VARIABLE = 66,
    CODUO_SCRIPT_IMPORT_GET_CHECKSUM = 67,
    CODUO_SCRIPT_IMPORT_HAS_SOURCE_FILES = 68,
    CODUO_SCRIPT_IMPORT_SAVE_SOURCE = 69,
    CODUO_SCRIPT_IMPORT_LOAD_SOURCE = 70,
    CODUO_SCRIPT_IMPORT_SKIP_SOURCE = 71,
    CODUO_SCRIPT_IMPORT_SAVE_PRE = 72,
    CODUO_SCRIPT_IMPORT_SAVE_POST = 73,
    CODUO_SCRIPT_IMPORT_SAVE_SHUTDOWN = 74,
    CODUO_SCRIPT_IMPORT_UNKNOWN_75 = 75,
    CODUO_SCRIPT_IMPORT_LOAD_PRE = 76,
    CODUO_SCRIPT_IMPORT_LOAD_SHUTDOWN = 77,
    CODUO_SCRIPT_IMPORT_UNKNOWN_78 = 78,
    CODUO_SCRIPT_IMPORT_LOAD_SCRIPT = 79,
    CODUO_SCRIPT_IMPORT_FIND_ANIM_TREE = 80,
    CODUO_SCRIPT_IMPORT_FIND_ANIM = 81,
    CODUO_SCRIPT_IMPORT_GET_FUNCTION_HANDLE = 82,
    CODUO_SCRIPT_IMPORT_FREE_THREAD = 83,
    CODUO_SCRIPT_IMPORT_CONVERT_THREAD_TO_SAVE = 84,
    CODUO_SCRIPT_IMPORT_CONVERT_THREAD_FROM_LOAD = 85,
    CODUO_SCRIPT_IMPORT_SET_STRING = 86,
    CODUO_SCRIPT_IMPORT_ALLOC_STRING = 87,
    CODUO_SCRIPT_IMPORT_NOTIFY_NUM = 88,
    CODUO_SCRIPT_IMPORT_NOTIFY_ID = 89,
    CODUO_SCRIPT_IMPORT_SL_CONVERT_TO_STRING = 90,
    CODUO_SCRIPT_IMPORT_SL_GET_STRING = 91,
    CODUO_SCRIPT_IMPORT_SL_GET_LOWERCASE_STRING = 92,
    CODUO_SCRIPT_IMPORT_SL_FIND_LOWERCASE_STRING = 93,
    CODUO_SCRIPT_IMPORT_CREATE_CANONICAL_FILENAME = 94,
    CODUO_SCRIPT_IMPORT_SET_TIME = 95,
    CODUO_SCRIPT_IMPORT_RUN_CURRENT_THREADS = 96,
    CODUO_SCRIPT_IMPORT_RESET_TIMEOUT = 97,
    CODUO_SCRIPT_IMPORT_GET_ANIMS_INDEX = 98,
    CODUO_SCRIPT_IMPORT_GET_ANIMS = 99,
    CODUO_SCRIPT_IMPORT_MT_ALLOC = 100,
    CODUO_SCRIPT_IMPORT_MT_FREE = 101
} coduo_script_import_t;

typedef enum coduo_script_export_e {
    CODUO_SCRIPT_EXPORT_GET_FUNCTION = 0,
    CODUO_SCRIPT_EXPORT_GET_METHOD = 1,
    CODUO_SCRIPT_EXPORT_SET_OBJECT_FIELD = 2,
    CODUO_SCRIPT_EXPORT_GET_OBJECT_FIELD = 3,
    CODUO_SCRIPT_EXPORT_LOAD_READ = 4
} coduo_script_export_t;

typedef struct XAnim_s XAnim;
typedef struct XAnimTree_s XAnimTree;
typedef struct coduo_script_entity_type_usage_s
    coduo_script_entity_type_usage_t;
/* Exact original tag from the Mac PEF scr_anim_s assignment symbol. */
typedef struct scr_anim_s {
    uint16_t animIndex;
    uint16_t treeIndex;
} scr_anim_t;
typedef struct coduo_script_anim_tree_ref_s {
    XAnim *tree;
} coduo_script_anim_tree_ref_t;
typedef void (*coduo_script_callback_fn)(void);
typedef void (*coduo_script_function_callback_fn)(void);
typedef void (*coduo_script_method_callback_fn)(uint32_t script_object);
typedef void *(*coduo_script_anim_tree_alloc_fn)(size_t size);
typedef void (*coduo_script_source_io_fn)(void *buffer, int32_t byte_count);
typedef union coduo_script_import_callback_u {
    coduo_script_callback_fn generic;
    qboolean (*bool_from_u32)(uint32_t);
    int (*int_from_u32)(uint32_t);
    int (*int_from_int)(int);
    int (*int_from_cstring)(const char *);
    int (*int_from_u16)(uint16_t);
    int (*int_from_void)(void);
    qboolean (*bool_from_void)(void);
    qboolean (*bool_from_cstring)(const char *);
    qboolean (*bool_from_u16)(uint16_t);
    qboolean (*bool_from_u8)(uint8_t);
    qboolean (*bool_from_bool)(qboolean);
    uint16_t (*u16_from_u32)(uint32_t);
    uint16_t (*u16_from_u16)(uint16_t);
    uint16_t (*u16_from_cstring)(const char *);
    uint16_t (*u16_from_cstring_int)(const char *, int);
    uint16_t (*u16_from_cstring_intp)(const char *, int *);
    uint16_t (*u16_from_int_int)(int, int);
    uint16_t (*u16_from_u16_cstring)(uint16_t, const char *);
    uint16_t (*u16_from_u32_u32)(uint32_t, uint32_t);
    uint16_t (*u16_from_int_int_u32_u32)(int, int, uint32_t, uint32_t);
    uint16_t (*u16_from_voidp)(void *);
    uint32_t (*u32_from_void)(void);
    uint32_t (*u32_from_u32)(uint32_t);
    uint32_t (*u32_from_u16_cstring)(uint16_t, const char *);
    uint32_t (*u32_from_xanim)(XAnim *);
    uint32_t (*u32_from_u32_intp)(uint32_t, int *);
    uint32_t (*u32_from_cstring_cstring)(const char *, const char *);
    coduo_script_variable_type_t (*variable_type_from_u32)(uint32_t);
    scr_anim_t (*anim_ref_from_u32_xanimtree)(uint32_t, XAnimTree *);
    coduo_script_anim_tree_ref_t (*anim_tree_ref_from_u32)(uint32_t);
    coduo_script_anim_tree_ref_t (*anim_tree_ref_from_cstring)(
        const char *);
    float (*float_from_u32)(uint32_t);
    const char *(*cstring_from_u16)(uint16_t);
    const char *(*cstring_from_u32)(uint32_t);
    void *(*voidp_from_u16)(uint16_t);
    XAnim *(*xanim_from_u32)(uint32_t);
    void *(*voidp_from_size_int)(size_t, int);
    void (*void_from_void)(void);
    void (*void_from_bool)(qboolean);
    void (*void_from_int)(int);
    void (*void_from_u16)(uint16_t);
    void (*void_from_u32)(uint32_t);
    void (*void_from_float)(float);
    void (*void_from_cstring)(const char *);
    void (*void_from_cstring_cstring)(const char *, const char *);
    void (*void_from_int_cstring)(int32_t, const char *);
    void (*void_from_const_floatp)(const float *);
    void (*void_from_anim_tree_alloc)(coduo_script_anim_tree_alloc_fn);
    void (*void_from_voidp)(void *);
    void (*void_from_u32p)(uint32_t *);
    void (*void_from_source_io)(coduo_script_source_io_fn);
    void (*void_from_voidp_size)(void *, size_t);
    void (*void_from_u32_floatp)(uint32_t, float *);
    void (*void_from_u8)(uint8_t);
    int (*int_from_u8)(uint8_t);
    uint16_t (*u16_from_cstring_u8)(const char *, uint8_t);
    void (*void_from_intp_cstring)(int *, const char *);
    void (*void_from_int_int)(int, int);
    void (*void_from_u32_u32)(uint32_t, uint32_t);
    void (*void_from_size_int)(size_t, int);
    void (*void_from_int_int_int)(int, int, int);
    void (*void_from_int_int_u16)(int, int, uint16_t);
    void (*void_from_int_int_u16_u32)(int, int, uint16_t, uint32_t);
    void (*void_from_int_int_u32_u32)(int, int, uint32_t, uint32_t);
    void (*void_from_u16_u16_u32)(uint16_t, uint16_t, uint32_t);
    void (*void_from_u16_cstring_u16)(uint16_t, const char *, uint16_t);
    void (*void_from_classmap_u32)(coduo_script_entity_type_usage_t *,
                                   uint32_t);
    void (*void_from_cstring_voidp)(const char *, const void *);
    void (*void_from_cstring_cstring_voidp)(const char *, const char *, void *);
    void (*void_from_cstring_cstring_animref)(const char *, const char *,
                                              scr_anim_t *);
    void (*void_from_voidp_voidp_voidp)(void *, void *, void *);
    void (*void_from_voidp_u16)(uint16_t *, uint16_t);
    void (*void_from_voidp_int)(void *, int);
    void (*void_from_voidp_int_uint32)(void *, int, uint32_t);
    void (*void_from_voidp_int_int)(void *, int, int);
} coduo_script_import_callback_t;
typedef coduo_script_function_callback_fn
    (*coduo_script_export_get_function_fn)(
        const char **name, int *developer_only);
typedef coduo_script_method_callback_fn
    (*coduo_script_export_get_method_fn)(
        const char **name, int *developer_only);
typedef void (*coduo_script_export_object_field_fn)(
    int classnum, int object_num, int field_index);
typedef void *(*coduo_script_export_load_read_fn)(uint32_t size);

typedef union coduo_script_export_callback_u {
    coduo_script_callback_fn generic;
    coduo_script_export_get_function_fn get_function;
    coduo_script_export_get_method_fn get_method;
    coduo_script_export_object_field_fn object_field;
    coduo_script_export_load_read_fn load_read;
} coduo_script_export_callback_t;

typedef coduo_script_import_callback_t
    coduo_script_import_table_t[CODUO_SCRIPT_IMPORT_CALLBACK_COUNT];
typedef coduo_script_export_callback_t
    coduo_script_export_table_t[CODUO_SCRIPT_EXPORT_COUNT];

#ifdef __cplusplus
}
#endif

#endif /* CODUO_ENGINE_ABI_H */
