#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>

#include "core_runtime_private.h"

void Cmd_AddCommand(const char *name, coduo_cmd_function_fn handler);

void Sys_Init(void)
{
    Cmd_AddCommand("in_restart", IN_Restart_f);
    Cvar_Set("arch", "linux i386");
    Cvar_Set("username", Sys_GetCurrentUser());
    Sys_InitInput();
}

void Sys_Warning(const char *format, ...)
{
    char message[SYS_WARNING_MESSAGE_BUFFER_SIZE];
    va_list argptr;

    va_start(argptr, format);
    /* ORIGINAL_BINARY_BUG: stock formats without a capacity into this
     * 1,024-byte stack array; see
     * original-bugs/coduomp-system-error-format-buffer-overflow.md. */
    vsprintf(message, format, argptr);
    va_end(argptr);

    if (sys_ttyConsoleActive != 0) {
        Sys_TTYHideInputLine();
    }

    fprintf(stderr, "Warning: %s", message);

    if (sys_ttyConsoleActive != 0) {
        Sys_TTYShowInputLine();
    }
}

void Sys_OutOfMemory(void)
{
    fprintf(stderr, "OUT OF MEMORY! ABORTING!!!\n");
    exit(SYS_OUT_OF_MEMORY_EXIT_STATUS);
}
