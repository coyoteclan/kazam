#include "core_runtime_private.h"

char *com_redirectBuffer;
int32_t com_redirectBufferSize;
coduo_com_redirect_flush_t com_redirectFlush;

void Com_BeginRedirect(char *buffer, int bufferSize,
                       coduo_com_redirect_flush_t flush)
{
    if (buffer != NULL && bufferSize != 0 && flush != NULL) {
        com_redirectBuffer = buffer;
        com_redirectBufferSize = bufferSize;
        com_redirectFlush = flush;
        *com_redirectBuffer = '\0';
    }
}

void Com_EndRedirect(void)
{
    if (com_redirectFlush != NULL) {
        com_redirectFlush(com_redirectBuffer);
    }

    com_redirectBuffer = NULL;
    com_redirectBufferSize = 0;
    com_redirectFlush = NULL;
}
