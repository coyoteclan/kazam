#include "coduo_engine_structs.h"
#include "../animation/dobj_private.h"
#include "../animation/xanim_private.h"
#include "../scripting/script_runtime_private.h"
#include "core_runtime_private.h"

void Com_InitServerRuntimePools(void)
{
    DObjShutdownPool();
    XAnimShutdownSmallTreePool();
    XAnimShutdown();
    Scr_Shutdown();
    Com_InitScriptRuntime();
    XAnimInit();
    XAnimInitSmallTreePool();
    DObjInitPool();
}
