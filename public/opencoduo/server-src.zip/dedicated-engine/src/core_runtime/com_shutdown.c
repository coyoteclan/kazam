#include "core_runtime_private.h"

void SV_Shutdown(const char *finalMessage);

void Com_Shutdown(const char *finalMessage)
{
    CL_Disconnect(qtrue);
    CL_ShutdownAll();
    SV_Shutdown(finalMessage);
    Hunk_ClearData();
    CL_StartHunkUsers();
}
