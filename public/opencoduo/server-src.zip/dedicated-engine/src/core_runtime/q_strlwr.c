#include <ctype.h>
#include <stddef.h>

#include "coduo_ctype_compat.h"
#include "core_runtime_private.h"

char *Q_strlwr(char *text)
{
    char *cursor = text;

    while (*cursor != '\0') {
        *cursor = (char)tolower(coduo_ctype_signed_byte_arg(*cursor));
        ++cursor;
    }

    return text;
}
