#if !defined(_WIN32)
#include <fcntl.h>
#endif
#include <stdarg.h>
#include <stdio.h>

#include "core_runtime_private.h"

void Sys_Error(const char *format, ...)
{
#if !defined(_WIN32)
    int flags;
#endif
    char message[SYS_ERROR_MESSAGE_BUFFER_SIZE];
    va_list argptr;

#if !defined(_WIN32)
    flags = fcntl(SYS_STDIN_FILE_DESCRIPTOR, SYS_F_GETFL_COMMAND,
                  SYS_F_GETFL_UNUSED_ARGUMENT);
    fcntl(SYS_STDIN_FILE_DESCRIPTOR, SYS_F_SETFL_COMMAND,
          flags & ~SYS_LINUX_O_NONBLOCK);
#endif

    if (sys_ttyConsoleActive != 0) {
        Sys_TTYHideInputLine();
    }

    CL_Shutdown();

    va_start(argptr, format);
    /* ORIGINAL_BINARY_BUG: stock formats without a capacity into this
     * 1,024-byte stack array; see
     * original-bugs/coduomp-system-error-format-buffer-overflow.md. */
    vsprintf(message, format, argptr);
    va_end(argptr);

    fprintf(stderr, "Sys_Error: %s\n", message);
    Sys_Exit(SYS_ERROR_EXIT_STATUS);
}
