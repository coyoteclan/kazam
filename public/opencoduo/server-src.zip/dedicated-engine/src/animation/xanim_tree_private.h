#ifndef CODUO_XANIM_TREE_PRIVATE_H
#define CODUO_XANIM_TREE_PRIVATE_H

#include "coduo_engine_structs.h"

extern int32_t xanim_activePoolPayloadSlot;

XAnim *XAnimAllocTree(const char *name,
                                   uint32_t nodeCount,
                                   coduo_script_anim_tree_alloc_fn
                                       allocCallback);
void XAnimSetLeafNode(XAnim *tree,
                      uint16_t nodeIndex,
                      const char *animName);
void XAnimSetParentNode(XAnim *tree,
                        uint16_t nodeIndex,
                        const char *unusedName,
                        uint16_t firstChildIndex,
                        uint16_t childCount,
                        uint16_t flags);
void XAnimSetupSyncNodes(XAnim *tree);

#endif
