#include <stdint.h>
#include <stddef.h>
#include <strings.h>

#include "../core_runtime/core_runtime_private.h"
#include "../model_assets/xmodel_asset_private.h"
#include "coduo_engine_structs.h"

XModel *SV_XModelGet(const char *modelName)
{
    if (strncasecmp(modelName, "xmodel", 6) != 0 ||
        (modelName[6] != '/' && modelName[6] != '\\')) {
        Com_Error(1, "\x15" "bad model name '%s'", modelName);
    }

    return XModelPrecache(modelName + 7, qfalse, Hunk_AllocXModelPrecache,
                          NULL);
}

void SV_XModelDebugBoxes(int32_t entityNum)
{
    (void)entityNum;
}
