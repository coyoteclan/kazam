#include "coduo_engine_structs.h"
#include "xanim_private.h"

void XAnimSetUser(int32_t activeSlot)
{
    xanim_activePoolPayloadSlot = activeSlot;
}
