#include "coduo_engine_structs.h"
#include "xanim_private.h"

int XAnimGetPoolHighWaterBytes(void)
{
    return xanim_poolHighWaterCount * (int)sizeof(XAnimInfo);
}

int XAnimGetPoolUsedBytes(void)
{
    return xanim_poolUsedCount * (int)sizeof(XAnimInfo);
}

XAnim *
XAnimRuntimeTreeSourceTree(XAnimTree *runtimeTree)
{
    return runtimeTree->sourceTree;
}

const char *XAnimGetAnimName(XAnim *tree,
                             int32_t animIndex)
{
    XAnimEntry *entry = &tree->entries[animIndex];

    if (entry->childCount != 0) {
        return "<non-leaf anim>";
    }

    return entry->payload.leafAsset->name;
}

uint32_t XAnimGetAnimTreeSize(XAnim *tree)
{
    return tree->nodeCount;
}
