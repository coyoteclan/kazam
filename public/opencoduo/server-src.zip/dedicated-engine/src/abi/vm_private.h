#ifndef CODUO_VM_PRIVATE_H
#define CODUO_VM_PRIVATE_H

#include "coduo_engine_structs.h"

extern coduo_vm_t *currentVM;
extern coduo_vm_table_t vmTable;

void VM_Init(void);
coduo_vm_t *VM_Create(const char * module,
                      coduo_vm_system_call_fn systemCall);
void VM_Free(coduo_vm_t *vm);
void VM_Clear(void);
intptr_t VM_Call(coduo_vm_t *vm,
                               int32_t command, ...);

#endif
