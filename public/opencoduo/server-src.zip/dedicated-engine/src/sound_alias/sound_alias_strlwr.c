#include <ctype.h>
#include <stddef.h>

#include "coduo_ctype_compat.h"
#include "sound_alias_private.h"

char *strlwr(char *string)
{
    if (string == NULL) {
        return NULL;
    }

    while (*string != '\0') {
        *string =
            (char)tolower(coduo_ctype_signed_byte_arg(*string));
        ++string;
    }

    return string;
}
