#ifndef CODUO_SOUND_ALIAS_PRIVATE_H
#define CODUO_SOUND_ALIAS_PRIVATE_H

#include "coduo_engine_structs.h"

extern coduo_sound_alias_checksum_table_t soundAlias_checksums;
extern coduo_sound_alias_count_table_t soundAlias_counts;
extern char *soundAlias_currentFile;
extern coduo_sound_alias_hash_table_t soundAlias_hashTable;
extern coduo_sound_alias_loaded_flags_t soundAlias_loadedFlags;
extern coduo_sound_alias_localized_source_name_t soundAlias_localizedSourceName;
extern coduo_sound_alias_parse_node_t *soundAlias_parseListHead;
extern coduo_sound_alias_subtitle_reference_buffer_t
    soundAlias_subtitleReferenceBuffer;
extern coduo_sound_alias_table_pointer_table_t soundAlias_tablePointers;

char *strlwr(char *string);
void Com_InitSoundAliasParseNode(coduo_sound_alias_parse_node_t *node,
                                 qboolean defaultLoadspec);
void Com_ParseSoundAliasColumn(
    const char *sourceFile, const char *text,
    int32_t column,
    coduo_sound_alias_parse_seen_column_table_t seenColumns,
    coduo_sound_alias_parse_node_t *node);
void Com_ValidateSoundAliasParseNode(coduo_sound_alias_parse_node_t *node);
coduo_sound_alias_parse_node_t *
Com_CloneSoundAliasParseNode(const coduo_sound_alias_parse_node_t *node);
void Com_FinalizeSoundAliasRecord(
    const coduo_sound_alias_parse_node_t *node, coduo_sound_alias_t *alias,
    const char *name, const char *file, const char *subtitle,
    int32_t locale);
int Com_SoundAliasHash(const char *name);
qboolean Com_IsValidSoundAliasName(const char *name);
char **Com_LoadSoundAliasLoadspecList(
    const char *filename, int32_t *countOut);
void Com_FreeSoundAliasStringList(char **list);
int32_t Com_LoadSoundAliasCsvRows(
    const char *sourceName, const char *csvPath, int32_t count,
    qboolean defaultLoadspec);
coduo_sound_alias_parse_node_t *
Com_SortSoundAliasParseList(coduo_sound_alias_parse_node_t *head,
                            int32_t *count);
qboolean Com_SoundAliasSubtitleReferenceExists(const char *subtitle);
const char *Com_SoundAliasSubtitleReferenceForText(const char *englishText);
void Com_UpdateSoundAliasSubtitleFile(const char *subtitle,
                                      const char *englishText);
void Com_LoadSoundAliasSet(const char *sourceName,
                           int32_t locale);
void Com_UnloadSoundAliasSet(int32_t locale);

#endif
