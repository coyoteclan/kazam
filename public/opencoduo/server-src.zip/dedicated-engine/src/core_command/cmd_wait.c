#include <stdlib.h>

#include "cmd_private.h"

void Cmd_Wait_f(void)
{
    if (Cmd_Argc() == 2) {
        /* ORIGINAL_BINARY_BUG: stock accepts a negative frame count, while
         * Cbuf_Execute treats every nonzero value as pending and decrements
         * it, effectively stalling queued commands until dword wrap. */
        cbuf_wait = atoi(Cmd_Argv(1));
    } else {
        cbuf_wait = 1;
    }
}
