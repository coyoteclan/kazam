#include "cmd_private.h"

void Cmd_TokenizeString(const char *text)
{
    Cmd_TokenizeString2(text, 0);
}
