#include "cmd_private.h"

void Cmd_ArgsBuffer(char *buffer, int bufferLength)
{
    char *text;

    text = Cmd_Args(1);
    Q_strncpyz(buffer, text, bufferLength);
}
