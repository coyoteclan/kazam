#include "cmd_private.h"

void Cmd_CommandCompletion(coduo_cmd_name_callback_t callback)
{
    cmd_function_t *cmd;

    for (cmd = cmd_functions; cmd != NULL; cmd = cmd->next) {
        callback(cmd->name);
    }
}
