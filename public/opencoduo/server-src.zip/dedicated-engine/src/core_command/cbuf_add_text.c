#include <string.h>

#include "cmd_private.h"

void Cbuf_AddText(const char *text)
{
    const int32_t textLength = (int32_t)strlen(text);
    /* ORIGINAL_BINARY_BUG: the wrapping signed dword sum can become negative
     * and pass the fixed command-buffer capacity check. */
    const int32_t newSize = textLength + cbuf_cmd_text.cursize;

    if (newSize < cbuf_cmd_text.maxsize) {
        char *buffer = cbuf_cmd_text.data;

        /*
         * Stock passes the dword strlen result to memcpy.  Preserve that
         * call-boundary width when native size_t is wider than 32 bits.
         */
        memcpy(buffer + cbuf_cmd_text.cursize, text,
               (size_t)(uint32_t)textLength);
        cbuf_cmd_text.cursize += textLength;
    } else {
        Com_Printf("Cbuf_AddText: overflow\n");
    }
}
