#ifndef CODUO_CMD_PRIVATE_H
#define CODUO_CMD_PRIVATE_H

#include <stddef.h>

#include "coduo_engine_structs.h"
#include "q_string_compare.h"

extern coduo_cbuf_text_buffer_t cbuf_textBuffer;
extern coduo_cmd_text_t cbuf_cmd_text;
extern int32_t cbuf_wait;
extern int32_t cmd_argc;
extern const char *cmd_argv[CODUO_CMD_MAX_ARGS];
extern coduo_cmd_token_buffer_t cmd_tokenBuffer;
extern char cmd_args[];
extern cmd_function_t *cmd_functions;
extern cvar_t *cl_running;
extern cvar_t *sv_running;

typedef void (*coduo_cmd_name_callback_t)(const char *name);

void Com_Printf(const char *format, ...);
void Com_Error(int32_t code, const char *format, ...);
void Q_strncpyz(char *dest, const char *src, int destsize);
void Com_DefaultExtension(char *path, int maxSize, const char *extension);
int FS_ReadFile(const char *qpath, void **buffer);
void FS_FreeFile(void *buffer);
int32_t Cvar_VariableIntegerValue(const char *name);
const char *Cvar_VariableString(const char *name);
int Com_BlockChecksum(const void *buffer, int length);
void *Z_Malloc(size_t size);
void Z_Free(void *ptr);
char *CopyString(const char *text);
char *va(const char *format, ...);
qboolean Cvar_Command(void);
qboolean CL_GameCommand(void);
qboolean UI_GameCommand(void);
void CL_ForwardCommandToServer(const char *text);
qboolean Com_Filter(const char *filter, const char *name,
                      qboolean caseSensitive);
int SV_GameConsoleCommand(void);
void PB_CallServerSbGlobal(int command, int clientNum, uint32_t length,
                           const char *text);

void Cbuf_Init(void);
void Cbuf_AddText(const char *text);
void Cbuf_InsertText(const char *text);
void Cbuf_ExecuteText(coduo_cbuf_exec_when_t exec_when, const char *text);
void Cbuf_Execute(void);
void Cmd_ExecuteString(const char *text);
int32_t Cmd_Argc(void);
const char *Cmd_Argv(uint32_t arg);
void Cmd_ArgvBuffer(uint32_t arg, char *buffer,
                    int32_t bufferLength);
void Cmd_Wait_f(void);
void Cmd_Exec_f(void);
void Cmd_ShowChecksum_f(void);
void Cmd_Vstr_f(void);
void Cmd_Echo_f(void);
char *Cmd_Args(int32_t start);
void Cmd_ArgsBuffer(char *buffer, int bufferLength);
void Cmd_TokenizeString2(const char *text, int maxTokens);
void Cmd_TokenizeString(const char *text);
void Cmd_AddCommand(const char *name, coduo_cmd_function_fn handler);
void Cmd_RemoveCommand(const char *name);
void Cmd_Shutdown(void);
void Cmd_CommandCompletion(coduo_cmd_name_callback_t callback);
void Cmd_List_f(void);
void Cmd_Init(void);

#endif
