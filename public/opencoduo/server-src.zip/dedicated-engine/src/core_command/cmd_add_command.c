#include <string.h>

#include "cmd_private.h"

void Cmd_AddCommand(const char *name, coduo_cmd_function_fn handler)
{
    cmd_function_t *function;

    for (function = cmd_functions; function != NULL;
         function = function->next) {
        if (strcmp(name, function->name) == 0) {
            if (handler != NULL) {
                Com_Printf("Cmd_AddCommand: %s already defined\n", name);
            }
            return;
        }
    }

    function = Z_Malloc((size_t)sizeof(*function));
    function->name = CopyString(name);
    function->handler = handler;
    function->next = cmd_functions;
    cmd_functions = function;
}
