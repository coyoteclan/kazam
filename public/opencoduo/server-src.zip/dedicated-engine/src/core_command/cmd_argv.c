#include "cmd_private.h"

const char *Cmd_Argv(uint32_t arg)
{
    if (arg < (uint32_t)cmd_argc) {
        return cmd_argv[arg];
    }

    return "";
}
