#include "cmd_private.h"

int32_t Cmd_Argc(void)
{
    return cmd_argc;
}
