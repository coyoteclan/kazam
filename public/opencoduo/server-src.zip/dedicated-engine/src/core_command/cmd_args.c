#include "cmd_private.h"

#include <string.h>

char *Cmd_Args(int32_t start)
{
    int32_t i;

    cmd_args[0] = '\0';
    /* ORIGINAL_BINARY_BUG: the stock routine joins arguments into the
     * 1,024-byte global without any destination-capacity check. */
    for (i = start; i < cmd_argc; i++) {
        strcat(cmd_args, cmd_argv[i]);
        if (i != cmd_argc - 1) {
            strcat(cmd_args, " ");
        }
    }

    return cmd_args;
}
