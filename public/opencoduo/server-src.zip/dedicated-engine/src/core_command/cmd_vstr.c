#include "cmd_private.h"

void Cmd_Vstr_f(void)
{
    if (Cmd_Argc() == 2) {
        const char *value = Cvar_VariableString(Cmd_Argv(1));
        Cbuf_InsertText(va("%s\n", value));
    } else {
        Com_Printf("vstr <variablename> : execute a variable command\n");
    }
}
