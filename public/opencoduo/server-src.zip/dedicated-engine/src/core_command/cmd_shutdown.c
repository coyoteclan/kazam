#include "cmd_private.h"

void Cmd_Shutdown(void)
{
    cmd_function_t *cmd;

    while ((cmd = cmd_functions) != NULL) {
        cmd_functions = cmd->next;
        Z_Free(cmd->name);
        Z_Free(cmd);
    }
}
