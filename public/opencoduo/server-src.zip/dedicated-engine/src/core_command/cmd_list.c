#include "cmd_private.h"

void Cmd_List_f(void)
{
    const char *match;
    int count;
    cmd_function_t *cmd;

    if (Cmd_Argc() > 1) {
        match = Cmd_Argv(1);
    } else {
        match = NULL;
    }

    count = 0;
    for (cmd = cmd_functions; cmd != NULL; cmd = cmd->next) {
        const char *name = cmd->name;

        if (match == NULL || Com_Filter(match, name, 0) != 0) {
            Com_Printf("%s\n", name);
            count++;
        }
    }

    Com_Printf("%i commands\n", count);
}
