#include "cmd_private.h"

void Cmd_ShowChecksum_f(void)
{
    char filename[CODUO_MAX_QPATH];
    void *fileBuffer;
    int fileLength;
    int checksum;

    if (Cmd_Argc() != 2) {
        Com_Printf("showchecksum <filename> : prints size and checksum of a file\n");
        return;
    }

    Q_strncpyz(filename, Cmd_Argv(1), sizeof(filename));
    Com_DefaultExtension(filename, sizeof(filename), ".cfg");
    fileLength = FS_ReadFile(filename, &fileBuffer);

    if (fileBuffer == NULL) {
        Com_Printf("couldn't find %s\n", Cmd_Argv(1));
        return;
    }

    checksum = Com_BlockChecksum(fileBuffer, fileLength);
    Com_Printf("ShowChecksum: %s, size: %i, checksum: %i", filename, fileLength,
               checksum);
    FS_FreeFile(fileBuffer);
}
