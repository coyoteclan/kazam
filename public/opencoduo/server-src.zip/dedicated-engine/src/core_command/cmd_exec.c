#include "cmd_private.h"

void Cmd_Exec_f(void)
{
    char filename[CODUO_MAX_QPATH];
    void *fileBuffer;
    int fileLength;

    if (Cmd_Argc() != 2) {
        Com_Printf("exec <filename> : execute a script file\n");
        return;
    }

    Q_strncpyz(filename, Cmd_Argv(1), sizeof(filename));
    Com_DefaultExtension(filename, sizeof(filename), ".cfg");
    fileLength = FS_ReadFile(filename, &fileBuffer);

    if (fileBuffer == NULL) {
        Com_Printf("couldn't exec %s\n", Cmd_Argv(1));
        return;
    }

    Com_Printf("execing %s\n", Cmd_Argv(1));
    if (Cvar_VariableIntegerValue("sv_console_lockout") != 0) {
        const int checksum = Com_BlockChecksum(fileBuffer, fileLength);
        Cbuf_InsertText(va("say Server exec: %s, size: %i, checksum: %i",
                           filename, fileLength, checksum));
    }

    Cbuf_InsertText(fileBuffer);
    FS_FreeFile(fileBuffer);
}
