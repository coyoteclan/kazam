#include "cmd_private.h"

void Cmd_ArgvBuffer(uint32_t arg, char *buffer,
                    int32_t bufferLength)
{
    const char *text = Cmd_Argv(arg);

    Q_strncpyz(buffer, text, bufferLength);
}
