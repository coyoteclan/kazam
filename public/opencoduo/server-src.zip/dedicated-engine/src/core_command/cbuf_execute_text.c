#include "cmd_private.h"

static const char cbufExecuteTextBadExecWhenMessage[] =
    "\x15"
    "Cbuf_ExecuteText: bad exec_when";

void Cbuf_ExecuteText(coduo_cbuf_exec_when_t exec_when, const char *text)
{
    if (exec_when == CODUO_EXEC_INSERT) {
        Cbuf_InsertText(text);
    } else {
        if (exec_when < CODUO_EXEC_APPEND) {
            if (exec_when == CODUO_EXEC_NOW) {
                if (text != NULL && *text != '\0') {
                    Cmd_ExecuteString(text);
                    return;
                }

                Cbuf_Execute();
                return;
            }
        } else if (exec_when == CODUO_EXEC_APPEND) {
            Cbuf_AddText(text);
            return;
        }

        Com_Error(0, cbufExecuteTextBadExecWhenMessage);
    }
}
