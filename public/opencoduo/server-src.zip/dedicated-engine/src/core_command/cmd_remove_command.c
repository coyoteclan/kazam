#include <string.h>

#include "cmd_private.h"

void Cmd_RemoveCommand(const char *name)
{
    cmd_function_t **link;
    cmd_function_t *cmd;

    link = &cmd_functions;
    for (;;) {
        cmd = *link;
        if (cmd == NULL) {
            return;
        }

        if (strcmp(name, cmd->name) == 0) {
            *link = cmd->next;
            if (cmd->name != NULL) {
                Z_Free(cmd->name);
            }
            Z_Free(cmd);
            return;
        }

        link = &cmd->next;
    }
}
