#include "cmd_private.h"

void Cbuf_Init(void)
{
    cbuf_cmd_text.data = cbuf_textBuffer;
    cbuf_cmd_text.maxsize =
        (int32_t)sizeof(cbuf_textBuffer);
    cbuf_cmd_text.cursize = 0;
}
