#include "core_memory_private.h"

#define HUNK_MARK_UNSET 0

qboolean Hunk_HighMarkIsSet(void)
{
    return hunk.highMark != HUNK_MARK_UNSET;
}
