#include "core_memory_private.h"

void Hunk_SetLowMark(void)
{
    hunk.lowMark = hunk.lowUsed;
}

void Hunk_ClearToLowMark(void)
{
    hunk.lowTemp = hunk.lowMark;
    hunk.lowUsed = hunk.lowMark;
    Hunk_RetouchMemory();
}
