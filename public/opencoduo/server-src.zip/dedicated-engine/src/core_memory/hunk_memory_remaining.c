#include "core_memory_private.h"

size_t Hunk_MemoryRemaining(void)
{
    return hunk.totalSize - (hunk.lowTemp + hunk.highTemp);
}
