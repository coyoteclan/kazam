#include "core_memory_private.h"

qboolean Hunk_CheckHighMark(void *ptr)
{
    uint8_t *highMarkAddress;

    highMarkAddress = hunk_base + hunk.totalSize - hunk.highMark;

    return highMarkAddress <= (uint8_t *)ptr;
}
