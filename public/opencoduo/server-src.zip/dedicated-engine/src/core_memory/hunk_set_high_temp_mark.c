#include "core_memory_private.h"

void Hunk_SetHighTempMark(void)
{
    hunk.highTempMark = hunk.highUsed;
}
