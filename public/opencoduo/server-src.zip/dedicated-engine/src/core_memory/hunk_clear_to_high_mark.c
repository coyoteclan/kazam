#include "core_memory_private.h"

void Hunk_ClearToHighMark(void)
{
    hunk.highTemp = hunk.highMark;
    hunk.highUsed = hunk.highMark;
    Hunk_RetouchMemory();
}
