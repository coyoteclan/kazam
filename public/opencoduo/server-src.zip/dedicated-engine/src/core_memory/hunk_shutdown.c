#include <stdlib.h>

#include "core_memory_private.h"

void Hunk_Shutdown(void)
{
    free(hunk_allocBase);
    hunk_base = NULL;
    hunk_allocBase = NULL;
}
