#include <stdlib.h>
#include <string.h>

#include "coduo_engine_structs.h"

#define Z_MALLOC_CLEAR_VALUE 0

void Sys_OutOfMemory(void);
void Com_Memset(void *dest, int32_t value, size_t count);

void Z_Free(void *ptr)
{
    free(ptr);
}

void *Z_Malloc(size_t size)
{
    void *ptr;

    ptr = malloc(size);
    if (ptr == NULL) {
        Sys_OutOfMemory();
    }
    Com_Memset(ptr, Z_MALLOC_CLEAR_VALUE, size);
    return ptr;
}

char *CopyString(const char *text)
{
    char *copy;

    copy = Z_Malloc(strlen(text) + 1);
    strcpy(copy, text);
    return copy;
}

void Com_Memset(void *dest, int32_t value, size_t count)
{
    (void)memset(dest, value, count);
}

void Com_Memcpy(void *dest, const void *src, size_t count)
{
    (void)memcpy(dest, src, count);
}
