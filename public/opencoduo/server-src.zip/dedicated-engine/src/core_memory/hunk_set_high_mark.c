#include "core_memory_private.h"

void Hunk_SetHighMark(void)
{
    hunk.highMark = hunk.highUsed;
}
