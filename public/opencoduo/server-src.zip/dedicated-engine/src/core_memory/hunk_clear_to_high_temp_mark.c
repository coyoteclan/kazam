#include "core_memory_private.h"

void Hunk_ClearToHighTempMark(void)
{
    hunk.highTemp = hunk.highTempMark;
    hunk.highUsed = hunk.highTempMark;
    Hunk_RetouchMemory();
}
