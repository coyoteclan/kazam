#include "coduo_x87emu.h" /* defines EMULATE_X87; x87 shim when it is 1 */

#include "core_math_private.h"

qboolean VectorCompareEpsilon(const vec3_t left, const vec3_t right)
{
    for (int index = 0; index <= 2; index++) {
#if EMULATE_X87
        /* stock keeps (left-right)^2 in an 80-bit register (no float spill of the
         * difference or its square) before the unordered compare against the
         * epsilon, so the square and comparison run in the shim. */
        x87f delta =
            x87f_sub(x87f_load_f32(left[index]), x87f_load_f32(right[index]));
        if (x87f_lt(x87f_load_f32(CODUO_VEC3_COMPARE_EPSILON_SQ),
                    x87f_mul(delta, delta))) {
            return qfalse;
        }
#else
        if ((left[index] - right[index]) * (left[index] - right[index]) >
            CODUO_VEC3_COMPARE_EPSILON_SQ) {
            return qfalse;
        }
#endif
    }

    return qtrue;
}
