#include "coduo_x87emu.h" /* defines EMULATE_X87; x87 shim when it is 1 */

#include "core_math_private.h"

#if EMULATE_X87
/* rotation column: 80-bit ((la*ra + lb*rb) + lc*rc) rounded to float. */
#define CODUO_M43_DOT3(la, lb, lc, ra, rb, rc)                                 \
    x87f_store_f32(x87f_add(                                                   \
        x87f_add(x87f_mul(x87f_load_f32(la), x87f_load_f32(ra)),              \
                 x87f_mul(x87f_load_f32(lb), x87f_load_f32(rb))),             \
        x87f_mul(x87f_load_f32(lc), x87f_load_f32(rc))))
/* translation column: the 3-term dot plus the translation term ld. */
#define CODUO_M43_DOT4(la, lb, lc, ld, ra, rb, rc)                             \
    x87f_store_f32(x87f_add(                                                   \
        x87f_add(x87f_add(x87f_mul(x87f_load_f32(la), x87f_load_f32(ra)),     \
                          x87f_mul(x87f_load_f32(lb), x87f_load_f32(rb))),    \
                 x87f_mul(x87f_load_f32(lc), x87f_load_f32(rc))),            \
        x87f_load_f32(ld)))
#endif

void MatrixMultiply43(const float left[3][4], const float right[3][4],
                      float out[3][4])
{
#if EMULATE_X87
    /* x87-faithful transcription (stock coduo_lnxded 0x08067d3b): columns 0-2 are
     * 80-bit three-term dots; column 3 adds the row's translation term left[i][3]
     * inside the same 80-bit chain, all rounded to float at the store. */
    for (int i = 0; i < 3; ++i) {
        out[i][0] = CODUO_M43_DOT3(left[i][0], left[i][1], left[i][2],
                                   right[0][0], right[1][0], right[2][0]);
        out[i][1] = CODUO_M43_DOT3(left[i][0], left[i][1], left[i][2],
                                   right[0][1], right[1][1], right[2][1]);
        out[i][2] = CODUO_M43_DOT3(left[i][0], left[i][1], left[i][2],
                                   right[0][2], right[1][2], right[2][2]);
        out[i][3] = CODUO_M43_DOT4(left[i][0], left[i][1], left[i][2],
                                   left[i][3], right[0][3], right[1][3],
                                   right[2][3]);
    }
#else
    out[0][0] =
        ((left[0][0] * right[0][0]) + (left[0][1] * right[1][0])) +
        (left[0][2] * right[2][0]);
    out[0][1] =
        ((left[0][0] * right[0][1]) + (left[0][1] * right[1][1])) +
        (left[0][2] * right[2][1]);
    out[0][2] =
        ((left[0][0] * right[0][2]) + (left[0][1] * right[1][2])) +
        (left[0][2] * right[2][2]);
    out[0][3] =
        (((left[0][0] * right[0][3]) + (left[0][1] * right[1][3])) +
         (left[0][2] * right[2][3])) +
        left[0][3];

    out[1][0] =
        ((left[1][0] * right[0][0]) + (left[1][1] * right[1][0])) +
        (left[1][2] * right[2][0]);
    out[1][1] =
        ((left[1][0] * right[0][1]) + (left[1][1] * right[1][1])) +
        (left[1][2] * right[2][1]);
    out[1][2] =
        ((left[1][0] * right[0][2]) + (left[1][1] * right[1][2])) +
        (left[1][2] * right[2][2]);
    out[1][3] =
        (((left[1][0] * right[0][3]) + (left[1][1] * right[1][3])) +
         (left[1][2] * right[2][3])) +
        left[1][3];

    out[2][0] =
        ((left[2][0] * right[0][0]) + (left[2][1] * right[1][0])) +
        (left[2][2] * right[2][0]);
    out[2][1] =
        ((left[2][0] * right[0][1]) + (left[2][1] * right[1][1])) +
        (left[2][2] * right[2][1]);
    out[2][2] =
        ((left[2][0] * right[0][2]) + (left[2][1] * right[1][2])) +
        (left[2][2] * right[2][2]);
    out[2][3] =
        (((left[2][0] * right[0][3]) + (left[2][1] * right[1][3])) +
         (left[2][2] * right[2][3])) +
        left[2][3];
#endif
}
