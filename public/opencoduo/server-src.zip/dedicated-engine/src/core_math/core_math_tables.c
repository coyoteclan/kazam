#include "core_math_private.h"

/* Original coduo_lnxded 0x080662ac copies this vector from VA 0x080dd708. */
const vec3_t vec3_origin = {0.0f, 0.0f, 0.0f};
