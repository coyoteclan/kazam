#include "core_math_private.h"

long double VectorMax(const vec3_t vector)
{
    float maximum;
    float result;

    if (vector[1] <= vector[0]) {
        maximum = vector[0];
    } else {
        maximum = vector[1];
    }

    if (vector[2] <= maximum) {
        result = maximum;
    } else {
        result = vector[2];
    }

    return (long double)result;
}
