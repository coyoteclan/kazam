#include "core_math_private.h"

long double QuatRelativeVectorPartLengthSquared(const vec4_t left,
                                                const vec4_t right)
{
    vec4_t conjugate;
    vec4_t product;

    QuatInverse(right, conjugate);
    QuatMultiply(left, conjugate, product);
    return QuatNormalizedVectorPartLengthSquared(product);
}
