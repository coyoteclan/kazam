#include "coduo_x87emu.h" /* defines EMULATE_X87; x87 shim when it is 1 */

#include "core_math_private.h"

long double DotProduct(const vec3_t left, const vec3_t right)
{
#if EMULATE_X87
    /* x87-faithful transcription (stock coduo_lnxded 0x08066333): lanes loaded as
     * float32 from left[i]/right[i], multiplied and summed left-to-right in 80-bit
     * (fld; fmul; faddp), the unrounded sum left in st0 (pop ebp; ret). This
     * helper has NO callers in the reconstruction (dead in the engine — dots are
     * computed inline elsewhere), so no consumer pins the return rounding; the sum
     * is rounded to float at the return to match the float-projected differential
     * digest and avoid an arm64 80->64 truncation. The x86 #else path keeps the
     * raw 80-bit st0 return, matching stock exactly. */
    x87f sum = x87f_mul(x87f_load_f32(left[0]), x87f_load_f32(right[0]));
    sum = x87f_add(sum,
                   x87f_mul(x87f_load_f32(left[1]), x87f_load_f32(right[1])));
    sum = x87f_add(sum,
                   x87f_mul(x87f_load_f32(left[2]), x87f_load_f32(right[2])));
    return (long double)x87f_store_f32(sum);
#else
    return ((long double)left[0] * (long double)right[0]) +
           ((long double)left[1] * (long double)right[1]) +
           ((long double)left[2] * (long double)right[2]);
#endif
}
