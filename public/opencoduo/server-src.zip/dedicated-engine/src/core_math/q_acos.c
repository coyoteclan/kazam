#include <math.h>

#include "core_math_private.h"

long double Q_acos(float value)
{
    const float piFloat = 3.1415927f;
    float angle;

    angle = (float)acos((double)value);
    if (angle > 3.141592653589793) {
        return piFloat;
    }
    if (angle < -3.141592653589793) {
        return piFloat;
    }
    return angle;
}
