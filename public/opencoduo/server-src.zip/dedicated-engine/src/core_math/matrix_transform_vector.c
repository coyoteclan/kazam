#include "coduo_x87emu.h" /* defines EMULATE_X87; x87 shim when it is 1 */

#include "core_math_private.h"

void MatrixTransformVector(const vec3_t in, vec3_t matrix[3], vec3_t out)
{
#if EMULATE_X87
    /* x87-faithful transcription (stock coduo_lnxded 0x08069154): each output is
     * the 80-bit dot (in0*col0 + in1*col1) + in2*col2, rounded to float only at
     * the store. */
    out[0] = x87f_store_f32(x87f_add(
        x87f_add(x87f_mul(x87f_load_f32(in[0]), x87f_load_f32(matrix[0][0])),
                 x87f_mul(x87f_load_f32(in[1]), x87f_load_f32(matrix[1][0]))),
        x87f_mul(x87f_load_f32(in[2]), x87f_load_f32(matrix[2][0]))));
    out[1] = x87f_store_f32(x87f_add(
        x87f_add(x87f_mul(x87f_load_f32(in[0]), x87f_load_f32(matrix[0][1])),
                 x87f_mul(x87f_load_f32(in[1]), x87f_load_f32(matrix[1][1]))),
        x87f_mul(x87f_load_f32(in[2]), x87f_load_f32(matrix[2][1]))));
    out[2] = x87f_store_f32(x87f_add(
        x87f_add(x87f_mul(x87f_load_f32(in[0]), x87f_load_f32(matrix[0][2])),
                 x87f_mul(x87f_load_f32(in[1]), x87f_load_f32(matrix[1][2]))),
        x87f_mul(x87f_load_f32(in[2]), x87f_load_f32(matrix[2][2]))));
#else
    out[0] = (in[0] * matrix[0][0] + in[1] * matrix[1][0]) +
             in[2] * matrix[2][0];
    out[1] = (in[0] * matrix[0][1] + in[1] * matrix[1][1]) +
             in[2] * matrix[2][1];
    out[2] = (in[0] * matrix[0][2] + in[1] * matrix[1][2]) +
             in[2] * matrix[2][2];
#endif
}
