#include "core_math_private.h"

void AnglesToAxis(const vec3_t angles, coduo_compact_affine_matrix43_t *matrix)
{
    vec3_t right;

    AngleVectors(angles, matrix->axis[0], right, matrix->axis[2]);
    matrix->axis[1][0] = vec3_origin[0] - right[0];
    matrix->axis[1][1] = vec3_origin[1] - right[1];
    matrix->axis[1][2] = vec3_origin[2] - right[2];
}
