#include "core_math_private.h"

#include <string.h>

void RotateAroundDirection(vec3_t axis[3], float yaw)
{
    vec3_t temp;

    PerpendicularVector(axis[1], axis[0]);
    if (yaw != 0.0f) {
        memcpy(&temp[0], &axis[1][0], sizeof(temp[0]));
        memcpy(&temp[1], &axis[1][1], sizeof(temp[1]));
        memcpy(&temp[2], &axis[1][2], sizeof(temp[2]));
        RotatePointAroundVector(axis[1], axis[0], temp, yaw);
    }

    CrossProduct(axis[0], axis[1], axis[2]);
}
