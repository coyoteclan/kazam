#include "coduo_x87emu.h" /* defines EMULATE_X87; x87 shim when it is 1 */

#include "core_math_private.h"

void QuatFromZAxisDegrees(float angleDegrees, vec4_t quat)
{
    float halfAngleRadians;

#if EMULATE_X87
    /* half-angle in 80-bit to the fsincos leaf (stock coduo_lnxded 0x08069b5e). */
    halfAngleRadians = x87f_store_f32(x87f_mul(
        x87f_load_f32(angleDegrees), x87f_load_f64(3.141592653589793 / 360.0)));
#else
    halfAngleRadians =
        (float)((double)angleDegrees * (3.141592653589793 / 360.0));
#endif
    quat[0] = 0.0f;
    quat[1] = 0.0f;
    SinCosFloat(halfAngleRadians, &quat[2], &quat[3]);
}
