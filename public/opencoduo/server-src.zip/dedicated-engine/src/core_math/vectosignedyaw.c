#include <math.h>

#include "coduo_x87emu.h" /* defines EMULATE_X87; x87 shim when it is 1 */

#include "core_math_private.h"

long double vectosignedyaw(const vec2_t vector)
{
    float degrees;

#if EMULATE_X87
    /* x87-faithful transcription (stock coduo_lnxded 0x0806707d): 180.0*atan2/pi
     * evaluated in 80-bit and rounded to float; no 360 wrap (signed result).
     * atan2 is a libm call left native (see [[x87-transcendental-audit]]). */
    if ((vector[1] == 0.0f) && (vector[0] == 0.0f)) {
        degrees = 0.0f;
    } else {
        degrees = x87f_store_f32(x87f_div(
            x87f_mul(
                x87f_load_f64(180.0),
                x87f_load_f64(atan2((double)vector[1], (double)vector[0]))),
            x87f_load_f64(3.141592653589793)));
    }
#else
    if ((vector[1] == 0.0f) && (vector[0] == 0.0f)) {
        degrees = 0.0f;
    } else {
        degrees = (float)((180.0 * atan2((double)vector[1],
                                         (double)vector[0])) /
                          3.141592653589793);
    }
#endif

    return (long double)degrees;
}
