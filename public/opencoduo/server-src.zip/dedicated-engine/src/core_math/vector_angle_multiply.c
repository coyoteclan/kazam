#include "coduo_x87emu.h" /* defines EMULATE_X87; x87 shim when it is 1 */

#include "core_math_private.h"

#include <string.h>

void VectorAngleMultiply(vec2_t point, float angleDegrees)
{
    float sinValue;
    float cosValue;
    float rotatedX;

#if EMULATE_X87
    /* x87-faithful transcription (stock coduo_lnxded 0x080695a6): angle*(pi/180)
     * in 80-bit to the fsincos leaf; each rotated component is an 80-bit
     * two-product sum/difference rounded to float. Original read-before-write
     * order preserved (rotatedX and point[1] both use the original point[0]). */
    SinCosFloat(x87f_store_f32(x87f_mul(x87f_load_f32(angleDegrees),
                                           x87f_load_f64(3.141592653589793 /
                                                         180.0))),
                   &sinValue, &cosValue);

    rotatedX = x87f_store_f32(
        x87f_sub(x87f_mul(x87f_load_f32(point[0]), x87f_load_f32(cosValue)),
                 x87f_mul(x87f_load_f32(point[1]), x87f_load_f32(sinValue))));
    point[1] = x87f_store_f32(
        x87f_add(x87f_mul(x87f_load_f32(point[1]), x87f_load_f32(cosValue)),
                 x87f_mul(x87f_load_f32(point[0]), x87f_load_f32(sinValue))));
#else
    SinCosFloat(
        (float)((double)angleDegrees * (3.141592653589793 / 180.0)),
        &sinValue, &cosValue);

    rotatedX = (point[0] * cosValue) - (point[1] * sinValue);
    point[1] = (point[1] * cosValue) + (point[0] * sinValue);
#endif
    memcpy(&point[0], &rotatedX, sizeof(point[0]));
}
