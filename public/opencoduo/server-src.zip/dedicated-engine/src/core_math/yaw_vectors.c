#include <string.h>

#include "coduo_x87emu.h" /* defines EMULATE_X87; x87 shim when it is 1 */

#include "core_math_private.h"

void YawVectors(float angleDegrees, vec3_t forward, vec3_t right)
{
    float angleRadians;
    float sinValue;
    float cosValue;

    /* Stock (0x0806763f) multiplies by the single folded double constant
     * pi/180 (0x3f91df46a2529d39 @ 0x80dd808) — one fmul, not mul-then-div.
     * The forward/right stores are raw dword copies and a sign-bit toggle;
     * only the degrees->radians product is carried through the shim. */
#if EMULATE_X87
    angleRadians = x87f_store_f32(x87f_mul(x87f_load_f32(angleDegrees),
                                           x87f_load_f64(3.141592653589793 /
                                                         180.0)));
#else
    angleRadians =
        (float)((double)angleDegrees * (3.141592653589793 / 180.0));
#endif
    SinCosFloat(angleRadians, &sinValue, &cosValue);

    if (forward != NULL) {
        memcpy(&forward[0], &cosValue, sizeof(forward[0]));
        memcpy(&forward[1], &sinValue, sizeof(forward[1]));
        forward[2] = 0.0f;
    }

    if (right != NULL) {
        uint32_t cosBits;

        memcpy(&right[0], &sinValue, sizeof(right[0]));
        memcpy(&cosBits, &cosValue, sizeof(cosBits));
        cosBits ^= CODUO_FLOAT_SIGN_BIT;
        memcpy(&right[1], &cosBits, sizeof(right[1]));
        right[2] = 0.0f;
    }
}
