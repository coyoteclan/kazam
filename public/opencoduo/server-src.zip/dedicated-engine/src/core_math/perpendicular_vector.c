#include <math.h>

#include "core_math_private.h"

void PerpendicularVector(vec3_t dst, const vec3_t src)
{
    vec3_t tempvec = {0.0f, 0.0f, 0.0f};
    float minelem = 1.0f;
    int pos = 0;

    for (int i = 0; i < 3; i++) {
        const float elem = fabsf(src[i]);
        if (elem < minelem) {
            minelem = elem;
            pos = i;
        }
    }

    tempvec[pos] = 1.0f;
    ProjectPointOnPlane(dst, tempvec, src);
    VectorNormalize(dst);
}
