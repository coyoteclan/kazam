#include <math.h>

#include "coduo_x87emu.h" /* defines EMULATE_X87; x87 shim when it is 1 */

#include "core_math_private.h"

long double SinSquaredDegrees(float angleDegrees)
{
    double sinValue;
    float result;

#if EMULATE_X87
    /* x87-faithful transcription (stock coduo_lnxded 0x08069a33): the degrees->
     * radians product angleDegrees*(pi/180) is formed in 80-bit and rounded to
     * double64 for the sin argument (the constant is the single folded double
     * 0x3f91df46a2529d39); the returned double is squared in 80-bit and rounded to
     * float. sin is a libm call left native (see [[x87-transcendental-audit]]). */
    const double radians = x87f_store_f64(
        x87f_mul(x87f_load_f32(angleDegrees),
                 x87f_load_f64(3.141592653589793 / 180.0)));
    sinValue = sin(radians);
    result = x87f_store_f32(
        x87f_mul(x87f_load_f64(sinValue), x87f_load_f64(sinValue)));
#else
    sinValue = sin((double)angleDegrees * (3.141592653589793 / 180.0));
    result = (float)(sinValue * sinValue);
#endif

    return (long double)result;
}
