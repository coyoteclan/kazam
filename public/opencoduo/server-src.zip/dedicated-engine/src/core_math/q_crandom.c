#include "core_math_private.h"

long double Q_crandom(int32_t *value)
{
    long double centered;

    centered = Q_random(value) - 0.5f;
    return centered + centered;
}
