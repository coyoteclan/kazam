#include "coduo_x87emu.h" /* defines EMULATE_X87; x87 shim when it is 1 */

#include "core_math_private.h"

void QuatFromXAxisDegrees(float angleDegrees, vec4_t out)
{
    float angleRadians;

#if EMULATE_X87
    /* half-angle in 80-bit to the fsincos leaf (stock coduo_lnxded 0x08069ba8). */
    angleRadians = x87f_store_f32(x87f_mul(
        x87f_load_f32(angleDegrees), x87f_load_f64(3.141592653589793 / 360.0)));
#else
    angleRadians =
        (float)((double)angleDegrees * (3.141592653589793 / 360.0));
#endif

    out[1] = 0.0f;
    out[2] = 0.0f;
    SinCosFloat(angleRadians, &out[0], &out[3]);
}
