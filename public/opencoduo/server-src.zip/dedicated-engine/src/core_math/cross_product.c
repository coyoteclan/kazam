#include "coduo_x87emu.h" /* defines EMULATE_X87; x87 shim when it is 1 */

#include "core_math_private.h"

void CrossProduct(const vec3_t left, const vec3_t right, vec3_t out)
{
#if EMULATE_X87
    /* x87-faithful transcription (stock coduo_lnxded 0x080666b1): each
     * component is two 80-bit products and an 80-bit subtract, rounded to
     * float only at the single store (fld;fmul;fld;fmul;fsubp;fstp per lane).
     * Loads happen in program order, so if out aliases left/right the same
     * intermediate values are read as by the original. */
    out[0] = x87f_store_f32(x87f_sub(
        x87f_mul(x87f_load_f32(left[1]), x87f_load_f32(right[2])),
        x87f_mul(x87f_load_f32(left[2]), x87f_load_f32(right[1]))));
    out[1] = x87f_store_f32(x87f_sub(
        x87f_mul(x87f_load_f32(left[2]), x87f_load_f32(right[0])),
        x87f_mul(x87f_load_f32(left[0]), x87f_load_f32(right[2]))));
    out[2] = x87f_store_f32(x87f_sub(
        x87f_mul(x87f_load_f32(left[0]), x87f_load_f32(right[1])),
        x87f_mul(x87f_load_f32(left[1]), x87f_load_f32(right[0]))));
#else
    out[0] = (left[1] * right[2]) - (left[2] * right[1]);
    out[1] = (left[2] * right[0]) - (left[0] * right[2]);
    out[2] = (left[0] * right[1]) - (left[1] * right[0]);
#endif
}
