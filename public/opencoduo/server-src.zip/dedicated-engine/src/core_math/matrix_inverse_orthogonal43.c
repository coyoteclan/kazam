#include "core_math_private.h"

void MatrixInverseOrthogonal43(const coduo_compact_affine_matrix43_t *in,
                               coduo_compact_affine_matrix43_t *out)
{
    vec3_t inverseOrigin;

    MatrixTranspose(in->axis, out->axis);

    /* Stock 0x08068ae4..0x08068b14 loads each vec3_origin lane before
     * subtracting the input origin. Preserve that global dependency and the
     * arithmetic positive-zero subtraction rather than using unary negation. */
    inverseOrigin[0] = vec3_origin[0] - in->origin[0];
    inverseOrigin[1] = vec3_origin[1] - in->origin[1];
    inverseOrigin[2] = vec3_origin[2] - in->origin[2];

    MatrixTransformVector(inverseOrigin, out->axis, out->origin);
}
