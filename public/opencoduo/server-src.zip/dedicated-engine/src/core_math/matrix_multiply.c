#include "coduo_x87emu.h" /* defines EMULATE_X87; x87 shim when it is 1 */

#include "core_math_private.h"

void MatrixMultiply(float in1[3][3], float in2[3][3], float out[3][3])
{
#if EMULATE_X87
    /* x87-faithful transcription (stock coduo_lnxded 0x080678fc): each
     * out[i][j] is the 80-bit dot ((in1[i][0]*in2[0][j] + in1[i][1]*in2[1][j]) +
     * in1[i][2]*in2[2][j]), rounded to float only at the store. */
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            out[i][j] = x87f_store_f32(x87f_add(
                x87f_add(
                    x87f_mul(x87f_load_f32(in1[i][0]), x87f_load_f32(in2[0][j])),
                    x87f_mul(x87f_load_f32(in1[i][1]), x87f_load_f32(in2[1][j]))),
                x87f_mul(x87f_load_f32(in1[i][2]), x87f_load_f32(in2[2][j]))));
        }
    }
#else
    out[0][0] =
        (in1[0][0] * in2[0][0]) + (in1[0][1] * in2[1][0]) +
        (in1[0][2] * in2[2][0]);
    out[0][1] =
        (in1[0][0] * in2[0][1]) + (in1[0][1] * in2[1][1]) +
        (in1[0][2] * in2[2][1]);
    out[0][2] =
        (in1[0][0] * in2[0][2]) + (in1[0][1] * in2[1][2]) +
        (in1[0][2] * in2[2][2]);

    out[1][0] =
        (in1[1][0] * in2[0][0]) + (in1[1][1] * in2[1][0]) +
        (in1[1][2] * in2[2][0]);
    out[1][1] =
        (in1[1][0] * in2[0][1]) + (in1[1][1] * in2[1][1]) +
        (in1[1][2] * in2[2][1]);
    out[1][2] =
        (in1[1][0] * in2[0][2]) + (in1[1][1] * in2[1][2]) +
        (in1[1][2] * in2[2][2]);

    out[2][0] =
        (in1[2][0] * in2[0][0]) + (in1[2][1] * in2[1][0]) +
        (in1[2][2] * in2[2][0]);
    out[2][1] =
        (in1[2][0] * in2[0][1]) + (in1[2][1] * in2[1][1]) +
        (in1[2][2] * in2[2][1]);
    out[2][2] =
        (in1[2][0] * in2[0][2]) + (in1[2][1] * in2[1][2]) +
        (in1[2][2] * in2[2][2]);
#endif
}
