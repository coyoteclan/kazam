#ifndef CODUO_CORE_INFO_PRIVATE_H
#define CODUO_CORE_INFO_PRIVATE_H

#include "coduo_engine_structs.h"
#include "info.h"

#endif
