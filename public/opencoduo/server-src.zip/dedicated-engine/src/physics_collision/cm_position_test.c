#include "cm_leaf_queries_private.h"
#include "cm_trace_core_private.h"

void CM_PositionTest(traceWork_t *traceWork)
{
    cmLeafQueryWork_t leafWork;
    int32_t leafList[1024];
    vec3_t mins;
    vec3_t maxs;

    mins[0] = traceWork->start[0] + traceWork->mins[0];
    mins[1] = traceWork->start[1] + traceWork->mins[1];
    mins[2] = traceWork->start[2] + traceWork->mins[2];
    maxs[0] = traceWork->start[0] + traceWork->maxs[0];
    maxs[1] = traceWork->start[1] + traceWork->maxs[1];
    maxs[2] = traceWork->start[2] + traceWork->maxs[2];

    for (int32_t axis = 0; axis < 3; ++axis) {
        mins[axis] -= 1.0f;
        maxs[axis] += 1.0f;
    }

    leafWork.count = 0;
    leafWork.maxcount = 1024;
    leafWork.list = leafList;
    leafWork.storeLeafs = CM_StoreLeafs;
    leafWork.lastLeaf = 0;
    leafWork.overflowed = 0;
    leafWork.mins[0] = mins[0];
    leafWork.mins[1] = mins[1];
    leafWork.mins[2] = mins[2];
    leafWork.maxs[0] = maxs[0];
    leafWork.maxs[1] = maxs[1];
    leafWork.maxs[2] = maxs[2];

    cm_checkcount++;
    CM_BoxLeafnums_r(&leafWork, 0);
    cm_checkcount++;

    for (int32_t leafIndex = 0; leafIndex < leafWork.count; ++leafIndex) {
        CM_TestInLeaf(traceWork, &cm_leafs[leafList[leafIndex]]);

        if (traceWork->trace.allsolid != 0) {
            return;
        }
    }
}
