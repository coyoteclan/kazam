#include "cm_world_sector_private.h"

void SV_TraceEntities(cmClipMoveWork_t *traceWork)
{
    SV_TraceEntities_r(traceWork, &cm_worldSectorRoot, 0.0f,
                 traceWork->bestTrace.fraction, traceWork->start,
                 traceWork->end);
}
