#include "cm_patch_private.h"

void CM_TraceThroughPatchCollide(traceWork_t *traceWork,
                                 const coduo_patch_collide_t *patchCollide)
{
    if (traceWork->isPoint != 0) {
        CM_TracePointThroughPatchCollide(traceWork, patchCollide);
        return;
    }

    if (traceWork->sphere.use != 0) {
        const float savedStartZ = traceWork->start[2];
        const float savedEndZ = traceWork->end[2];

        CM_TraceCapsuleThroughPatchCollide(traceWork, patchCollide);

        traceWork->start[2] = savedStartZ;
        traceWork->end[2] = savedEndZ;
        return;
    }

    CM_TraceBoxThroughPatchCollide(traceWork, patchCollide);
}
