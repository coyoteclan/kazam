#include "cm_world_sector_private.h"

int32_t
SV_SweptSightTraceEntities(cmClipSightTraceWork_t *sightTraceWork)
{
    return SV_SweptSightTraceEntities_r(sightTraceWork, &cm_worldSectorRoot, 0.0f, 1.0f,
                        sightTraceWork->start, sightTraceWork->end);
}
