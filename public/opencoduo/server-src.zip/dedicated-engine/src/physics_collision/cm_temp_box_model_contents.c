#include "cm_trace_core_private.h"

int32_t CM_TempBoxModelContents(void)
{
    return cm_boxBrush->contents;
}
