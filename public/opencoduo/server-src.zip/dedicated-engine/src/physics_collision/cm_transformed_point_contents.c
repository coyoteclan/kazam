#include "../core_math/core_math_private.h"
#include "cm_world_sector_private.h"

enum {
    CM_TEMP_BOX_MODEL_HANDLE = 0x1ff
};

int32_t CM_TransformedPointContents(const vec3_t point,
                                                  int32_t model,
                                                  const vec3_t origin,
                                                  const vec3_t angles)
{
    vec3_t transformed;
    vec3_t forward;
    vec3_t right;
    vec3_t up;
    vec3_t temp;

    transformed[0] = point[0] - origin[0];
    transformed[1] = point[1] - origin[1];
    transformed[2] = point[2] - origin[2];

    if (model != CM_TEMP_BOX_MODEL_HANDLE &&
        (angles[0] != 0.0f || angles[1] != 0.0f || angles[2] != 0.0f)) {
        AngleVectors(angles, forward, right, up);

        temp[0] = transformed[0];
        temp[1] = transformed[1];
        temp[2] = transformed[2];

        transformed[0] =
            temp[0] * forward[0] + temp[1] * forward[1] + temp[2] * forward[2];
        transformed[1] =
            -(temp[0] * right[0] + temp[1] * right[1] + temp[2] * right[2]);
        transformed[2] =
            temp[0] * up[0] + temp[1] * up[1] + temp[2] * up[2];
    }

    return CM_PointContents(transformed, model);
}
