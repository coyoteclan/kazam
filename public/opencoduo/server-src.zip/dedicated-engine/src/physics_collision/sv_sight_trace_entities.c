#include "cm_world_sector_private.h"

void SV_SightTraceEntities(cmPointTraceWork_t *sightTraceWork)
{
    SV_SightTraceEntities_r(sightTraceWork, &cm_worldSectorRoot, 0.0f,
                 sightTraceWork->bestTrace.fraction, sightTraceWork->start,
                 sightTraceWork->end);
}
