#include "cm_trace_core_private.h"

void CM_ModelBounds(int32_t model, vec3_t mins, vec3_t maxs)
{
    const coduo_collision_model_t *cmod;

    cmod = CM_ClipHandleToModel(model);
    mins[0] = cmod->mins[0];
    mins[1] = cmod->mins[1];
    mins[2] = cmod->mins[2];
    maxs[0] = cmod->maxs[0];
    maxs[1] = cmod->maxs[1];
    maxs[2] = cmod->maxs[2];
}
