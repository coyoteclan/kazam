#include "cm_world_sector_private.h"

void CM_InitWorldSector(void)
{
    int32_t model;
    uint32_t sectorIndex;
    float width0;
    float width1;

    model = CM_InlineModel(0);
    CM_ModelBounds(model, cm_worldMins, cm_worldMaxs);

    cm_freeWorldSectors = &cm_worldSectorPool[0];
    for (sectorIndex = 0; sectorIndex < CODUO_WORLD_SECTOR_POOL_COUNT - 1;
         sectorIndex++) {
        cm_worldSectorPool[sectorIndex].parent =
            CM_StoreWorldSector(&cm_worldSectorPool[sectorIndex + 1]);
    }

    cm_worldSectorPool[CODUO_WORLD_SECTOR_POOL_COUNT - 1].parent = NULL;

    width0 = cm_worldMaxs[0] - cm_worldMins[0];
    width1 = cm_worldMaxs[1] - cm_worldMins[1];
    cm_worldSectorRoot.axis = width0 <= width1;
    cm_worldSectorRoot.dist =
        (cm_worldMaxs[cm_worldSectorRoot.axis] +
         cm_worldMins[cm_worldSectorRoot.axis]) *
        0.5f;
    cm_worldSectorRoot.children[0] = CM_StoreWorldSector(&cm_nullWorldSector);
    cm_worldSectorRoot.children[1] = CM_StoreWorldSector(&cm_nullWorldSector);
}
