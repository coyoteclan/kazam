#include "cm_patch_private.h"
#include "cm_terrain_private.h"
#include "cm_trace_core_private.h"

qboolean CM_SightTraceThroughPatch(
    const traceWork_t *traceWork,
    const coduo_collision_terrain_patch_t *terrainPatch)
{
    /*
     * ORIGINAL_BINARY_BUG: see
     * original-bugs/coduomp-sight-trace-cached-terrain-clear-hit.md.
     * This clear predicate is correct for tree traversal, but CM_SightTrace's
     * cached-terrain path also consumes it directly as a one-based hit.
     */
    if (CM_TraceMayIntersectBox(traceWork, terrainPatch->mins,
                                     terrainPatch->maxs) == 0) {
        return 1;
    }

    if (terrainPatch->terrainCollide != NULL) {
        return CM_SightTraceThroughTerrainCollide(
            traceWork, terrainPatch->terrainCollide);
    }

    return CM_SightTraceThroughPatchCollide(traceWork,
                                           terrainPatch->patchCollide);
}
