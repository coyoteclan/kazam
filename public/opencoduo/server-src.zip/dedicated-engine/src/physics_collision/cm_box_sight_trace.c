#include "cm_trace_core_private.h"

static const vec3_t cm_box_sight_trace_origin = {0.0f, 0.0f, 0.0f};

int32_t
CM_BoxSightTrace(int32_t result,
                 const vec3_t start,
                 const vec3_t end,
                 const vec3_t mins,
                 const vec3_t maxs,
                 int32_t model,
                 int32_t brushMask,
                 qboolean capsule)
{
    return CM_SightTrace(result, start, end, mins, maxs, model,
                         cm_box_sight_trace_origin, brushMask, capsule, NULL);
}
