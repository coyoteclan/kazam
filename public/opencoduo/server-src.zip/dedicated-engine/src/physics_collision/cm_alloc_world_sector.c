#include "cm_world_sector_private.h"

worldSector_t *CM_AllocWorldSector(const float mins[2],
                                          const float maxs[2])
{
    worldSector_t *sector;
    float size[2];
    int32_t axis;

    sector = cm_freeWorldSectors;
    if (sector == NULL) {
        return NULL;
    }

    size[0] = maxs[0] - mins[0];
    size[1] = maxs[1] - mins[1];
    axis = size[0] <= size[1];

    if (size[axis] <= 512.0f) {
        return 0;
    }

    cm_freeWorldSectors = CM_LoadWorldSector(cm_freeWorldSectors->parent);
    sector->axis = axis;
    sector->dist = (maxs[axis] + mins[axis]) * 0.5f;
    sector->children[0] = CM_StoreWorldSector(&cm_nullWorldSector);
    sector->children[1] = CM_StoreWorldSector(&cm_nullWorldSector);

    return sector;
}
