#include "cm_leaf_queries_private.h"
#include "cm_trace_core_private.h"

int32_t
CM_BoxLeafnums(const vec3_t mins, const vec3_t maxs,
               int32_t *list,
               int32_t listSize,
               int32_t *lastLeaf)
{
    cmLeafQueryWork_t work;

    cm_checkcount++;

    work.mins[0] = mins[0];
    work.mins[1] = mins[1];
    work.mins[2] = mins[2];
    work.maxs[0] = maxs[0];
    work.maxs[1] = maxs[1];
    work.maxs[2] = maxs[2];
    work.count = 0;
    work.maxcount = listSize;
    work.list = list;
    work.storeLeafs = CM_StoreLeafs;
    work.lastLeaf = 0;
    work.overflowed = 0;

    CM_BoxLeafnums_r(&work, 0);
    *lastLeaf = work.lastLeaf;
    return work.count;
}
