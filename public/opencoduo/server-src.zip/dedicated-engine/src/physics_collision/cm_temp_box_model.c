#include "cm_trace_core_private.h"

enum {
    CM_TEMP_CAPSULE_MODEL_HANDLE = 510,
    CM_TEMP_BOX_MODEL_HANDLE = 511
};

int32_t CM_TempBoxModel(const vec3_t mins, const vec3_t maxs,
                                    int32_t contents,
                                    qboolean capsule)
{
    cm_boxModel.mins[0] = mins[0];
    cm_boxModel.mins[1] = mins[1];
    cm_boxModel.mins[2] = mins[2];
    cm_boxModel.maxs[0] = maxs[0];
    cm_boxModel.maxs[1] = maxs[1];
    cm_boxModel.maxs[2] = maxs[2];

    cm_boxBrush->mins[0] = mins[0];
    cm_boxBrush->mins[1] = mins[1];
    cm_boxBrush->mins[2] = mins[2];
    cm_boxBrush->maxs[0] = maxs[0];
    cm_boxBrush->maxs[1] = maxs[1];
    cm_boxBrush->maxs[2] = maxs[2];
    cm_boxBrush->contents = contents;

    if (capsule) {
        return CM_TEMP_CAPSULE_MODEL_HANDLE;
    }

    return CM_TEMP_BOX_MODEL_HANDLE;
}
