#include "cm_patch_private.h"

qboolean CM_PositionTestInPatchCollide(traceWork_t *traceWork,
                                     const coduo_patch_collide_t *patchCollide)
{
    if (traceWork->isPoint != 0) {
        return 0;
    }

    const float savedStartZ = traceWork->start[2];
    const float savedEndZ = traceWork->end[2];
    const qboolean result =
        CM_TestCapsuleInPatchCollide(traceWork, patchCollide);

    traceWork->start[2] = savedStartZ;
    traceWork->end[2] = savedEndZ;

    return result;
}
