#include "../core_runtime/core_runtime_private.h"
#include "coduo_engine_structs.h"

#include "cm_collision_globals_private.h"
#include "cm_leaf_queries_private.h"
#include "cm_trace_core_private.h"

int32_t CM_InlineModel(int32_t modelNum)
{
    if (modelNum < 0 || cm_numSubModels <= modelNum) {
        Com_Error(1, "\x15" "CM_InlineModel: bad number");
    }

    return modelNum;
}

int32_t CM_NumClusters(void)
{
    return cm_numClusters;
}

int32_t CM_NumInlineModels(void)
{
    return cm_numSubModels;
}

char *CM_EntityString(void)
{
    return cm_entityString;
}

int32_t CM_LeafCluster(
    int32_t leafnum)
{
    return cm_leafs[leafnum].cluster;
}

int32_t CM_LeafArea(int32_t leafnum)
{
    return cm_leafs[leafnum].area;
}

int32_t CM_PointLeafnum(const vec3_t point)
{
    return CM_PointLeafnum_r(point, 0);
}

const uint8_t *CM_ClusterPVS(int32_t cluster)
{
    if (cluster < 0 || cm_numClusters <= cluster || !cm_visibilityLoaded) {
        return cm_visibility;
    }

    return cm_visibility + cluster * cm_clusterBytes;
}
