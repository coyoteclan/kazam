#include "cm_trace_core_private.h"

void CM_InitBoxHull(void)
{
    cm_boxBrush = &cm_brushes[cm_numBrushes];
    cm_boxBrush->numSides = 0;
    cm_boxBrush->sides = 0;
    cm_boxBrush->contents = -1;
    cm_boxBrush->axialMaterialIndices[0] = -1;
    cm_boxBrush->axialMaterialIndices[1] = -1;
    cm_boxBrush->axialMaterialIndices[2] = -1;
    cm_boxBrush->axialMaterialIndices[3] = -1;
    cm_boxBrush->axialMaterialIndices[4] = -1;
    cm_boxBrush->axialMaterialIndices[5] = -1;
    cm_boxModel.leaf.numLeafBrushes = 1;
    cm_boxModel.leaf.firstLeafBrush = cm_numLeafBrushes;
    cm_leafbrushes[cm_numLeafBrushes] = cm_numBrushes;
}
