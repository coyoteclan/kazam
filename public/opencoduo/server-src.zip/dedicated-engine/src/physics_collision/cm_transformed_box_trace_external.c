#include "cm_trace_core_private.h"

void CM_TransformedBoxTraceExternal(trace_t *trace,
                                    const vec3_t start,
                                    const vec3_t end,
                                    const vec3_t mins,
                                    const vec3_t maxs,
                                    int32_t model,
                                    int32_t brushMask,
                                    const vec3_t origin,
                                    const vec3_t angles,
                                    qboolean capsule)
{
    trace->fraction = 1.0f;
    CM_TransformedBoxTrace(trace, start, end, mins, maxs, model, brushMask,
                           origin, angles, capsule);
}
