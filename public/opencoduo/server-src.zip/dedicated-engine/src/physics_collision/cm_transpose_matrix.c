#include "coduo_engine_structs.h"

void TransposeMatrix(vec3_t in[3], vec3_t out[3])
{
    int i;
    int j;

    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            out[i][j] = in[j][i];
        }
    }
}
