#include "../core_math/core_math_private.h"

void CreateRotationMatrix(const vec3_t angles, vec3_t matrix[3])
{
    AngleVectors(angles, matrix[0], matrix[1], matrix[2]);
    VectorInverse(matrix[1]);
}
