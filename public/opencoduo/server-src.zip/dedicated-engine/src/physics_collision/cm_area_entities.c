#include "cm_world_sector_private.h"

int32_t
CM_AreaEntities(const vec3_t mins, const vec3_t maxs,
                int32_t *entityList,
                int32_t maxcount,
                int32_t contentMask)
{
    coduo_area_entities_work_t work;

    work.mins = mins;
    work.maxs = maxs;
    work.entityList = entityList;
    work.count = 0;
    work.maxcount = maxcount;
    work.contentMask = contentMask;

    CM_AreaEntities_r(&cm_worldSectorRoot, &work);

    return work.count;
}
