#include "../core_runtime/core_runtime_private.h"
#include "cm_patch_private.h"

static qboolean cm_patchBoxCollisionWarningPrinted;

void CM_TraceBoxThroughPatchCollide(traceWork_t *traceWork,
                                    const coduo_patch_collide_t *patchCollide)
{
    if (cm_patchBoxCollisionWarningPrinted == 0) {
        cm_patchBoxCollisionWarningPrinted = 1;
        Com_DPrintf("^1Box collision on terrain currently being faked with "
                    "capsule collision\n");
    }

    traceWork->sphere.use = 1;

    const float savedStartZ = traceWork->start[2];
    const float savedEndZ = traceWork->end[2];
    const float savedRadius =
        traceWork->sphere.radius;

    traceWork->sphere.radius = traceWork->maxs[0];
    CM_TraceCapsuleThroughPatchCollide(traceWork, patchCollide);

    traceWork->sphere.use = 0;
    traceWork->start[2] = savedStartZ;
    traceWork->end[2] = savedEndZ;
    traceWork->sphere.radius = savedRadius;
}
