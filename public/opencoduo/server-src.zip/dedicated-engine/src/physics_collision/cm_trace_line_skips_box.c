#include "cm_world_sector_private.h"

qboolean CM_TraceLineSkipsBox(const vec3_t start,
                                    const vec3_t end,
                                    const vec3_t mins,
                                    const vec3_t maxs,
                                    float fraction)
{
    float enterFraction = 0.0f;
    float leaveFraction = fraction;
    float sideScale = -1.0f;
    const float *bounds = mins;

    for (;;) {
        for (int axis = 0; axis < 3; ++axis) {
            const float startOffset = (start[axis] - bounds[axis]) * sideScale;
            const float endOffset = (end[axis] - bounds[axis]) * sideScale;

            if (0.0f < startOffset) {
                if (0.0f < endOffset) {
                    return 1;
                }

                const float offsetDelta = startOffset - endOffset;
                if ((enterFraction * offsetDelta) < startOffset) {
                    enterFraction = startOffset / offsetDelta;
                    if (leaveFraction <= enterFraction) {
                        return 1;
                    }
                }
            } else {
                if (0.0f < endOffset) {
                    const float offsetDelta = startOffset - endOffset;
                    if ((leaveFraction * offsetDelta) < startOffset) {
                        leaveFraction = startOffset / offsetDelta;
                        if (leaveFraction <= enterFraction) {
                            return 1;
                        }
                    }
                }
            }
        }

        if (sideScale == 1.0f) {
            return 0;
        }

        sideScale = 1.0f;
        bounds = maxs;
    }
}
