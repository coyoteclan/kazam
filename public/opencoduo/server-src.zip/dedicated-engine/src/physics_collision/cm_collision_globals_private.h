#ifndef CODUO_CM_COLLISION_GLOBALS_PRIVATE_H
#define CODUO_CM_COLLISION_GLOBALS_PRIVATE_H

#include <stdint.h>

#include "cm_world_sector_private.h"

extern int32_t cm_numClusters;
extern int32_t cm_numAreas;
extern int32_t cm_clusterBytes;
extern uint8_t *cm_visibility;
extern qboolean cm_visibilityLoaded;
extern char *cm_entityString;
extern int32_t cm_entityStringLength;
extern coduo_collision_area_t *cm_areas;
extern int32_t *cm_areaPortals;
extern int32_t cm_floodValid;
extern int32_t cm_staticModelCount;
extern worldSectorAreaLink_t *cm_staticModels;

#endif
