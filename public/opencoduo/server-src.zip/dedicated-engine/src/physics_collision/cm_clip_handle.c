#include "../core_runtime/core_runtime_private.h"
#include "cm_trace_core_private.h"

enum {
    CM_TEMP_CAPSULE_MODEL_HANDLE = 510,
    CM_TEMP_BOX_MODEL_HANDLE = 511,
    CM_MAX_CLIP_HANDLE = 512
};

const coduo_collision_model_t *CM_ClipHandleToModel(int32_t handle)
{
    const coduo_collision_model_t *model;

    if (handle < 0) {
        Com_Error(1, "\x15" "CM_ClipHandleToModel: bad handle %i", handle);
    }

    if (handle < cm_numSubModels) {
        model = &cm_cmodels[handle];
    } else if (handle == CM_TEMP_BOX_MODEL_HANDLE ||
               handle == CM_TEMP_CAPSULE_MODEL_HANDLE) {
        model = &cm_boxModel;
    } else {
        if (handle < CM_MAX_CLIP_HANDLE) {
            Com_Error(1, "\x15"
                         "CM_ClipHandleToModel: bad handle %i < %i < %i",
                      cm_numSubModels, handle, CM_MAX_CLIP_HANDLE);
        }

        int32_t diagnosticHandle = handle + CM_MAX_CLIP_HANDLE;
        Com_Error(1, "\x15" "CM_ClipHandleToModel: bad handle %i",
                  diagnosticHandle);
        model = 0;
    }

    return model;
}
