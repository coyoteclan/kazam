#include "cm_trace_core_private.h"

void CM_BoxTrace(trace_t *trace,
                 const vec3_t start,
                 const vec3_t end,
                 const vec3_t mins,
                 const vec3_t maxs,
                 int32_t model,
                 int32_t brushMask,
                 qboolean capsule)
{
    trace->fraction = 1.0f;
    CM_Trace(trace, start, end, mins, maxs, model, brushMask, capsule, NULL);
}
