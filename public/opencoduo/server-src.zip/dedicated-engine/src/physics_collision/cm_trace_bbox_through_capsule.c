#include "cm_trace_core_private.h"

void CM_TraceBoundingBoxThroughCapsule(traceWork_t *traceWork)
{
    vec3_t capsuleCenter;
    vec3_t capsuleMinsFromCenter;
    vec3_t capsuleMaxsFromCenter;
    float capsuleRadius;

    for (int axis = 0; axis < 3; ++axis) {
        capsuleCenter[axis] =
            (cm_boxModel.mins[axis] + cm_boxModel.maxs[axis]) * 0.5f;
        capsuleMinsFromCenter[axis] =
            cm_boxModel.mins[axis] - capsuleCenter[axis];
        capsuleMaxsFromCenter[axis] =
            cm_boxModel.maxs[axis] - capsuleCenter[axis];
        traceWork->start[axis] -= capsuleCenter[axis];
        traceWork->end[axis] -= capsuleCenter[axis];
    }
    (void)capsuleMinsFromCenter;

    traceWork->sphere.use = 1;
    if (capsuleMaxsFromCenter[2] < capsuleMaxsFromCenter[0]) {
        capsuleRadius = capsuleMaxsFromCenter[2];
    } else {
        capsuleRadius = capsuleMaxsFromCenter[0];
    }
    traceWork->sphere.radius = capsuleRadius;
    traceWork->sphere.halfheight = capsuleMaxsFromCenter[2];
    traceWork->sphere.offset[0] = 0.0f;
    traceWork->sphere.offset[1] = 0.0f;
    traceWork->sphere.offset[2] =
        capsuleMaxsFromCenter[2] - traceWork->sphere.radius;
    traceWork->sphereExtents[0] = traceWork->sphere.radius;
    traceWork->sphereExtents[1] = traceWork->sphere.radius;
    traceWork->sphereExtents[2] = traceWork->sphere.halfheight;

    CM_TempBoxModel(traceWork->mins, traceWork->maxs, cm_boxBrush->contents, 0);
    CM_TraceThroughBrush(traceWork, cm_boxBrush);
}
