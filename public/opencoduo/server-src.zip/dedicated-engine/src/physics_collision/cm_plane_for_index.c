#include "cm_world_sector_private.h"

cplane_t *CM_PlaneForIndex(int32_t planeIndex)
{
    return &cm_planes[planeIndex];
}
