#include "cm_leaf_queries_private.h"

void CM_BoxLeafnums_r(cmLeafQueryWork_t *work, int32_t nodeNum)
{
    while (nodeNum >= 0) {
        const coduo_collision_node_t *node = &cm_nodes[nodeNum];
        const int32_t side =
            BoxOnPlaneSide(work->mins, work->maxs, node->plane);

        if (side == 1) {
            nodeNum = node->children[0];
        } else if (side == 2) {
            nodeNum = node->children[1];
        } else {
            CM_BoxLeafnums_r(work, node->children[0]);
            nodeNum = node->children[1];
        }
    }

    work->storeLeafs(work, nodeNum);
}
