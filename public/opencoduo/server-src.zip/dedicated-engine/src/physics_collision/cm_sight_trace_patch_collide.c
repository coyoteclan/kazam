#include "cm_patch_private.h"

qboolean CM_SightTraceThroughPatchCollide(
    const traceWork_t *traceWork,
    const coduo_patch_collide_t *patchCollide)
{
    traceWork_t sightTraceWork = *traceWork;

    sightTraceWork.trace.fraction = 1.0f;
    CM_TraceThroughPatchCollide(&sightTraceWork, patchCollide);

    return sightTraceWork.trace.fraction == 1.0f;
}
