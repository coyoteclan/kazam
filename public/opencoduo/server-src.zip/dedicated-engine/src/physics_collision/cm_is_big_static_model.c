#include "cm_world_sector_private.h"

qboolean CM_IsBigStaticModel(const vec3_t mins, const vec3_t maxs)
{
    (void)mins;
    (void)maxs;

    return qfalse;
}
