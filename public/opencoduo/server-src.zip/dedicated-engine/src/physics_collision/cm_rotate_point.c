#include "coduo_engine_structs.h"
#include "coduo_x87emu.h" /* defines EMULATE_X87; x87 shim when it is 1 */

void RotatePoint(vec3_t point, vec3_t matrix[3])
{
    const float x = point[0];
    const float y = point[1];
    const float z = point[2];

    /* Each row dot matrix[k].(x,y,z) is 3-mul/2-add kept 80-bit, one store. */
#if EMULATE_X87
    for (int k = 0; k < 3; k++) {
        point[k] = x87f_store_f32(x87f_add(x87f_add(
            x87f_mul(x87f_load_f32(matrix[k][0]), x87f_load_f32(x)),
            x87f_mul(x87f_load_f32(matrix[k][1]), x87f_load_f32(y))),
            x87f_mul(x87f_load_f32(matrix[k][2]), x87f_load_f32(z))));
    }
#else
    point[0] = matrix[0][0] * x + matrix[0][1] * y + matrix[0][2] * z;
    point[1] = matrix[1][0] * x + matrix[1][1] * y + matrix[1][2] * z;
    point[2] = matrix[2][0] * x + matrix[2][1] * y + matrix[2][2] * z;
#endif
}
