#include "cm_world_sector_private.h"

qboolean CM_SightTraceStaticModels(const vec3_t start,
                                   const vec3_t end,
                                   int32_t contentsMask)
{
    cmSightTraceStaticModelsWork_t work;

    work.contentsMask = contentsMask;
    work.start[0] = start[0];
    work.start[1] = start[1];
    work.start[2] = start[2];
    work.end[0] = end[0];
    work.end[1] = end[1];
    work.end[2] = end[2];

    return CM_SightTraceStaticModels_r(&work, &cm_worldSectorRoot, 0.0f,
                                       1.0f, work.start, work.end) != 0;
}
