#include "cm_world_sector_private.h"

int32_t
SV_PointSightTraceEntities(cmPointSightTraceWork_t *sightTraceWork)
{
    return SV_PointSightTraceEntities_r(sightTraceWork, &cm_worldSectorRoot, 0.0f, 1.0f,
                        sightTraceWork->start, sightTraceWork->end);
}
