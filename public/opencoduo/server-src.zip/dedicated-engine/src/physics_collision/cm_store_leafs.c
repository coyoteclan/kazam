#include "cm_leaf_queries_private.h"

void CM_StoreLeafs(cmLeafQueryWork_t *work, int32_t nodeNum)
{
    int32_t leafnum = -1 - nodeNum;
    int32_t *leafNums = work->list;

    if (cm_leafs[leafnum].cluster != -1) {
        work->lastLeaf = leafnum;
    }

    if (work->count < work->maxcount) {
        leafNums[work->count] = leafnum;
        work->count++;
    } else {
        work->overflowed = 1;
    }
}
