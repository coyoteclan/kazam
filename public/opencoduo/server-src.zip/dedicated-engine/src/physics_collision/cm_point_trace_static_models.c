#include <string.h>

#include "cm_world_sector_private.h"

void CM_PointTraceStaticModels(trace_t *trace,
                               const vec3_t start,
                               const vec3_t end,
                               int32_t contentsMask)
{
    cmPointTraceStaticModelsWork_t work;

    memset(&work.trace, 0, sizeof(work.trace));
    work.trace.fraction = trace->fraction;
    work.contentsMask = contentsMask;
    work.start[0] = start[0];
    work.start[1] = start[1];
    work.start[2] = start[2];
    work.end[0] = end[0];
    work.end[1] = end[1];
    work.end[2] = end[2];

    CM_PointTraceStaticModels_r(&work, &cm_worldSectorRoot, 0.0f,
                                work.trace.fraction, work.start, work.end);

    if (work.trace.fraction < trace->fraction) {
        vec3_t delta;

        delta[0] = end[0] - start[0];
        delta[1] = end[1] - start[1];
        delta[2] = end[2] - start[2];

        work.trace.endpos[0] = start[0] + delta[0] * work.trace.fraction;
        work.trace.endpos[1] = start[1] + delta[1] * work.trace.fraction;
        work.trace.endpos[2] = start[2] + delta[2] * work.trace.fraction;

        *trace = work.trace;
    }
}
