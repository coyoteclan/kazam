#include "cm_trace_core_private.h"

int32_t
CM_SightTraceBoundingBoxThroughCapsule(traceWork_t *traceWork)
{
    vec3_t boxCenter;
    vec3_t boxMinsFromCenter;
    vec3_t boxMaxsFromCenter;
    float radius;

    for (int32_t axis = 0; axis < 3; ++axis) {
        boxCenter[axis] =
            (cm_boxModel.mins[axis] + cm_boxModel.maxs[axis]) * 0.5f;
        boxMinsFromCenter[axis] = cm_boxModel.mins[axis] - boxCenter[axis];
        boxMaxsFromCenter[axis] = cm_boxModel.maxs[axis] - boxCenter[axis];
        traceWork->start[axis] -= boxCenter[axis];
        traceWork->end[axis] -= boxCenter[axis];
    }
    (void)boxMinsFromCenter;

    traceWork->sphere.use = 1;
    if (boxMaxsFromCenter[2] < boxMaxsFromCenter[0]) {
        radius = boxMaxsFromCenter[2];
    } else {
        radius = boxMaxsFromCenter[0];
    }
    traceWork->sphere.radius = radius;
    traceWork->sphere.halfheight = boxMaxsFromCenter[2];
    traceWork->sphere.offset[0] = 0.0f;
    traceWork->sphere.offset[1] = 0.0f;
    traceWork->sphere.offset[2] =
        boxMaxsFromCenter[2] - traceWork->sphere.radius;
    traceWork->sphereExtents[0] = traceWork->sphere.radius;
    traceWork->sphereExtents[1] = traceWork->sphere.radius;
    traceWork->sphereExtents[2] = traceWork->sphere.halfheight;

    CM_TempBoxModel(traceWork->mins, traceWork->maxs, cm_boxBrush->contents, 0);
    return CM_SightTraceThroughBrush(traceWork, cm_boxBrush);
}
