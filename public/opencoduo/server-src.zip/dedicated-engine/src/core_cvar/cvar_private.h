#ifndef CODUO_CVAR_PRIVATE_H
#define CODUO_CVAR_PRIVATE_H

#include "coduo_engine_structs.h"
#include "com_sprintf.h"
#include "q_string_compare.h"

enum {
    CODUO_CVAR_HASH_BASE_INDEX = 119,
    CODUO_CVAR_HASH_MASK = CODUO_ENGINE_CVAR_HASH_SIZE - 1,
    CODUO_CVAR_SET_VALUE_BUFFER_SIZE = 4096,
    CODUO_CVAR_SET_VALUE_LIMIT = 4093,
    CODUO_CVAR_WRITE_BUFFER_SIZE = 1024,
    CODUO_CVAR_DUMP_BUFFER_SIZE = 8192,
    CODUO_CVAR_SET_VALUE_FORMAT_SIZE = 32,
    CODUO_CVAR_PRINT_CHANNEL_DEVELOPER = 4
};

extern coduo_engine_cvar_table_t cvar_vars;
extern coduo_engine_cvar_hash_table_t cvar_hashTable;
extern cvar_t *cvar_sortedHead;
extern int32_t cvar_numIndexes;
extern int32_t cvar_modifiedFlags;
extern coduo_cvar_info_string_buffer_t cvar_infoStringBuffer;
extern coduo_cvar_big_info_string_buffer_t cvar_bigInfoStringBuffer;

extern cvar_t *sv_cheats;
extern cvar_t *sv_console_lockout;
extern cvar_t *sv_running;
extern cvar_t *logfile;

void Com_Error(int32_t code, const char *format, ...);
void Com_Printf(const char *format, ...);
void Com_DPrintf(const char *format, ...);
void Com_PrintMessage(int32_t channel,
                      const char *message);
char *CopyString(const char *text);
void Z_Free(void *ptr);
char *va(const char *format, ...);
qboolean Com_Filter(const char *filter, const char *name,
                    qboolean caseSensitive);
void Q_strncpyz(char *dest, const char *src, int destsize);
int32_t Cmd_Argc(void);
const char *Cmd_Argv(uint32_t arg);
void Cmd_AddCommand(const char *name, coduo_cmd_function_fn handler);
void FS_Printf(int32_t handle, const char *format, ...);
void SV_SetConfigValueForKey(int32_t base,
                             int32_t count,
                             const char *key, const char *value);
cvar_t *Cvar_Get(const char *name, const char *value,
                              uint32_t flags);
cvar_t *Cvar_Set2(const char *name, const char *value,
                               qboolean force);
cvar_t *Cvar_Set(const char *name, const char *value);
void Cvar_SetExisting(const char *name, const char *value);
void Cvar_SetValue(const char *name, float value);
const char *Cvar_VariableString(const char *name);
float Cvar_VariableValue(const char *name);
const char *Cvar_InfoString(uint32_t flags);
const char *Cvar_InfoString_Big(uint32_t flags);
void Cvar_SetConfigstringValues(int32_t base,
                                int32_t count,
                                uint32_t flags);
void Cvar_Update(vmCvar_t *vmCvar);
void Cvar_ClearScriptSetServerinfoFlags(void);
void Cvar_ResetScriptInfo(void);
void Cvar_AddCommands(void);
void Cvar_DumpToChannel(int32_t channel);
void Cvar_WriteVariables(int32_t handle);
void Cvar_WriteDefaults(int32_t handle);
void Cvar_CommandCompletion(void (*callback)(const char *name));
void Cvar_SetCheatState(void);

#endif
