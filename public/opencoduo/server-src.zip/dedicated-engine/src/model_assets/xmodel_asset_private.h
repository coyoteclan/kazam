#ifndef CODUO_XMODEL_ASSET_PRIVATE_H
#define CODUO_XMODEL_ASSET_PRIVATE_H

#include "coduo_engine_structs.h"

typedef void *(*xmodel_asset_alloc_fn)(size_t size);

extern uint8_t *weaponInfo_memory;
extern int32_t weaponInfo_memoryState;
extern float xmodel_testLodDist;
extern coduo_xmodel_test_lod_distance_table_t xmodel_testLodDistances;
extern uint8_t xmodel_testLodsEnabled;

void XModelSetOptimize(qboolean enabled);
int32_t XModelLittleInt16(int16_t value);
void *Hunk_AllocXModelPrecache(size_t size);
void FreeWeaponInfoMemory(int32_t callerState,
                          qboolean keepMemory);
XModel *XModelPrecache(const char *name, qboolean loadSurfaces,
                                     xmodel_asset_alloc_fn alloc,
                                     xmodel_asset_alloc_fn optionalAlloc);
qboolean XModelBad(const XModel *model);
int32_t XModelNumBones(const XModel *model);
const uint16_t *XModelBoneNames(const XModel *model);
int32_t XModelGetBoneIndex(const XModel *model, uint16_t name);
void XModelGetBounds(const XModel *model, vec3_t mins, vec3_t maxs);
void XModelGetBasePose(XModel *model,
                       DObjSkelMat *basePose);
qboolean XModelGetStaticBounds(XModel *model,
                               vec3_t transform[3],
                               vec3_t mins,
                               vec3_t maxs);
int32_t XModelGetContents(XModel *model);
int32_t XModelGetLodForDist(
    const XModel *model, float distance);
int32_t XModelGetSurfaces(
    const XModel *model, XSurface ***surfacesOut,
    int32_t lodIndex);
const char *XModelGetSurfaceName(const XModel *model,
                                 int32_t surfaceIndex,
                                 int32_t lodIndex);
int32_t
XModelTraceLine(XModel *model,
                trace_t *trace,
                const DObjSkelMat *basePose,
                const vec3_t start,
                const vec3_t end,
                int32_t contentMask);

#endif
