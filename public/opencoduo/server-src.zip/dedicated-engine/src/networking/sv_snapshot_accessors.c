#include "sv_snapshot_private.h"

void SV_AddEntToSnapshot(
    int32_t entityNum,
    snapshotEntityNumbers_t *entityNumbers)
{
    if (entityNumbers->count != CODUO_SNAPSHOT_ENTITY_NUMBER_LIST_COUNT) {
        entityNumbers->numbers[entityNumbers->count] = entityNum;
        ++entityNumbers->count;
    }
}

int32_t SV_GetClientArchiveTime(
    int32_t clientNum)
{
    return VM_Call(sv_gameVM, CODUO_GAME_GET_CLIENT_ARCHIVE_TIME, clientNum);
}

const coduo_host_client_snapshot_t *SV_GetClientState(
    int32_t clientNum)
{
    return (const coduo_host_client_snapshot_t *)
        VM_Call(sv_gameVM, CODUO_GAME_GET_CLIENT_SESSION, clientNum);
}

qboolean SV_GetFollowPlayerState(
    int32_t clientNum,
    playerState_t *playerStateOut)
{
    return VM_Call(sv_gameVM, CODUO_GAME_GET_FOLLOW_PLAYER_STATE, clientNum,
                   playerStateOut);
}

qboolean SV_GetCurrentClientInfo(
    int32_t clientNum,
    playerState_t *playerStateOut,
    coduo_archived_client_info_meta_t *clientSnapshotOut)
{
    const client_t *clients = svs.clients;
    const client_t *client = &clients[clientNum];
    qboolean result = 0;

    if (client->state == CODUO_CS_ACTIVE) {
        if (SV_GetFollowPlayerState(clientNum, playerStateOut) != 0) {
            *clientSnapshotOut = *SV_GetClientState(clientNum);
            result = 1;
        }
    }

    return result;
}

void SV_SetClientArchiveTime(
    int32_t clientNum,
    int32_t archiveTime)
{
    VM_Call(sv_gameVM, CODUO_GAME_SET_CLIENT_ARCHIVE_TIME, clientNum,
            archiveTime);
}

void SV_AddArchivedEntToSnapshot(
    int32_t entityNum,
    snapshotEntityNumbers_t *entityNumbers)
{
    if (entityNumbers->count != CODUO_SNAPSHOT_ENTITY_NUMBER_LIST_COUNT) {
        entityNumbers->numbers[entityNumbers->count] = entityNum;
        ++entityNumbers->count;
    }
}
