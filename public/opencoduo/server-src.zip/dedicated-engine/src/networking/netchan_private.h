#ifndef CODUO_NETCHAN_PRIVATE_H
#define CODUO_NETCHAN_PRIVATE_H

#include "coduo_engine_structs.h"

extern cvar_t *net_profile;
extern cvar_t *net_lanauthorize;
extern cvar_t *net_qport;
extern cvar_t *net_showprofile;
extern cvar_t *showdrop;
extern cvar_t *showpackets;
extern loopback_table_t net_loopbacks;
extern coduo_net_profile_mode_t net_profileActiveMode;
extern netProfileInfo_t *svs_oobNetProfile;
extern const char *net_profileSocketNames[CODUO_NET_PROFILE_SOCKET_NAME_COUNT];

void NetProf_PrepProfiling(netProfileInfo_t **profile);
void NetProf_AddPacket(netProfileStream_t *stream,
                       int32_t bytes,
                       qboolean fragmented);
void NetProf_NewSendPacket(netchan_t *chan,
                           int32_t bytes,
                           qboolean fragmented);
void NetProf_NewRecievePacket(netchan_t *chan,
                              int32_t bytes,
                              qboolean fragmented);
void NetProf_UpdateStatistics(netProfileStream_t *stream);

void Netchan_Init(int32_t qport);
void Netchan_Setup(netsrc_t sock, netchan_t *chan,
                   netadr_t adr, int32_t qport);
qboolean Netchan_Process(netchan_t *chan, msg_t *msg);
void Netchan_TransmitNextFragment(netchan_t *chan);
void Netchan_Transmit(netchan_t *chan,
                      int32_t length,
                      const void *data);
void SV_Netchan_Decode(client_t *client, uint8_t *data,
                       int32_t length);
void SV_Netchan_TransmitNextFragment(netchan_t *chan);
void SV_Netchan_Transmit(client_t *client, uint8_t *data,
                         int32_t length);
void SV_Netchan_AddOOBProfilePacket(int32_t length);
void SV_Netchan_PrintProfileStats(qboolean printHeader);
const char *NET_AdrToString(netadr_t adr);
int32_t NET_CompareBaseAdrSigned(const netadr_t *a,
                                 const netadr_t *b);
int32_t NET_CompareAdrSigned(const netadr_t *a, const netadr_t *b);
void NET_SendLoopPacket(netsrc_t sock,
                        int32_t length, const void *data);
void NET_SendPacket(netsrc_t sock,
                    int32_t length,
                    const void *data, netadr_t to);
qboolean NET_CompareBaseAdr(netadr_t a, netadr_t b);
qboolean NET_CompareAdr(netadr_t a, netadr_t b);
qboolean NET_IsLocalAddress(netadr_t adr);
void NET_OutOfBandPrint(netsrc_t sock, netadr_t adr,
                        const char *format, ...);
void NET_OutOfBandData(netsrc_t sock, netadr_t adr,
                       const void *data,
                       int32_t length);
void NET_OutOfBandPbPacket(netsrc_t sock, netadr_t adr,
                           const void *data,
                           int32_t length);
qboolean NET_StringToAdr(const char *text, netadr_t *adr);
qboolean NET_GetLoopPacket(netsrc_t sock, netadr_t *from,
                           msg_t *msg);

#endif
