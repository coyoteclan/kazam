#ifndef CODUO_SV_SNAPSHOT_PRIVATE_H
#define CODUO_SV_SNAPSHOT_PRIVATE_H

#include "coduo_engine_structs.h"

extern coduo_host_svs_header_t svs;
extern coduo_host_sv_prefix_t sv;
extern coduo_host_entity_link_table_t sv_entityLinks;
extern coduo_host_game_data_globals_t sv_gameData;
extern cvar_t *sv_fps;
extern cvar_t *sv_maxclients;
extern cvar_t *sv_maxRate;
extern cvar_t *sv_padPackets;
extern coduo_vm_t *sv_gameVM;

intptr_t VM_Call(coduo_vm_t *vm,
                               int32_t command, ...);

void SV_AddEntToSnapshot(
    int32_t entityNum,
    snapshotEntityNumbers_t *entityNumbers);
void SV_AddArchivedEntToSnapshot(
    int32_t entityNum,
    snapshotEntityNumbers_t *entityNumbers);
int32_t SV_GetClientArchiveTime(
    int32_t clientNum);
const coduo_host_client_snapshot_t *SV_GetClientState(
    int32_t clientNum);
qboolean SV_GetFollowPlayerState(int32_t clientNum,
                                 playerState_t *playerStateOut);
void SV_SetClientArchiveTime(int32_t clientNum,
                             int32_t archiveTime);
qboolean
SV_GetCurrentClientInfo(
    int32_t clientNum,
    playerState_t *playerStateOut,
    coduo_archived_client_info_meta_t *clientSnapshotOut);
int32_t
SV_RateMsec(client_t *client,
            int32_t messageSize);
void SV_ArchiveSnapshot(void);
void SV_SendClientMessages(void);
void SV_SendClientSnapshot(client_t *client);
void SV_SendMessageToClient(msg_t *msg, client_t *client);
void SV_PrintServerCommandsForClient(client_t *client);
void SV_BuildClientSnapshot(client_t *client);
void SV_UpdateServerCommandsToClient(client_t *client,
                                     msg_t *msg);
void SV_UpdateServerCommandsToClient_PreventOverflow(
    client_t *client,
    msg_t *msg,
    int32_t maxBytes);
void SV_WriteSnapshotToClient(client_t *client, msg_t *msg);

#endif
