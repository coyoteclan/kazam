#include "fs_private.h"

qboolean FS_PakIsPure(const pack_t *pack)
{
    int32_t index;

    if (fs_numServerPaks == 0) {
        return 1;
    }

    for (index = 0; index < fs_numServerPaks; index++) {
        if (pack->checksum == fs_serverPaks[index]) {
            return 1;
        }
    }

    return 0;
}
