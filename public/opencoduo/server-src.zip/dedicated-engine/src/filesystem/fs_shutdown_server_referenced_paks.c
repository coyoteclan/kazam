#include "fs_private.h"

void FS_ShutdownServerReferencedPaks(void)
{
    int index;

    for (index = 0; index < fs_numServerReferencedPaks; index++) {
        if (fs_serverReferencedPakNames[index] != NULL) {
            Z_Free(fs_serverReferencedPakNames[index]);
        }

        fs_serverReferencedPakNames[index] = NULL;
    }

    fs_numServerReferencedPaks = 0;
}
