#include "fs_private.h"

void FS_AddNonPackFileDirectory(const char *path, const char *extension)
{
    searchpath_t *searchpath;
    directory_t *directory;

    for (searchpath = FS_SearchpathHead(); searchpath != NULL;
         searchpath = FS_SearchpathNext(searchpath)) {
        if (searchpath->pack == NULL) {
            directory = searchpath->dir;
            FS_AddNonPackFileDirectory_Internal(directory->path, directory->gamedir, path, extension);
        }
    }
}
