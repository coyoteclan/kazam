#include "fs_private.h"

void *FS_FileForHandle(int32_t handle)
{
    return fs_handleFiles[handle].ioObject;
}
