#include "fs_private.h"

void FS_FullPath_f(void)
{
    FS_DisplayPath(qfalse);
}
