#include <stdarg.h>
#include <string.h>

#include "fs_private.h"

void FS_Printf(int32_t handle, const char *format, ...)
{
    char text[4096];
    va_list argptr;

    va_start(argptr, format);
    /* ORIGINAL_BINARY_BUG: stock formats without a bound into this fixed
     * stack array; see original-bugs/coduomp-fs-printf-stack-overflow.md. */
    vsprintf(text, format, argptr);
    va_end(argptr);

    FS_Write(text, (int32_t)strlen(text), handle);
}
