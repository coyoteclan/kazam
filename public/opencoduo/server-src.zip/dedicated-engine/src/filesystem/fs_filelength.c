#include "fs_private.h"

long FS_filelength(int32_t handle)
{
    FILE *file;
    coduo_fs_zip_io_file_t *zipFile;
    long currentOffset;
    long length;

    FS_CheckFileSystemStarted();

    if (fs_handleFiles[handle].zipArchive == NULL) {
        file = FS_LoadIOFile(FS_FileForHandle(handle));
        currentOffset = ftell(file);
        fseek(file, 0, SEEK_END);
        length = (long)ftell(file);
        fseek(file, currentOffset, SEEK_SET);
    } else {
        zipFile = FS_LoadZipIOFile(fs_handleFiles[handle].ioObject);
        length = (long)
            zipFile->cur_file_info.uncompressed_size;
    }

    return length;
}
