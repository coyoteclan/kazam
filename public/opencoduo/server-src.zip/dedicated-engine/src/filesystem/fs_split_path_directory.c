#include <string.h>

#include "fs_private.h"

int FS_SplitPathDirectory(const char *path, char *directory,
                          int *separatorCount)
{
    int count = 0;
    int lastSeparator = 0;
    int index = 0;

    *directory = '\0';

    while (path[index] != '\0') {
        if (path[index] == '/' || path[index] == '\\') {
            lastSeparator = index;
            count++;
        }
        index++;
    }

    /* ORIGINAL_BINARY_BUG: stock copies an unrestricted caller or pak path
     * into a fixed caller stack array; see
     * original-bugs/coduomp-file-list-path-stack-overflow.md. */
    strcpy(directory, path);
    directory[lastSeparator] = '\0';

    /* ORIGINAL_BINARY_BUG: for a one-character separator-free path,
     * lastSeparator + 1 equals its length and decrements zero to -1; see
     * original-bugs/coduomp-returnpath-one-character-depth.md. */
    if (lastSeparator + 1 == index) {
        count--;
    }

    *separatorCount = count;
    return lastSeparator;
}
