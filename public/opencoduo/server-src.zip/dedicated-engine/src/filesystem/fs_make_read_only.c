#include <stdint.h>
#include <sys/stat.h>

#include "fs_private.h"

qboolean FS_MakeReadOnly(const char *qpath, int clearOwnerRead)
{
    struct stat fileStat;
    mode_t mode;
    char osPath[FS_OSPATH_SIZE];

    FS_CheckFileSystemStarted();
    FS_BuildOSPath(fs_homepath->string,
                   fs_currentGameDir, qpath, osPath);

    if (Sys_Stat(osPath, &fileStat) == -1) {
        return 0;
    }

    if (clearOwnerRead == 0) {
        mode = fileStat.st_mode | S_IRUSR;
    } else {
        mode = fileStat.st_mode & ~S_IRUSR;
    }

    fileStat.st_mode = mode;
    if (chmod(osPath, fileStat.st_mode) == -1) {
        return 0;
    }

    return 1;
}
