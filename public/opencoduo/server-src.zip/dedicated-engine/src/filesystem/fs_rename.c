#include "fs_private.h"

void FS_Rename(const char *from, const char *to)
{
    char destOSPath[256];
    char sourceOSPath[256];

    FS_CheckFileSystemStarted();
    /* ORIGINAL_BINARY_BUG: the game-VM rename path accepts parent components
     * before host rename/remove/copy operations; see
     * original-bugs/coduomp-game-syscall-rename-path-traversal.md. */
    FS_BuildOSPath(fs_homepath->string,
                   fs_currentGameDir, from, sourceOSPath);
    FS_BuildOSPath(fs_homepath->string,
                   fs_currentGameDir, to, destOSPath);

    if (fs_debug->integer != 0) {
        Com_Printf("FS_Rename: %s --> %s\n", sourceOSPath, destOSPath);
    }

    if (rename(sourceOSPath, destOSPath) != 0) {
        FS_Remove(destOSPath);
        if (rename(sourceOSPath, destOSPath) != 0) {
            FS_Copyfiles(sourceOSPath, destOSPath);
            FS_Remove(sourceOSPath);
        }
    }
}
