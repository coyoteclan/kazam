#include <stdint.h>

#include "fs_private.h"

void FS_ShutdownFileLists(fs_dir_file_list_t *list)
{
    fs_dir_file_list_t *next;

    while (list != NULL) {
        next = FS_DirFileListNext(list);
        Z_Free(list->fileList);
        Z_Free(list);
        list = next;
    }
}
