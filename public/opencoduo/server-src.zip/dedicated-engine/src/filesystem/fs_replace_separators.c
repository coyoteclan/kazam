#include "fs_private.h"

void FS_ReplaceSeparators(char *path)
{
    while (*path != '\0') {
        if (*path == '\\' || *path == ':') {
            *path = '/';
        }
        path++;
    }
}
