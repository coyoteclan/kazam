#include "fs_private.h"

void FS_Path_f(void)
{
    FS_DisplayPath(qfalse);
}
