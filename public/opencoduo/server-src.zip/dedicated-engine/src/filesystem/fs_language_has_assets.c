#include "fs_private.h"

qboolean FS_LanguageHasAssets(int32_t language)
{
    searchpath_t *search;

    search = fs_searchpaths;
    while (search != NULL) {
        if (search->localized != 0 && search->language == language) {
            return 1;
        }
        search = search->next;
    }

    return 0;
}
