#include "fs_private.h"

void FS_BuildOSPath(const char *base, const char *game, const char *qpath,
                    char *ospath)
{
    FS_BuildOSPath_Internal(base, game, qpath, ospath, 0);
}
