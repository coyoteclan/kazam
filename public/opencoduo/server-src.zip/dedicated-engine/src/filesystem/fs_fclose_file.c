#include <stdint.h>

#include "fs_private.h"

void FS_FCloseFile(int32_t handle)
{
    FS_CheckFileSystemStarted();

    if (fs_handleFiles[handle].seekCallbackGuard != 0) {
        Sys_EndStreamedFile(handle);
    }

    if (fs_handleFiles[handle].zipArchive != NULL) {
        /* ORIGINAL_BINARY_BUG: the engine discards the ZIP reader's only
         * CRC-mismatch result; see
         * original-bugs/engine-zip-crc-error-discarded.md. */
        Unzip_CloseCurrentFile(
            (struct coduo_unz_s *)fs_handleFiles[handle].ioObject);

        if (fs_handleFiles[handle].uniqueObject != 0) {
            Unzip_Close((struct coduo_unz_s *)fs_handleFiles[handle].ioObject);
        }

        Com_Memset(&fs_handleFiles[handle], 0, sizeof(fs_handleFiles[handle]));
    } else {
        if (fs_handleFiles[handle].ioObject != NULL) {
            fclose(FS_LoadIOFile(fs_handleFiles[handle].ioObject));
        }

        Com_Memset(&fs_handleFiles[handle], 0, sizeof(fs_handleFiles[handle]));
    }
}
