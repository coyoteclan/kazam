#include "fs_private.h"

qboolean FS_Delete(char *qpath)
{
    qboolean result;
    char osPath[FS_OSPATH_SIZE];

    FS_CheckFileSystemStarted();
    if (qpath == NULL || *qpath == '\0') {
        result = 0;
    } else if (Q_strncmp(qpath, "save", 4) == 0 &&
               (qpath[4] == '/' || qpath[4] == '\\')) {
        /* ORIGINAL_BINARY_BUG: the save prefix does not reject following
         * parent components; see
         * original-bugs/coduomp-ui-delete-path-traversal.md. */
        FS_BuildOSPath(fs_homepath->string,
                       fs_currentGameDir, qpath, osPath);
        if (remove(osPath) != -1) {
            result = 1;
        } else {
            result = 0;
        }
    } else {
        result = 0;
    }

    return result;
}
