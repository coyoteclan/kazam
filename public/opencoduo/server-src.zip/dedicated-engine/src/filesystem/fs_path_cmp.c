#include "fs_private.h"

int32_t FS_PathCmp(const char *leftPath, const char *rightPath)
{
    int32_t left;
    int32_t right;

    while (1) {
        left = (int32_t)(int8_t)(uint8_t)*leftPath;
        leftPath++;
        right = (int32_t)(int8_t)(uint8_t)*rightPath;
        rightPath++;

        if (Q_islower(left) != 0) {
            left -= 'a' - 'A';
        }
        if (Q_islower(right) != 0) {
            right -= 'a' - 'A';
        }

        if (left == '\\' || left == ':') {
            left = '/';
        }
        if (right == '\\' || right == ':') {
            right = '/';
        }

        if (left < right) {
            return -1;
        }
        if (right < left) {
            return 1;
        }
        if (left == '\0') {
            return 0;
        }
    }
}
