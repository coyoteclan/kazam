#include "fs_private.h"

void FS_Restart(int checksumFeed)
{
    FS_Shutdown(qfalse);
    fs_checksumFeed = checksumFeed;
    FS_ClearPakReferences(qfalse);
    FS_Startup("main");
    FS_CheckRestrictedDemoPaks();

    if (FS_ReadFile("default_mp.cfg", NULL) < 1) {
        if (fs_savedBasepath[0] != '\0') {
            FS_PureServerSetLoadedPaks("", "");
            Cvar_Set("fs_basepath", fs_savedBasepath);
            Cvar_Set("fs_gamedirvar", fs_savedGame);
            fs_savedBasepath[0] = '\0';
            fs_savedGame[0] = '\0';
            Cvar_Set("fs_restrict", "0");
            FS_Restart(checksumFeed);
            Com_Error(1, "Invalid game folder\n");
        }
        Com_Error(0,
                  "Couldn't load %s.  Make sure Call of Duty is run from the "
                  "correct folder.",
                  "default_mp.cfg");
    }

    if (Q_stricmp(fs_game->string, fs_savedGame) != 0) {
        if (Com_SafeMode() == 0) {
            Cbuf_AddText(va("exec %s\n", "uoconfig_mp_server.cfg"));
        }
    }

    Q_strncpyz(fs_savedBasepath, fs_basepath->string, sizeof(fs_savedBasepath));
    Q_strncpyz(fs_savedGame, fs_game->string, sizeof(fs_savedGame));
}
