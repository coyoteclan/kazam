#include "fs_private.h"

void FS_FreeFile(void *buffer)
{
    FS_CheckFileSystemStarted();

    if (buffer == NULL) {
        Com_Error(0, "\x15" "FS_FreeFile( NULL )");
    }

    fs_loadCount--;
    Hunk_FreeTempMemory(buffer);
}
