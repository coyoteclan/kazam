#include "fs_private.h"

void FS_Shutdown(qboolean clearLookupLists)
{
    int32_t handle;

    for (handle = 1; handle < CODUO_FS_HANDLE_TABLE_COUNT; handle++) {
        /* ORIGINAL_BINARY_BUG: stock tests cached size rather than the live
         * FILE/ZIP lane, skipping zero-size open handles; see
         * original-bugs/coduomp-fs-shutdown-zero-size-handle-leak.md. */
        if (fs_handleFiles[handle].size != 0) {
            FS_FCloseFile(handle);
        }
    }

    if (clearLookupLists != 0) {
        FS_ShutdownSearchPaths(fs_searchpaths);
        FS_ShutdownFileLists(fs_dir_file_lists);
        fs_lookup_searchpaths = NULL;
        fs_lookup_dir_file_lists = NULL;
    } else {
        if (fs_lookup_searchpaths != fs_searchpaths) {
            FS_ShutdownSearchPaths(fs_searchpaths);
        }
        if (fs_lookup_dir_file_lists != fs_dir_file_lists) {
            FS_ShutdownFileLists(fs_dir_file_lists);
        }
    }

    fs_searchpaths = NULL;
    fs_dir_file_lists = NULL;

    Cmd_RemoveCommand("path");
    Cmd_RemoveCommand("fullpath");
    Cmd_RemoveCommand("dir");
    Cmd_RemoveCommand("fdir");
    Cmd_RemoveCommand("touchFile");
}
