#include <ctype.h>
#include <stdint.h>
#include <string.h>

#include "coduo_ctype_compat.h"
#include "fs_private.h"

enum {
    FS_LANGUAGE_NAME_PREFIX_LENGTH = 10,
};

char *PakFileLanguage(char *text)
{
    char *buffer;
    int index;

    fs_languageNameBufferIndex ^= 1;
    buffer = fs_languageNameBuffers[fs_languageNameBufferIndex];

    if (strlen(text) < FS_LANGUAGE_NAME_PREFIX_LENGTH) {
        buffer[0] = '\0';
    } else {
        index = FS_LANGUAGE_NAME_PREFIX_LENGTH;
        memset(buffer, 0, sizeof(fs_languageNameBuffers[0]));
        while (index < (int)sizeof(fs_languageNameBuffers[0]) &&
               text[index] != '\0' &&
               isalpha(coduo_ctype_signed_byte_arg(text[index])) != 0) {
            buffer[index - FS_LANGUAGE_NAME_PREFIX_LENGTH] = text[index];
            index++;
        }
    }

    return buffer;
}
