#include <stdint.h>

#include "fs_private.h"

enum {
    FS_SHARED_HANDLE_FIRST = 1,
    FS_SHARED_HANDLE_COUNT = 50,
    FS_UNIQUE_HANDLE_FIRST = 51,
    FS_UNIQUE_HANDLE_COUNT = 13,
};

int32_t FS_HandleForFile(qboolean uniqueFile)
{
    int32_t firstHandle;
    int32_t handleCount;
    int32_t index;

    if (uniqueFile == 0) {
        firstHandle = FS_SHARED_HANDLE_FIRST;
        handleCount = FS_SHARED_HANDLE_COUNT;
    } else {
        firstHandle = FS_UNIQUE_HANDLE_FIRST;
        handleCount = FS_UNIQUE_HANDLE_COUNT;
    }

    for (index = 0; index < handleCount; index++) {
        if (fs_handleFiles[firstHandle + index].ioObject == NULL) {
            return firstHandle + index;
        }
    }

    for (index = FS_SHARED_HANDLE_FIRST;
         index < CODUO_FS_HANDLE_TABLE_COUNT; index++) {
        Com_Printf("FILE %2i: '%s'\n", index, fs_handleFiles[index].name);
    }

    Com_Error(1, "\x15" "FS_HandleForFile: none free");
    return -1;
}
