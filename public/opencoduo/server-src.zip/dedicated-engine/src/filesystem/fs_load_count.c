#include "fs_private.h"

int FS_LoadCount(void)
{
    return fs_loadCount;
}
