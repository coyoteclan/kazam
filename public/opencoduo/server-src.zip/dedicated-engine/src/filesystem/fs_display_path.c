#include "fs_private.h"

void FS_DisplayPath(qboolean localizedFilter)
{
    const searchpath_t *searchpath;
    const pack_t *pack;
    const directory_t *dir;
    int handle;

    if (fs_ignoreLozalized->integer != 0) {
        Com_Printf("    localized assets are being ignored\n");
    }

    Com_Printf("Current search path:\n");
    for (searchpath = FS_SearchpathHead(); searchpath != NULL;
         searchpath = FS_SearchpathNext(searchpath)) {
        if (localizedFilter == 0 || FS_UseSearchPath(searchpath) != 0) {
            if (searchpath->pack != NULL) {
                pack = searchpath->pack;
                Com_Printf("%s (%i files)\n", pack->pakFilename, pack->numFiles);
                if (fs_numServerPaks != 0) {
                    if (FS_PakIsPure(pack) == 0) {
                        Com_Printf("    not on the pure list\n");
                    } else {
                        Com_Printf("    on the pure list\n");
                    }
                }
            } else {
                dir = searchpath->dir;
                Com_Printf("%s/%s\n", dir->path, dir->gamedir);
            }
        }
    }

    Com_Printf("\nFile Handles:\n");
    for (handle = 1; handle < CODUO_FS_HANDLE_TABLE_COUNT; handle++) {
        if (fs_handleFiles[handle].ioObject != NULL) {
            Com_Printf("handle %i: %s\n", handle, fs_handleFiles[handle].name);
        }
    }
}
