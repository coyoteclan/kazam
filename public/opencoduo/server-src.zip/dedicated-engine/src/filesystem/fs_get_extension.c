#include "fs_private.h"

char *FS_GetExtension(char *path)
{
    char *extension;

    extension = "";
    while (*path != '\0') {
        if (*path == '.') {
            extension = path + 1;
        } else if (*path == '/' || *path == '\\') {
            extension = "";
        }
        path++;
    }

    return extension;
}
