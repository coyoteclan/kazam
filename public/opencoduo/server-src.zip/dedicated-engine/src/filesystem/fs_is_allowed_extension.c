#include <strings.h>

#include "fs_private.h"

int FS_IsAllowedExtension(char *extension)
{
    if (*extension == '.') {
        extension++;
    }

    if (strcasecmp(extension, "cfg") == 0) {
        return 1;
    }
    if (Q_stricmp(extension, "menu") == 0) {
        return 1;
    }
    if (Q_stricmp(extension, ".dm_NETWORK_PROTOCOL_VERSION") == 0) {
        return 1;
    }
    if (Q_stricmp(extension, "dat") == 0) {
        return 1;
    }

    return 0;
}
