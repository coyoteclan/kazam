#include "fs_private.h"

void FS_ShutdownServerPakNames(void)
{
    int index;

    for (index = 0; index < fs_numServerPaks; index++) {
        if (fs_serverPakNames[index] != NULL) {
            Z_Free(fs_serverPakNames[index]);
        }

        fs_serverPakNames[index] = NULL;
    }

    fs_numServerPaks = 0;
}
