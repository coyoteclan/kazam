#include "fs_private.h"

void FS_Startup(const char *gameName)
{
    const char *homePath;

    Com_Printf("----- FS_Startup -----\n");
    fs_packFiles = 0;

    fs_debug = Cvar_Get("fs_debug", "0", 0);
    fs_copyfiles = Cvar_Get("fs_copyfiles", "0", CODUO_CVAR_INIT);
    fs_cdpath = Cvar_Get("fs_cdpath", Sys_DefaultCDPath(), CODUO_CVAR_INIT);
    fs_basepath = Cvar_Get("fs_basepath", Sys_DefaultInstallPath(), CODUO_CVAR_INIT);
    fs_basegame = Cvar_Get("fs_basegame", "uo", CODUO_CVAR_INIT);

    homePath = Sys_DefaultHomePath();
    if (homePath == NULL || *homePath == '\0') {
        homePath = fs_basepath->string;
    }
    fs_homepath = Cvar_Get("fs_homepath", homePath, CODUO_CVAR_INIT);

    fs_game = Cvar_Get("fs_game", "", CODUO_CVAR_INIT | CODUO_CVAR_SYSTEMINFO);
    fs_restrict = Cvar_Get("fs_restrict", "", CODUO_CVAR_INIT);
    fs_ignoreLozalized = Cvar_Get(
        "fs_ignoreLozalized", "0", CODUO_CVAR_LATCH | CODUO_CVAR_CHEAT);

    if (*fs_cdpath->string != '\0') {
        FS_AddLocalizedGameDirectory(fs_cdpath->string, gameName);
    }
    if (*fs_basepath->string != '\0') {
        FS_AddLocalizedGameDirectory(fs_basepath->string, gameName);
    }
    /* ORIGINAL_BINARY_BUG: stock gates this home-path scan on fs_basepath
     * rather than fs_homepath; see
     * original-bugs/coduomp-fs-startup-homepath-basepath-gate.md. */
    if (*fs_basepath->string != '\0') {
        if (Q_stricmp(fs_homepath->string, fs_basepath->string) != 0) {
            FS_AddLocalizedGameDirectory(fs_homepath->string, gameName);
        }
    }

    if (*fs_basegame->string != '\0') {
        if (Q_stricmp(gameName, "main") == 0) {
            if (Q_stricmp(fs_basegame->string, gameName) != 0) {
                if (*fs_cdpath->string != '\0') {
                    FS_AddLocalizedGameDirectory(fs_cdpath->string, fs_basegame->string);
                }
                if (*fs_basepath->string != '\0') {
                    FS_AddLocalizedGameDirectory(fs_basepath->string, fs_basegame->string);
                }
                if (*fs_homepath->string != '\0') {
                    if (Q_stricmp(fs_homepath->string,
                                     fs_basepath->string) != 0) {
                        FS_AddLocalizedGameDirectory(fs_homepath->string,
                                     fs_basegame->string);
                    }
                }
            }
        }
    }

    if (*fs_game->string != '\0') {
        if (Q_stricmp(gameName, "main") == 0) {
            if (Q_stricmp(fs_game->string, gameName) != 0) {
                if (*fs_cdpath->string != '\0') {
                    FS_AddLocalizedGameDirectory(fs_cdpath->string, fs_game->string);
                }
                if (*fs_basepath->string != '\0') {
                    FS_AddLocalizedGameDirectory(fs_basepath->string, fs_game->string);
                }
                if (*fs_homepath->string != '\0') {
                    if (Q_stricmp(fs_homepath->string,
                                     fs_basepath->string) != 0) {
                        FS_AddLocalizedGameDirectory(fs_homepath->string, fs_game->string);
                    }
                }
            }
        }
    }

    FS_AddNonPackFileDirectory("xanim", "");
    FS_AddNonPackFileDirectory("xmodel", "");
    FS_AddNonPackFileDirectory("xmodelparts", "");
    FS_AddNonPackFileDirectory("xmodelsurfs", "");
    FS_AddNonPackFileDirectory("weapons", "");
    FS_AddNonPackFileDirectory("animtrees", ".atr");

    Com_ReadCDKey();
    FS_AddCommands();
    FS_Path_f();

    fs_game->modified = 0;

    Com_Printf("----------------------\n");
    Com_Printf("%d files in pk3 files\n", fs_packFiles);
}
