#include <string.h>

#include "fs_private.h"

void FS_InitFilesystem(void)
{
    Com_StartupVariable("fs_cdpath");
    Com_StartupVariable("fs_basepath");
    Com_StartupVariable("fs_homepath");
    Com_StartupVariable("fs_game");
    Com_StartupVariable("fs_copyfiles");
    Com_StartupVariable("fs_restrict");
    Com_StartupVariable("fs_usewolf");
    Com_StartupVariable("cl_language");

    FS_Startup("main");
    FS_CheckRestrictedDemoPaks();

    if (FS_ReadFile("default_mp.cfg", NULL) < 1) {
        Com_Error(0,
                  "Couldn't load %s.  Make sure Call of Duty is run from the "
                  "correct folder.",
                  "default_mp.cfg");
    }

    Q_strncpyz(fs_savedBasepath, fs_basepath->string, sizeof(fs_savedBasepath));
    Q_strncpyz(fs_savedGame, fs_game->string, sizeof(fs_savedGame));
    memset(fs_startupScratch, 0, sizeof(fs_startupScratch));
}
