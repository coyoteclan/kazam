#include <string.h>

#include "fs_private.h"

int FS_CreatePath(char *path)
{
    char *scan;

    if (strstr(path, "..") != NULL || strstr(path, "::") != NULL) {
        Com_Printf("WARNING: refusing to create relative path \"%s\"\n", path);
        return 1;
    }

    for (scan = path + 1; *scan != '\0'; scan++) {
        if (*scan == '/') {
            *scan = '\0';
            Sys_Mkdir(path);
            *scan = '/';
        }
    }

    return 0;
}
