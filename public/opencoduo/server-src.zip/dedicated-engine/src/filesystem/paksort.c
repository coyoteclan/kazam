#include <stdint.h>

#include "fs_private.h"

enum {
    FS_LOCALIZED_NAME_PREFIX_LENGTH = 10,
};

int32_t paksort(const void *leftEntry, const void *rightEntry)
{
    char *leftPath;
    char *rightPath;
    char *leftLanguage;
    char *rightLanguage;

    leftPath = *(char *const *)leftEntry;
    rightPath = *(char *const *)rightEntry;

    if (Q_strncmp(leftPath, "          ", FS_LOCALIZED_NAME_PREFIX_LENGTH) ==
            0 &&
        Q_strncmp(rightPath, "          ", FS_LOCALIZED_NAME_PREFIX_LENGTH) ==
            0) {
        leftLanguage = PakFileLanguage(leftPath);
        rightLanguage = PakFileLanguage(rightPath);

        if (Q_stricmp(leftLanguage, "english") == 0) {
            if (Q_stricmp(rightLanguage, "english") != 0) {
                return -1;
            }
        } else {
            if (Q_stricmp(rightLanguage, "english") == 0) {
                return 1;
            }
        }
    }

    return FS_PathCmp(leftPath, rightPath);
}
