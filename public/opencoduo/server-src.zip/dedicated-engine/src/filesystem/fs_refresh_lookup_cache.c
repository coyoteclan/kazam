#include "fs_private.h"

void FS_RefreshLookupCache(void)
{
    if (fs_lookup_searchpaths != fs_searchpaths) {
        FS_ShutdownSearchPaths(fs_lookup_searchpaths);
        fs_lookup_searchpaths = fs_searchpaths;
    }

    if (fs_lookup_dir_file_lists != fs_dir_file_lists) {
        FS_ShutdownFileLists(fs_lookup_dir_file_lists);
        fs_lookup_dir_file_lists = fs_dir_file_lists;
    }
}
