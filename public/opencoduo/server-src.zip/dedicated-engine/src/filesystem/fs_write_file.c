#include "fs_private.h"

void FS_WriteFile(const char *qpath, const void *buffer,
                  int32_t length)
{
    int32_t handle;

    FS_CheckFileSystemStarted();

    if ((qpath == NULL) || (buffer == NULL)) {
        Com_Error(0, "\x15" "FS_WriteFile: NULL parameter");
    }

    handle = FS_FOpenFileWrite(qpath);
    if (handle == 0) {
        Com_Printf("Failed to open %s\n", qpath);
    } else {
        FS_Write(buffer, length, handle);
        FS_FCloseFile(handle);
    }
}
