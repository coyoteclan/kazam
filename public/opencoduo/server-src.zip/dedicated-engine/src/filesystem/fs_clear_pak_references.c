#include "fs_private.h"

void FS_ClearPakReferences(qboolean preserveGeneralAndGameReferences)
{
    searchpath_t *searchpath;
    pack_t *pack;

    for (searchpath = FS_SearchpathHead(); searchpath != NULL;
         searchpath = FS_SearchpathNext(searchpath)) {
        if (searchpath->pack != NULL) {
            pack = searchpath->pack;
            pack->cgameModuleReference = 0;
            pack->uiModuleReference = 0;
            if (preserveGeneralAndGameReferences == qfalse) {
                pack->generalReference = 0;
                pack->gameModuleReference = 0;
            }
        }
    }
}
