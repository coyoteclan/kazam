#include "fs_private.h"

void FS_NormalizePathSeparators(char *path)
{
    char *cursor;

    for (cursor = path; *cursor != '\0'; cursor++) {
        if (*cursor == '/' || *cursor == '\\') {
            *cursor = '/';
        }
    }
}
