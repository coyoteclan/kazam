#include "fs_private.h"

void FS_AddLocalizedGameDirectory(const char *base, const char *game)
{
    FS_AddGameDirectory(base, game, 1, 0);
    FS_AddGameDirectory(base, game, 0, 0);
}
