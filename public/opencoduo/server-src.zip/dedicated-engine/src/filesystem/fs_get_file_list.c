#include <string.h>

#include "fs_private.h"

int FS_GetFileList(const char *path, const char *extension, char *listBuffer,
                   int bufferSize)
{
    char **files;
    int numFiles;
    int listLength;
    int fileLength;
    int index;
    int result;

    files = NULL;
    *listBuffer = '\0';
    numFiles = 0;
    listLength = 0;

    if (Q_stricmp(path, "$modlist") == 0) {
        result = FS_GetModList(listBuffer, bufferSize);
    } else {
        files = FS_ListFiles(path, extension, &numFiles);
        for (index = 0; index < numFiles; index++) {
            fileLength = (int)strlen(files[index]) + 1;
            if (bufferSize <= fileLength + listLength + 1) {
                numFiles = index;
                break;
            }

            strcpy(listBuffer, files[index]);
            listBuffer += fileLength;
            listLength += fileLength;
        }

        FS_FreeFileList(files);
        result = numFiles;
    }

    return result;
}
