#include <stdint.h>

#include "fs_private.h"

void FS_ShutdownSearchPaths(searchpath_t *searchpath)
{
    searchpath_t *next;
    pack_t *pack;

    while (searchpath != NULL) {
        next = FS_SearchpathNext(searchpath);

        if (searchpath->pack != NULL) {
            pack = searchpath->pack;
            Unzip_Close(pack->zipFile);
            Z_Free(pack->fileList);
            Z_Free(pack);
        }

        if (searchpath->dir != NULL) {
            Z_Free(searchpath->dir);
        }

        Z_Free(searchpath);
        searchpath = next;
    }
}
