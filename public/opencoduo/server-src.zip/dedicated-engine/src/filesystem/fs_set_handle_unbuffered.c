#include "fs_private.h"

void FS_SetHandleUnbuffered(int32_t handle)
{
    FILE *file;

    file = FS_LoadIOFile(FS_FileForHandle(handle));
    setvbuf(file, NULL, _IONBF, 0);
}
