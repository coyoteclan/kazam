#include "fs_private.h"

enum {
    FS_UNIQUE_STRING_LIST_LIMIT = 4095,
};

int FS_AddFileToList(const char *text, char **list, int count)
{
    int index;

    if (count == FS_UNIQUE_STRING_LIST_LIMIT) {
        return count;
    }

    for (index = 0; index < count; index++) {
        if (Q_stricmp(text, list[index]) == 0) {
            return count;
        }
    }

    list[count] = CopyString(text);
    return count + 1;
}
