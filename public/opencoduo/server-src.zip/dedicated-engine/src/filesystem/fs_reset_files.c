#include "fs_private.h"

void FS_ResetFiles(void)
{
    fs_loadCount = 0;
}
