#include "fs_private.h"

#define Q_RAND_LCG_MULTIPLIER 69069u

int32_t Q_rand(int32_t *value)
{
    *value = (int32_t)((uint32_t)*value * Q_RAND_LCG_MULTIPLIER + 1u);
    return *value;
}
