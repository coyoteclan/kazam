#include "fs_private.h"

void FS_Remove(char *osPath)
{
    remove(osPath);
}
