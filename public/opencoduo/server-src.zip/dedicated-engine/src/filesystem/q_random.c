#include "fs_private.h"

long double Q_random(int32_t *value)
{
    return (long double)(uint16_t)Q_rand(value) / 65536.0f;
}
