#include <stdint.h>
#include <string.h>

#include "fs_private.h"

void FS_BuildOSPath_Internal(const char *base, const char *game, const char *qpath,
                  char *ospath, int quiet)
{
    int32_t baseLength;
    int32_t gameLength;
    int32_t qpathLength;

    if (game == NULL || game[0] == '\0') {
        game = fs_currentGameDir;
    }

    baseLength = (int32_t)strlen(base);
    gameLength = (int32_t)strlen(game);
    qpathLength = (int32_t)strlen(qpath);

    if (gameLength + baseLength + qpathLength + 2 > 255) {
        if (quiet != 0) {
            ospath[0] = '\0';
            return;
        }
        Com_Error(0, "\x15" "FS_BuildOSPath: os path length exceeded\n");
    }

    /* ORIGINAL_BINARY_BUG: stock joins qpath without rejecting absolute or
     * parent-relative components; see
     * original-bugs/coduomp-host-filesystem-unsanitized-paths.md. */
    memcpy(ospath, base, (size_t)(uint32_t)baseLength);
    ospath[baseLength] = '/';
    memcpy(ospath + baseLength + 1, game,
           (size_t)(uint32_t)gameLength);
    ospath[gameLength + baseLength + 1] = '/';
    memcpy(ospath + gameLength + baseLength + 2, qpath,
           (size_t)(uint32_t)(qpathLength + 1));
    FS_NormalizePathSeparators(ospath + baseLength);
}
