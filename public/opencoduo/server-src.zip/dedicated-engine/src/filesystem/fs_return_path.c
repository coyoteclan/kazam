#include "fs_private.h"

char *FS_ReturnPath(const char *qpath)
{
    char osPath[FS_OSPATH_SIZE];
    FILE *file;
    searchpath_t *search;
    directory_t *dir;

    for (search = FS_SearchpathHead(); search != NULL;
         search = FS_SearchpathNext(search)) {
        if (FS_UseSearchPath(search) != 0 && search->dir != NULL) {
            dir = search->dir;
            FS_BuildOSPath(dir->path, dir->gamedir, qpath, osPath);
            file = fopen(osPath, "rb");
            if (file != NULL) {
                fclose(file);
                return va("%s/%s", dir->gamedir, qpath);
            }
        }
    }

    return NULL;
}
