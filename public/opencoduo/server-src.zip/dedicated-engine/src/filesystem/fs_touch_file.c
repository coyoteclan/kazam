#include "fs_private.h"

qboolean FS_TouchFile(const char *qpath)
{
    int32_t handle;

    FS_FOpenFileRead(qpath, &handle, 0);
    if (handle != 0) {
        FS_FCloseFile(handle);
        return 1;
    }

    return 0;
}
