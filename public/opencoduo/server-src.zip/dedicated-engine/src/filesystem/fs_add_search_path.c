#include "fs_private.h"

void FS_AddSearchPath(searchpath_t *searchpath)
{
    searchpath_t *insertAfter;

    if (searchpath->localized == 0 || fs_searchpaths == NULL) {
        searchpath->next = fs_searchpaths;
        fs_searchpaths = searchpath;
    } else {
        insertAfter = fs_searchpaths;
        while (insertAfter->next != NULL &&
               insertAfter->next->localized == 0) {
            insertAfter = insertAfter->next;
        }

        searchpath->next = insertAfter->next;
        insertAfter->next = searchpath;
    }
}
