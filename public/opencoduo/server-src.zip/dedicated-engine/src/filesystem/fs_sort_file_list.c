#include "fs_private.h"

void FS_SortFileList(char **list, int count)
{
    char **sortedList;
    int sortedCount;
    int inputIndex;
    int insertIndex;
    int shiftIndex;

    sortedList = Z_Malloc(((size_t)count + 1U) * sizeof(*sortedList));
    sortedList[0] = NULL;

    sortedCount = 0;
    for (inputIndex = 0; inputIndex < count; inputIndex++) {
        insertIndex = 0;
        while (insertIndex < sortedCount &&
               FS_PathCmp(list[inputIndex], sortedList[insertIndex]) >= 0) {
            insertIndex++;
        }

        for (shiftIndex = sortedCount; insertIndex < shiftIndex; shiftIndex--) {
            sortedList[shiftIndex] = sortedList[shiftIndex - 1];
        }

        sortedList[insertIndex] = list[inputIndex];
        sortedCount++;
    }

    Com_Memcpy(list, sortedList, (size_t)(count * (int)sizeof(*list)));
    Z_Free(sortedList);
}
