#include "fs_private.h"

qboolean FS_UseSearchPath(const searchpath_t *searchpath)
{
    if ((searchpath->localized == 0) || (fs_ignoreLozalized->integer == 0)) {
        return 1;
    }

    return 0;
}
