#include "fs_private.h"

int32_t FS_FOpenFileRead(const char *qpath, int32_t *handle,
                         int32_t uniqueFile)
{
    fs_loadStack = 1;
    return FS_FOpenFileRead_Internal((char *)qpath, handle, uniqueFile, 0);
}
