#include <stdint.h>

#include "fs_private.h"

int32_t FS_FOpenFileAppend(const char *qpath)
{
    int32_t result;
    int32_t handle;
    char osPath[FS_OSPATH_SIZE];

    handle = 0;
    FS_CheckFileSystemStarted();

    handle = FS_HandleForFile(0);
    fs_handleFiles[handle].zipArchive = NULL;
    Q_strncpyz(fs_handleFiles[handle].name, qpath, CODUO_FS_HANDLE_NAME_SIZE);

    FS_BuildOSPath(fs_homepath->string,
                   fs_currentGameDir, qpath, osPath);

    if (fs_debug->integer != 0) {
        Com_Printf("FS_FOpenFileAppend: %s\n", osPath);
    }

    if (FS_CreatePath(osPath) != 0) {
        result = 0;
    } else {
        fs_handleFiles[handle].ioObject = fopen(osPath, "ab");
        fs_handleFiles[handle].sync = 0;

        if (fs_handleFiles[handle].ioObject == NULL) {
            handle = 0;
        }

        result = handle;
    }

    return result;
}
