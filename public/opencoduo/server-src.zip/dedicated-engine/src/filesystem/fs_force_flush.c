#include "fs_private.h"

void FS_ForceFlush(int32_t handle)
{
    fflush(FS_LoadIOFile(fs_handleFiles[handle].ioObject));
}
