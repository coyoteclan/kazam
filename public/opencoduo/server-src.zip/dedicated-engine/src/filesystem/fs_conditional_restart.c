#include "fs_private.h"

qboolean FS_ConditionalRestart(int32_t checksumFeed)
{
    if (sv_running->integer != 0) {
        return 0;
    }

    if (fs_game->modified == 0 && checksumFeed == fs_checksumFeed) {
        return 0;
    }

    FS_Restart(checksumFeed);
    return 1;
}
