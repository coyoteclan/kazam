#include "fs_private.h"

void FS_FreeFileList(char **list)
{
    int index;

    FS_CheckFileSystemStarted();

    if (list == NULL) {
        return;
    }

    for (index = 0; list[index] != NULL; index++) {
        Z_Free(list[index]);
    }

    Z_Free(list);
}
