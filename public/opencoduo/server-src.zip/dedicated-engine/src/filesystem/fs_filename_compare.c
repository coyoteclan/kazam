#include <stdint.h>

#include "fs_private.h"

int32_t FS_FilenameCompare(const char *path1, const char *path2)
{
    int32_t left;
    int32_t right;

    while (1) {
        left = (int32_t)(int8_t)(uint8_t)*path1;
        path1++;
        right = (int32_t)(int8_t)(uint8_t)*path2;
        path2++;

        if (Q_islower(left) != 0) {
            left -= 'a' - 'A';
        }
        if (Q_islower(right) != 0) {
            right -= 'a' - 'A';
        }

        if (left == '\\' || left == ':') {
            left = '/';
        }
        if (right == '\\' || right == ':') {
            right = '/';
        }

        if (left != right) {
            return -1;
        }
        if (left == '\0') {
            return 0;
        }
    }
}
