#include <ctype.h>
#include <stdint.h>

#include "coduo_ctype_compat.h"
#include "coduo_int32_bits.h"

uint32_t FS_HashFileName(const char *name, int32_t hashSize)
{
    uint32_t hash;
    int32_t index;
    int32_t c;

    hash = 0;
    index = 0;

    while (name[index] != '\0') {
        c = tolower(coduo_ctype_signed_byte_arg(name[index]));
        if (c == '.') {
            break;
        }
        if (c == '\\') {
            c = '/';
        }
        if (c == '/') {
            c = '/';
        }
        hash += (uint32_t)(index + 119) * (uint32_t)c;
        index++;
    }

    hash = coduo_int32_sar_bits(hash, 20U) ^
           coduo_int32_sar_bits(hash, 10U) ^ hash;
    hash &= (uint32_t)(hashSize - 1);

    return hash;
}
