#include <dirent.h>
#include <string.h>

#include "fs_private.h"

qboolean FS_DirectoryHasNonDotEntries(const char *path)
{
    DIR *directory = opendir(path);
    qboolean hasEntries = qfalse;

    if (directory == NULL) {
        return qfalse;
    }

    for (;;) {
        struct dirent *entry = readdir(directory);
        if (entry == NULL) {
            break;
        }

        if (strcmp(entry->d_name, ".") != 0 &&
            strcmp(entry->d_name, "..") != 0) {
            hasEntries = qtrue;
            break;
        }
    }

    closedir(directory);
    return hasEntries;
}
