#include <string.h>

#include "fs_private.h"

char *FS_ShiftedStrStr(char *haystack, const char *encodedNeedle, char shift)
{
    int i;
    char needle[FS_OSPATH_SIZE];

    for (i = 0; encodedNeedle[i] != '\0'; i++) {
        needle[i] =
            (char)((unsigned char)encodedNeedle[i] + (unsigned char)shift);
    }
    needle[i] = '\0';

    return strstr(haystack, needle);
}
