#include "fs_private.h"

int32_t FS_FOpenFileReadStream(char *qpath, int32_t *handle,
                               int32_t uniqueFile)
{
    return FS_FOpenFileRead_Internal(qpath, handle, uniqueFile, 1);
}
