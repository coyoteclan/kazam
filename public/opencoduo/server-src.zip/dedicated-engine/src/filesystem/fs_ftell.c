#include "fs_private.h"

long FS_FTell(int32_t handle)
{
    if (fs_handleFiles[handle].zipArchive != NULL) {
        return Unzip_TellCurrentFile(
            FS_LoadZipIOFile(fs_handleFiles[handle].ioObject));
    }

    return (long)ftell(
        FS_LoadIOFile(fs_handleFiles[handle].ioObject));
}
