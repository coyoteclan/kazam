#include "fs_private.h"

qboolean FS_FileExists(const char *qpath)
{
    char osPath[FS_OSPATH_SIZE];
    FILE *file;
    qboolean exists;

    FS_BuildOSPath(fs_homepath->string,
                   fs_currentGameDir, qpath, osPath);
    file = fopen(osPath, "rb");
    if (file != NULL) {
        fclose(file);
        exists = 1;
    } else {
        exists = 0;
    }

    return exists;
}
