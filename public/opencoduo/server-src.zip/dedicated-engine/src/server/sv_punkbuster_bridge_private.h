#ifndef CODUO_SV_PUNKBUSTER_BRIDGE_PRIVATE_H
#define CODUO_SV_PUNKBUSTER_BRIDGE_PRIVATE_H

#include <stdint.h>

#include "coduo_engine_structs.h"

void SV_SetPunkBusterCvar(const char *value);
int32_t Pb_Q_maxclients(void);
qboolean Pb_Q_client(int32_t clientNum, char *buffer);
qboolean Pb_Q_stats(int32_t clientNum, char *buffer);
void SV_SendPbPacket(int length, const char *data,
                     int32_t clientNum);
void SV_PrintPunkBusterMessage(const char *prefix, const char *text);
void SV_DropClientNum(int32_t clientNum, const char *dropReason);

#endif
