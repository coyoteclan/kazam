#ifndef CODUO_SERVER_PRIVATE_H
#define CODUO_SERVER_PRIVATE_H

#include <stdint.h>

#include "coduo_engine_structs.h"

sharedEntity_t *SV_GentityNum(int32_t entityNum);
playerState_t *SV_GameClientNum(int32_t clientNum);
uint16_t coduomp_sv_alloc_client_script_pers(void);
void SV_FreeClientScriptId(client_t *client);
void coduomp_sv_clear_master_address(void);
void coduomp_sv_clear_rcon_redirect_address(void);
void PB_DropClient(client_t *client);
void SV_DropClient(client_t *client, const char *dropReason);
void SV_SetClientDeferredDropReason(client_t *client,
                                    const char *dropReason);
void SV_AddOperatorCommands(void);
void SV_RemoveOperatorCommands(void);
void SV_ClientEnterWorld(client_t *client, usercmd_t *cmd);
void SV_SendClientGameState(client_t *client);
void SV_ClearClientDownload(client_t *client);
void SV_WriteDownloadToClient(client_t *client, msg_t *msg);
void SV_UserinfoChanged(client_t *client);
void SV_ClientThink(client_t *client,
                    const usercmd_t *cmd);
int32_t SV_GetClientScore(client_t *client);
void SV_GetChallenge(netadr_t from);
void SV_AuthorizeIpPacket(netadr_t from);
void SV_AuthorizeRequest(netadr_t from,
                         int32_t challenge);
void SVC_Status(netadr_t from);
void SVC_GameCompleteStatus(netadr_t from);
void SVC_DirectConnect(netadr_t from);
void SV_PacketEvent(netadr_t from, msg_t *msg);
void SV_ParseClientMessage(client_t *client, msg_t *msg);
void SV_SetConfigstring(int32_t index, const char *value);
void SV_SetUserinfo(int32_t clientNum, const char *userinfo);
void SV_SendServerCommand(client_t *client,
                          qboolean reliable,
                          const char *format, ...);
void SV_InitGameProgs(qboolean cvarRestartGate);
void SV_RunGameFrame(void);
void SV_Frame(int msec);
void SV_ShutdownGameProgs(void);
intptr_t SV_GameSystemCalls(intptr_t *parms);
void SV_ClearServer(void);
void SV_FreeSnapshotArchive(void);
const char *SV_GetMapBaseName(const char *mapName);
void SV_Init(void);
void SV_Heartbeat_f(void);
netadr_t *SV_ResolveMasterAddress(void);
void SV_MasterHeartbeat(const char *heartbeat);
void FUN_0808ac2b(void);

#endif
