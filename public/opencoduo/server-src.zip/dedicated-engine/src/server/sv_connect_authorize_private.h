#ifndef CODUO_SV_CONNECT_AUTHORIZE_PRIVATE_H
#define CODUO_SV_CONNECT_AUTHORIZE_PRIVATE_H

#include "coduo_engine_structs.h"

void SV_AuthorizeGuidCacheStore(int32_t guid);
qboolean SV_AuthorizeGuidOnBanList(int32_t guid);

#endif
