#ifndef CODUO_SV_CLIENT_COMMANDS_PRIVATE_H
#define CODUO_SV_CLIENT_COMMANDS_PRIVATE_H

#include "coduo_engine_structs.h"

void SV_ClientCommand_Userinfo(client_t *client);
void SV_ClientCommand_Disconnect(client_t *client);
void SV_ClientCommand_Cp(client_t *client);
void SV_ClientCommand_Vdr(client_t *client);
void SV_ClientCommand_Download(client_t *client);
void SV_ClientCommand_Nextdl(client_t *client);
void SV_ClientCommand_Stopdl(client_t *client);
void SV_ClientCommand_Donedl(client_t *client);
void SV_ClientCommand_Retransdl(client_t *client);
void SV_ClientCommand_Wwwdl(client_t *client);

#endif
