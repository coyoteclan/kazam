#ifndef CODUO_SV_INIT_SHUTDOWN_PRIVATE_H
#define CODUO_SV_INIT_SHUTDOWN_PRIVATE_H

void SV_Shutdown(const char *finalMessage);
void SV_NormalizeGametypeCvar(void);
void SV_ResetSnapshotArchiveCounters(void);
void SV_SpawnServer(const char *server);

#endif
