#ifndef CODUO_SV_SERVER_COMMANDS_PRIVATE_H
#define CODUO_SV_SERVER_COMMANDS_PRIVATE_H

#include "coduo_engine_structs.h"

void SV_AddServerCommand(client_t *client,
                         qboolean reliable,
                         const char *command);

#endif
