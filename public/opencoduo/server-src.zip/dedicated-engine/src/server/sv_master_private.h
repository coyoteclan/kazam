#ifndef CODUO_SV_MASTER_PRIVATE_H
#define CODUO_SV_MASTER_PRIVATE_H

void SV_MasterGameCompleteStatus(void);

#endif
