#ifndef CODUO_SV_GLOBALS_PRIVATE_H
#define CODUO_SV_GLOBALS_PRIVATE_H

#include <stdint.h>

#include "coduo_engine_structs.h"

extern coduo_host_sv_prefix_t sv;
extern coduo_host_svs_header_t svs;
extern coduo_challenge_table_t host_svs_challenges;
extern coduo_authorize_guid_cache_table_t host_authorizeGuidCache;
extern netadr_t host_authorizeServerAddress;
extern coduo_vm_t *sv_gameVM;
extern char *host_sv_configstrings[CODUO_MAX_CONFIGSTRINGS];
extern coduo_host_game_data_globals_t sv_gameData;
extern coduo_host_entity_link_table_t sv_entityLinks;
extern char *sv_entityParsePoint;
extern coduo_sv_gametype_normalize_buffer_t sv_gametypeNormalizeBuffer;
extern cvar_t *host_cvar_sv_maxclients_pointer_slot;
extern cvar_t *host_cvar_cl_paused_pointer_slot;
extern cvar_t *host_cvar_com_speeds_pointer_slot;
extern cvar_t *dedicated;
extern cvar_t *host_cvar_fs_basegame_pointer_slot;
extern cvar_t *host_cvar_g_gametype_pointer_slot;
extern cvar_t *host_cvar_mapname_pointer_slot;
extern cvar_t *host_cvar_rconPassword_pointer_slot;
extern cvar_t *host_cvar_scr_allow_jeeps_pointer_slot;
extern cvar_t *host_cvar_scr_allow_tanks_pointer_slot;
extern cvar_t *host_cvar_sv_allowAnonymous_pointer_slot;
extern cvar_t *host_cvar_sv_allowDownload_pointer_slot;
extern cvar_t *host_cvar_sv_disableClientConsole_pointer_slot;
extern cvar_t *host_cvar_sv_floodProtect_pointer_slot;
extern cvar_t *host_cvar_sv_fps_pointer_slot;
extern cvar_t *host_cvar_sv_hostname_pointer_slot;
extern cvar_t *host_cvar_sv_kickBanTime_pointer_slot;
extern cvar_t *host_cvar_sv_killserver_pointer_slot;
extern cvar_t *host_cvar_sv_mapRotation_pointer_slot;
extern cvar_t *host_cvar_sv_mapRotationCurrent_pointer_slot;
extern cvar_t *host_cvar_sv_maxPing_pointer_slot;
extern cvar_t *host_cvar_sv_maxRate_pointer_slot;
extern cvar_t *host_cvar_sv_minPing_pointer_slot;
extern cvar_t *host_cvar_sv_onlyVisibleClients_pointer_slot;
extern cvar_t *host_cvar_sv_packet_info_pointer_slot;
extern cvar_t *host_cvar_sv_paused_pointer_slot;
extern cvar_t *host_cvar_sv_padPackets_pointer_slot;
extern cvar_t *host_cvar_sv_privateClients_pointer_slot;
extern cvar_t *host_cvar_sv_privatePassword_pointer_slot;
extern cvar_t *host_cvar_sv_punkbuster_pointer_slot;
extern cvar_t *host_cvar_sv_pure_pointer_slot;
extern cvar_t *host_cvar_sv_reconnectlimit_pointer_slot;
extern cvar_t *host_cvar_sv_running_pointer_slot;
extern cvar_t *host_cvar_sv_showAverageBPS_pointer_slot;
extern cvar_t *host_cvar_sv_showCommands_pointer_slot;
extern cvar_t *host_cvar_sv_timeout_pointer_slot;
extern cvar_t *host_cvar_sv_wwwBaseURL_pointer_slot;
extern cvar_t *host_cvar_sv_wwwDlDisconnected_pointer_slot;
extern cvar_t *host_cvar_sv_wwwDownload_pointer_slot;
extern cvar_t *host_cvar_sv_zombietime_pointer_slot;
extern cvar_t *host_cvar_sv_cracked_pointer_slot;
extern cvar_t *host_cvar_timescale_pointer_slot;
extern cvar_t *_host_cvar_sv_serverid_pointer_slot;
extern cvar_t *_host_cvar_sv_showloss_pointer_slot;
extern cvar_t *sv_fps;
extern cvar_t *sv_maxRate;
extern cvar_t *sv_maxclients;
extern cvar_t *sv_padPackets;
extern cvar_t *sv_showAverageBPS;
extern int32_t com_errorEntered;
extern int32_t sv_serverId;
extern int32_t host_sv_frame_running_flag;
extern int32_t host_sv_rconThrottleTime;
extern int32_t sv_serverId_source;
extern int32_t host_sv_timeResidual;
extern int sv_averageBpsFrameCount;
extern float sv_averageCompressionRatioSum;
extern int sv_averageCompressionRatioCount;
extern int sv_compressedBpsMax;
extern int sv_compressedBpsWindow[20];
extern int32_t sv_reconnectSequence;
extern int sv_totalBytesSentThisFrame;
extern int sv_totalUncompressedBytesThisFrame;
extern int sv_uncompressedBpsMax;
extern int sv_uncompressedBpsWindow[20];
extern coduo_sv_client_command_handler_table_t sv_clientCommandHandlers;

#endif
