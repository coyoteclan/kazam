#ifndef CODUO_SV_GAME_LIFECYCLE_PRIVATE_H
#define CODUO_SV_GAME_LIFECYCLE_PRIVATE_H

#include "coduo_engine_structs.h"

void SV_RestartGameProgs(qboolean cvarRestartGate);

#endif
