#ifndef CODUO_CM_LOAD_MAP_PRIVATE_H
#define CODUO_CM_LOAD_MAP_PRIVATE_H

#include "coduo_engine_structs.h"

const char *Com_BuildVersionString(void);
void CM_LoadMap(const char *name, qboolean clientload, int32_t *checksum);

#endif
