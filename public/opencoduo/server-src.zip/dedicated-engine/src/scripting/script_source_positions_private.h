#ifndef CODUO_SCRIPT_SOURCE_POSITIONS_PRIVATE_H
#define CODUO_SCRIPT_SOURCE_POSITIONS_PRIVATE_H

#include <stdint.h>

#include "coduo_engine_structs.h"

enum {
    SCRIPT_SOURCE_POS_TABLE_COUNT = 2,
    SCRIPT_SAVED_SOURCE_FILE_COUNT_NONE = -1
};

typedef struct script_source_pos_record_s {
    uint8_t *codePos;
    uint32_t sourcePosIndex;
    uint32_t reserved08;
    uint32_t reserved0c;
} script_source_pos_record_t;

typedef struct script_source_file_record_s {
    uint8_t *normalCodeStart;
    uint8_t *relocatedCodeStart;
    char *name;
    char *source;
    int32_t sourceLen;
} script_source_file_record_t;

typedef struct script_saved_source_file_s {
    char *source;
    int32_t sourceLen;
} script_saved_source_file_t;

extern const char *script_sourcePos;
extern const char *script_sourceFilename;
extern uint32_t script_sourceFileCount;
extern uint32_t script_sourceFileCapacity;
extern script_source_file_record_t *script_sourceFiles;
extern int32_t script_savedSourceFileCount;
extern script_saved_source_file_t *script_savedSourceFiles;
extern uint32_t script_sourcePosCountForLastCodePos;
extern uint8_t *script_sourcePosLastCodePos;
extern uint32_t *script_sourcePosPool;
extern uint32_t script_sourcePosPoolCapacity;
extern uint32_t script_sourcePosPoolCount;
extern uint32_t
    script_sourcePosTableCapacity[SCRIPT_SOURCE_POS_TABLE_COUNT];
extern uint32_t script_sourcePosTableCount[SCRIPT_SOURCE_POS_TABLE_COUNT];
extern script_source_pos_record_t
    *script_sourcePosTables[SCRIPT_SOURCE_POS_TABLE_COUNT];

void InitOpcodeLookup(void);
void ShutdownOpcodeLookup(void);
qboolean Scr_IsInOpcodeMemory(coduo_script_codepos_t codePos);
qboolean Scr_IsInDeveloperOpcodeMemory(coduo_script_codepos_t codePos);
void AddOpcodePos(uint32_t sourcePos);
uint32_t GetPrevSourcePos(coduo_script_codepos_t codePos,
                          int32_t sourcePosOffset);
void CompileError2(coduo_script_codepos_t codePos,
                   const char *format, ...);
char *Scr_AddSourceBuffer(const char *filename,
                          uint8_t *normalCodeStart,
                          uint8_t *relocatedCodeStart);

#endif
