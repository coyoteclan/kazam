#ifndef CODUO_SCRIPT_VARIABLE_PRIVATE_H
#define CODUO_SCRIPT_VARIABLE_PRIVATE_H

#include "coduo_engine_structs.h"

extern uint16_t script_classMapRoot;
extern uint16_t script_entityTypeClassMapRoot;
extern coduo_script_entity_type_usage_t *script_entityTypeUsageRecords;
extern uint32_t script_entityTypeUsageCount;
extern coduo_script_variable_indirection_table_t script_variableIndirections;
extern coduo_script_variable_node_table_t script_variableNodes;
extern const char *script_variableTypeNames[CODUO_SCRIPT_VARIABLE_TYPE_COUNT];

uint32_t Scr_GetNumScriptVars(void);
uint16_t Scr_AllocArray(void);
coduo_script_variable_node_t *AllocVariable(void);
uint16_t AllocValue(void);
uint16_t AllocObject(void);
uint16_t
AllocThread(uint16_t parent);
void Var_Init(void);
void AddRefToObject(uint16_t handle);
void ClearVariableValue(uint16_t handle);
void ClearObjectInternal(uint16_t handle);
void FreeValueInternal(coduo_script_variable_node_t *node);
void FreeVariable(uint16_t handle);
void ClearObject(uint16_t handle);
void FreeValue(uint16_t handle);
void RemoveRefToObject(uint16_t handle);
uint16_t
GetArraySize(uint16_t handle);
uint16_t
FindVariable(uint16_t parent, uint32_t name);
uint16_t
FindVariableIndexInternal(uint16_t parent,
                                    uint32_t name);
uint16_t
FindObjectVariable(uint16_t parent,
                               uint16_t child);
uint16_t
FindArrayVariable(uint16_t parent,
                                  int32_t name);
uint16_t
FindArrayVariableIndex(uint16_t parent,
                       uint32_t name);
uint16_t
GetArrayVariableByUnsignedIndex(uint16_t classRoot,
                                uint32_t name);
uint16_t
GetVariable(uint16_t parent, uint32_t name);
uint16_t
GetVariableIndexInternal(uint16_t parent,
                                   uint32_t name);
uint16_t
GetArray(uint16_t handle);
uint16_t
GetVariableKeyObject(uint16_t handle);
uint32_t GetVariableName(uint16_t handle);
uint32_t GetEntityType(uint16_t handle);
uint16_t
GetObjectVariable(uint16_t parent,
                              uint16_t child);
uint16_t
GetArrayVariableBySignedIndex(uint16_t parent,
                                 int32_t name);
uint16_t
GetArrayVariableIndex(uint16_t parent,
                      uint32_t name);
uint16_t
GetVariableField(uint16_t parent,
                             uint16_t name);
uint16_t
GetSelf(uint16_t handle);
uint16_t
GetObject(uint16_t handle);
coduo_script_variable_type_t
GetVarType(uint16_t handle);
uint16_t
GetThreadNotifyName(uint16_t handle);
qboolean IsFieldObject(uint16_t handle);
qboolean IsValidArrayIndex(uint32_t name);
uint16_t
FindNextSibling(uint16_t handle);
uint16_t
FindObject(uint16_t handle);
uint16_t
AllocEntity(int32_t classNum,
                           uint16_t entityNum);
void ClearThreadNotifyName(uint16_t handle);
void CopyArray(uint16_t source,
                                       uint16_t dest);
void RemoveVariable(uint16_t parent,
                                uint32_t name);
void SafeRemoveVariable(
    uint16_t parent, uint32_t name);
void SafeRemoveArrayVariable(
    uint16_t parent, uint32_t name);
void RemoveArrayVariable(uint16_t parent,
                         uint32_t name);
void RemoveObjectVariable(
    uint16_t parent, uint16_t child);
VariableValue *
GetVariableValueAddress(uint16_t handle);
void GetVariableValue(uint16_t handle,
                              VariableValue *value);
void SetVariableValue(uint16_t handle,
                      VariableValue *value);
void SetVariableFieldValue(uint16_t handle,
                                       VariableValue *value);
void SetNewVariableValue(uint16_t handle,
                         VariableValue *value);
void MakeVariableExternal(
    Variable *slot,
    coduo_script_variable_node_t *parentNode);
uint16_t
Scr_GetEntityId(int32_t entityNum, int32_t classNum);
uint16_t
GetEntnum(uint16_t handle);
coduo_script_value_payload_t AllocVectorCopy(const vec3_t vector);
void RemoveRefToVector(coduo_script_value_payload_t vectorPayload);
void AddRefToValue(coduo_script_variable_type_t type,
                        coduo_script_value_payload_t payload);
void RemoveRefToValue(coduo_script_variable_type_t type,
                         coduo_script_value_payload_t payload);

#endif
