#ifndef CODUO_SCRIPT_STRING_PRIVATE_H
#define CODUO_SCRIPT_STRING_PRIVATE_H

#include "coduo_engine_structs.h"

#ifdef __cplusplus
extern "C" {
#endif

uint16_t SL_ConvertFromString(const char *text);

#ifdef __cplusplus
}
#endif

#endif
