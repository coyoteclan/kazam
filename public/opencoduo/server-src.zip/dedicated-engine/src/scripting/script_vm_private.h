#ifndef CODUO_SCRIPT_VM_PRIVATE_H
#define CODUO_SCRIPT_VM_PRIVATE_H

#include <stdint.h>

#include "coduo_engine_structs.h"

#ifdef __cplusplus
extern "C" {
#endif

uint16_t
VM_Execute(VariableValue *stackTop, uint8_t *codePos,
           uint16_t thread,
           uint16_t currentObject,
           VariableValue *stackBase);

#ifdef __cplusplus
}
#endif

#endif
