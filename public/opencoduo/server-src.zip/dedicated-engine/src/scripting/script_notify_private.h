#ifndef CODUO_SCRIPT_NOTIFY_PRIVATE_H
#define CODUO_SCRIPT_NOTIFY_PRIVATE_H

#include "coduo_engine_structs.h"

#ifdef __cplusplus
extern "C" {
#endif

void KillThread(uint16_t objectHandle);
void VM_TerminateNotifyList(uint16_t objectHandle);

#ifdef __cplusplus
}
#endif

#endif
