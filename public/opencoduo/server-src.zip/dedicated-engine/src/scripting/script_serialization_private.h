#ifndef CODUO_SCRIPT_SERIALIZATION_PRIVATE_H
#define CODUO_SCRIPT_SERIALIZATION_PRIVATE_H

#include <stddef.h>
#include <stdint.h>

#include "coduo_engine_structs.h"

extern uint16_t *script_objectIdToVariable;
extern uint16_t script_savedObjectCount;
extern uint8_t *script_serializationCursor;
extern uint16_t *script_variableToObjectId;

void WriteByte(uint8_t value);
uint8_t ReadByte(void);
void WriteShort(uint16_t value);
uint16_t ReadShort(void);
void WriteString(uint16_t string);
uint16_t ReadString(void);
void WriteFloat(float value);
long double ReadFloat(void);
void ScriptSave_WriteData(const void *data, size_t length);
void ScriptLoad_ReadData(void *data, size_t length);

#endif
