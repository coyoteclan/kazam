#ifndef CODUO_SCRIPT_RUNTIME_PRIVATE_H
#define CODUO_SCRIPT_RUNTIME_PRIVATE_H

#include "coduo_engine_structs.h"

extern coduo_script_call_stack_codepos_t script_callStackCodepos;
extern uint32_t script_callStackDepth;
extern uint32_t script_currentTimeKey;
extern const char *script_errorMessage;
extern int32_t script_errorParameterIndex;
extern const char *script_errorSource;
extern coduo_script_export_table_t script_exportCallbacks;
extern uint8_t script_forceErrorReport;
extern coduo_script_import_table_t script_importCallbacks;
extern int32_t
    script_loopWatchdogWarningFlag;
extern uint32_t script_loopWatchdogTick;
extern uint32_t script_parameterCount;
extern uint8_t script_runtimeActive;
extern int32_t
    script_runtimeDebugReportFlag;
extern int32_t script_runtimeDeveloperFlag;
extern int32_t
    script_runtimeDeveloperScriptFlag;
extern coduo_script_value_stack_t script_valueStack;
extern uint32_t script_valueStackDepth;
extern VariableValue *script_valueStackLimit;
extern VariableValue *script_valueStackTop;
extern coduo_script_variable_type_t script_coerceLeftType;
extern coduo_script_variable_type_t script_coerceRightType;
extern uint16_t script_animHandle;
extern uint16_t script_levelHandle;
extern uint16_t script_gameHandle;
extern uint16_t script_pauseArrayHandle;
extern uint16_t script_tempValueHandle;
extern uint16_t script_timeArrayHandle;

void Scr_Init(
    int32_t debugReport,
    int32_t developerScript,
    int32_t developerFlag);
void Scr_AllocGameVariable(void);
void Scr_FreeGameVariable(qboolean shutdown);
void Scr_GetChecksum(uint32_t checksum[3]);
coduo_script_import_callback_t *
Scr_NearHook(
    const coduo_script_export_callback_t *gameCallbacks);
coduo_script_function_callback_fn
Scr_GetFunction(const char **name, int *developerOnly);
coduo_script_method_callback_fn Scr_GetMethod(const char **name,
                                              int *developerOnly);
void Scr_Error(const char *message);
void Scr_TerminalError(const char *message);
void Scr_AddConstString(uint16_t value);
void Scr_NotifyId(uint16_t objectHandle,
                  uint16_t notifyName,
                  uint32_t paramCount);
void Scr_SetObjectField(int classnum, int objectNum, int fieldIndex);
void Scr_GetObjectField(int classnum, int objectNum, int fieldIndex);
void Scr_Shutdown(void);
void Scr_Abort(void);
void Scr_SetLoading(
    int32_t enabled);
void IncInParam(void);
void ScriptRuntime_RaiseError(void);
void VM_SetTime(void);
uint64_t rdtsc(void);
void SetEntityFieldValue(uint32_t classnum, int32_t objectNum,
                         int32_t fieldIndex, VariableValue *value);
void GetEntityFieldValue(uint32_t classnum, int32_t objectNum,
                         int32_t fieldIndex, VariableValue *value);
void RuntimeError(coduo_script_codepos_t codePos,
                                        int32_t sourcePosOffset,
                                        const char *message,
                                        const char *dialogMessage);
void Scr_ResetTimeout(void);
void Scr_PrintPrevCodePos(int32_t channel,
                              coduo_script_codepos_t codePos,
                              int32_t sourcePosOffset);
void Scr_DumpScriptThreads(void);
void Scr_DumpScriptVariables(void);
void ScriptValue_AddRefValue(VariableValue *value);
void ScriptValue_ReleaseValue(VariableValue *value);
long double FUN_080b085c(float value);
qboolean CastBool(VariableValue *value);
qboolean CastInt(VariableValue *value);
qboolean CastFloat(VariableValue *value);
qboolean CastString(VariableValue *value);
qboolean CastIString(VariableValue *value);
qboolean CastPointer(VariableValue *value);
qboolean CastVector(VariableValue *value);
qboolean CheckEquality(VariableValue *left,
                       VariableValue *right);
void VM_Resume(uint16_t threadList);

#endif
