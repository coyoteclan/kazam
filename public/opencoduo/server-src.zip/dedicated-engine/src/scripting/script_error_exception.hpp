/*
 * Maintained C++ spelling for the original script VM exception object.
 * The constructor body is original-backed at VA 0x080b0892; the class name is a
 * recovered adapter for the original EH throw/catch ABI.
 */
class ScriptErrorClass {
  public:
    ScriptErrorClass();
};
