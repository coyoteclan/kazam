#include <stdint.h>

#include "script_error_exception.hpp"

enum {
    SCRIPT_COM_ERROR_DROP = 1
};


extern "C" {

extern uint32_t script_callStackDepth;
extern const char *script_errorMessage;

extern void Com_Error(int32_t code, const char *format, ...);

ScriptErrorClass::ScriptErrorClass()
{
}

void ScriptRuntime_RaiseError(void)
{
    if (script_callStackDepth != 0) {
        throw ScriptErrorClass();
    }

    Com_Error(SCRIPT_COM_ERROR_DROP, "\x15" "%s", script_errorMessage);
}

}
