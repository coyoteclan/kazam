# coduo-server

Work-in-progress source for Call of Duty: United Offensive dedicated-server
components.

This public tree is intentionally limited to maintained source and public-safe
documentation. It does not include retail binaries, private binary-analysis
records, generated decompiler output, Ghidra databases, server-access notes, or
private recovery ledgers.

## Layout

- `game-module/`: compileable game-module source.
- `dedicated-engine/`: compileable dedicated-server engine source slices.
- `docs/`: public build and project-boundary notes.

## Status

The target is functional equivalence for server-side components. The source is
incomplete and should be treated as work in progress. Reviewed areas are kept in
compileable C/C++; unfinished behavior is represented by explicit stubs, names,
or declarations rather than generated dumps.

## Build

```sh
make -C game-module shared-i386
make -C game-module shared
make -C dedicated-engine check
make windows-i686
```

The Windows targets build both a PE32 console dedicated engine and the PE32
`uo_game_mp_x86.dll` it hosts. `windows-i386` selects the i386 instruction
baseline and `windows-i686` selects i686; both retain x87 math with the
retail-compatible 53-bit Windows precision mode. MinGW zlib can be supplied
with `WINDOWS_DEP_PREFIX=/path/to/prefix`.

See `BUILDING.md` for platform details and `docs/project-boundary.md` for what
is intentionally excluded from this export.
